/* Graphics (GX) command processor front end.
 *
 * The game writes graphics commands, byte by byte, to the write-gather pipe at 0xCC008000. This file decodes
 * that stream (it must know every command's length, which for draws depends on the vertex format) and
 * executes the commands that matter for control flow: draw-sync tokens and draw-done (pixel engine). Drawing
 * itself is counted and discarded; a renderer would hook in at the marked places.
 *
 * Command encoding (from the GX documentation as I know it; the boot is the test): 0x00 NOP, 0x08 CP register
 * load (reg, u32), 0x10 XF load (u32 header: (count-1)<<16 | address, then count words), 0x20/28/30/38 indexed
 * XF load (u32), 0x40 call display list (addr, size), 0x48 invalidate vertex cache, 0x61 BP register load (u32),
 * 0x80..0xB8 draws (u16 vertex count + vertices; low 3 bits select the vertex attribute table). */
#include "rt.h"
#include "rt_gxr.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint8_t *buf; static size_t cap, head, tail;
#define cp gx_cp                                       /* register files live in rt_gxr.c so the renderer can read them */
#define bp gx_bp
static uint32_t bp_mask = 0xFFFFFF;                    /* BP register 0xFE: bit mask applied to the next BP write */
static int depth;
static struct { unsigned long long cmds, draws, verts, bp_writes, xf_writes, tokens, finishes, errors, bytes; } st;
static int err_logged;

/* ---- pixel engine registers (0xCC001000) ---- */
static uint16_t pe_token, pe_ctrl;                   /* ctrl: 1 token enable, 2 finish enable, 4 token status, 8 finish status */
uint32_t rt_gx_pe_irq_bits(void) { return ((pe_ctrl & 5) == 5 ? 1u << 9 : 0) | ((pe_ctrl & 10) == 10 ? 1u << 10 : 0); }
int rt_gx_pe_access(uint32_t a, int write, int size, uint32_t *v) {
    uint32_t off = a & 0xFFFF;
    if (off >= 0x40 + 0x1000 || off < 0x1000) return 0;
    off -= 0x1000;
    if (size != 2 && size != 4) return 0;
    if (off == 0x0A) {                                /* control: enables are written, status bits clear on write of 1 */
        if (!write) { *v = pe_ctrl; return 1; }
        uint16_t nv = (uint16_t)*v;
        pe_ctrl = (uint16_t)((nv & 3) | (pe_ctrl & 0xC & ~nv));
        rt_irq_recompute(); return 1;
    }
    if (off == 0x0E) { if (!write) *v = pe_token; return 1; }
    return 0;                                         /* other PE registers: default storage */
}

/* ---- vertex size from the vertex descriptor (CP 0x50/0x60) and attribute table (CP 0x70/0x80/0x90 + n) ---- */
int gx_vtx_size(int vat) {
    static const int fsz[8] = {1, 1, 2, 2, 4, 0, 0, 0}, csz[8] = {2, 3, 4, 2, 3, 4, 0, 0};
    uint32_t lo = cp[0x50], hi = cp[0x60], a = cp[0x70 + vat], b = cp[0x80 + vat], c = cp[0x90 + vat];
    int n = (int)(lo & 1);                                              /* position matrix index */
    for (int i = 0; i < 8; i++) n += (int)((lo >> (1 + i)) & 1);        /* texture matrix indices */
    int pos = (lo >> 9) & 3, nrm = (lo >> 11) & 3, c0 = (lo >> 13) & 3, c1 = (lo >> 15) & 3;
    if (pos) n += pos == 1 ? ((a & 1) ? 3 : 2) * fsz[(a >> 1) & 7] : pos - 1;
    if (nrm) {
        int nbt = (a >> 9) & 1, fmt = (a >> 10) & 7;
        if (nrm == 1) n += (nbt ? 9 : 3) * fsz[fmt];
        else n += (nrm - 1) * ((nbt && ((a >> 31) & 1)) ? 3 : 1);
    }
    if (c0) n += c0 == 1 ? csz[(a >> 14) & 7] : c0 - 1;
    if (c1) n += c1 == 1 ? csz[(a >> 18) & 7] : c1 - 1;
    static const int sh_cnt[8] = {21, 0, 9, 18, 27, 5, 14, 23}, sh_fmt[8] = {22, 1, 10, 19, 28, 6, 15, 24};
    for (int i = 0; i < 8; i++) {
        int tc = (hi >> (2 * i)) & 3;
        if (!tc) continue;
        uint32_t w = i == 0 ? a : i < 5 ? b : c;
        int cnt = (int)((w >> sh_cnt[i]) & 1), fmt = (int)((w >> sh_fmt[i]) & 7);
        n += tc == 1 ? (cnt ? 2 : 1) * fsz[fmt] : tc - 1;
    }
    return n;
}

static uint32_t be32(const uint8_t *p) { return (uint32_t)p[0] << 24 | p[1] << 16 | p[2] << 8 | p[3]; }

/* Returns the byte length of the command at the head, 0 if more bytes are needed to tell, -1 if unknown. */
static long cmd_len(const uint8_t *p, size_t avail) {
    uint8_t op = p[0];
    if (op == 0x00 || op == 0x48 || op == 0x44) return 1;
    if (op == 0x08) return 6;
    if (op == 0x61) return 5;
    if (op == 0x20 || op == 0x28 || op == 0x30 || op == 0x38) return 5;
    if (op == 0x40) return 9;
    if (op == 0x10) { if (avail < 5) return 0; return 5 + 4L * ((be32(p + 1) >> 16) + 1); }
    if (op >= 0x80 && op <= 0xBF) {
        if (avail < 3) return 0;
        return 3 + (long)((p[1] << 8) | p[2]) * gx_vtx_size(op & 7);
    }
    return -1;
}

static void exec(Ctx *c, const uint8_t *p, long len) {
    uint8_t op = p[0];
    st.cmds++;
    if (op == 0x08) cp[p[1]] = be32(p + 2);
    else if (op == 0x10) {
        uint32_t h = be32(p + 1), n = (h >> 16) + 1, a = h & 0xFFFF; st.xf_writes++;
        gxr_set_ctx(c); for (uint32_t i = 0; i < n; i++) gxr_xf_write(a + i, be32(p + 5 + 4 * i));
    }
    else if (op == 0x20 || op == 0x28 || op == 0x30 || op == 0x38) gxr_xf_load_indexed(c, op, be32(p + 1));
    else if (op >= 0x80 && op <= 0xBF) {
        int n = (p[1] << 8) | p[2]; st.draws++; st.verts += (unsigned)n;
        gxr_draw(c, op, p + 3, n);
    }
    else if (op == 0x61) {
        uint32_t v = be32(p + 1); uint8_t reg = (uint8_t)(v >> 24);
        st.bp_writes++;
        if (reg == 0xFE) { bp_mask = v & 0xFFFFFF; return; }
        bp[reg] = (bp[reg] & ~bp_mask) | (v & bp_mask); bp_mask = 0xFFFFFF;
        gxr_bp_write(c, reg, bp[reg]);
        if (reg == 0x47 || reg == 0x48) {                                   /* draw-sync token (0x48 also interrupts) */
            pe_token = (uint16_t)v; st.tokens++;
            if (reg == 0x48) pe_ctrl |= 4;
            rt_irq_recompute();
        } else if (reg == 0x45 && (v & 0xFFFFFF) == 2) {                    /* draw done */
            pe_ctrl |= 8; st.finishes++; rt_irq_recompute();
        }
    }
    (void)len;
}

static void feed(Ctx *c, const uint8_t *data, size_t n);
static void run(Ctx *c) {
    while (head < tail) {
        long len = cmd_len(buf + head, tail - head);
        if (len == 0 || (len > 0 && (size_t)len > tail - head)) return;        /* wait for the rest */
        if (len < 0) {
            st.errors++;
            if (!err_logged) { err_logged = 1;
                fprintf(stderr, "[gx] unknown FIFO command 0x%02X (after %llu commands); dropping the buffer\n", buf[head], st.cmds); }
            head = tail = 0; return;
        }
        if (buf[head] == 0x40 && depth < 4) {                                  /* display list: run it from memory */
            uint32_t addr = 0x80000000u | be32(buf + head + 1), size = be32(buf + head + 5);
            head += (size_t)len; st.cmds++;
            if (size && size < (1u << 24)) {
                uint8_t *dl = malloc(size);
                for (uint32_t i = 0; i < size; i++) dl[i] = (uint8_t)rt_r8(c, addr + i);
                depth++; feed(c, dl, size); depth--; free(dl);
            }
            continue;
        }
        exec(c, buf + head, len); head += (size_t)len;
    }
    head = tail = 0;
}
static void feed(Ctx *c, const uint8_t *data, size_t n) {
    if (tail + n > cap) {                                                      /* compact, then grow */
        if (head) { memmove(buf, buf + head, tail - head); tail -= head; head = 0; }
        if (tail + n > cap) { cap = (tail + n) * 2 + 4096; buf = realloc(buf, cap); }
    }
    memcpy(buf + tail, data, n); tail += n; st.bytes += n;
    run(c);
    if (rt_chk_addr) rt_chk_hook(0xAAAA0004u);                 /* debug marker: after GX FIFO processing */
}
/* Write-gather pipe: 1, 2, 4 or 8 byte writes, big-endian. */
void rt_gx_fifo_write(Ctx *c, uint64_t v, int size) {
    uint8_t b[8];
    for (int i = 0; i < size; i++) b[i] = (uint8_t)(v >> (8 * (size - 1 - i)));
    feed(c, b, (size_t)size);
}
void rt_gx_summary(void) {
    fprintf(stderr, "GX: %llu bytes, %llu commands (%llu draws, %llu vertices, %llu BP, %llu XF), %llu tokens, %llu finishes, %llu errors\n",
            st.bytes, st.cmds, st.draws, st.verts, st.bp_writes, st.xf_writes, st.tokens, st.finishes, st.errors);
    gxr_summary();
}
