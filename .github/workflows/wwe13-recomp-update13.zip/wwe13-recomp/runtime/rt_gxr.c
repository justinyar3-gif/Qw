/* GX renderer front end: vertex fetch and decode, transform, texture coordinate generation, fragment state snapshot, EFB copies.
 * See rt_gxr.h. All register layouts are from memory (SDK / Dolphin); the unit test builds a tiny command stream and checks the result
 * against hand-computed values, but only the real game can show whether the layouts are right. */
#include "rt_gxr.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

uint32_t gx_cp[256], gx_bp[256], gx_xf[0x1100];
static const GxrBackend *g_be;
static int16_t g_tevreg[2][4][4];                         /* [0] colour registers PREV,C0,C1,C2  [1] constants K0..K3; r,g,b,a signed 11 bit */
static uint32_t g_frames; static unsigned long long n_tris, n_culled_all, n_copies_xfb, n_copies_tex, n_copies_skip;
static int env_flipcull;

void gxr_set_backend(const GxrBackend *b) { g_be = b; env_flipcull = getenv("RT_GX_FLIPCULL") != NULL; }
const GxrBackend *gxr_backend(void) { return g_be; }
uint32_t gxr_frames(void) { return g_frames; }

static float fb(uint32_t u) { float f; memcpy(&f, &u, 4); return f; }
static uint32_t phys_ea(uint32_t p) { return p < 0x01800000u ? 0x80000000u | p : (p >= 0x10000000u && p < 0x14000000u) ? 0x90000000u | (p - 0x10000000u) : 0x80000000u | (p & 0x01FFFFFFu); }
static int sext11(uint32_t v) { v &= 0x7FF; return (int)(v & 0x400 ? v | 0xFFFFF800u : v); }

static Ctx *g_ctx; void gxr_set_ctx(Ctx *c) { g_ctx = c; }
void gxr_xf_write(uint32_t addr, uint32_t v) {
    static int xtrace = -1, xn;
    if (xtrace < 0) xtrace = getenv("RT_GXR_XFTRACE") ? atoi(getenv("RT_GXR_XFTRACE")) : 0;
    if (xtrace && xn < xtrace && addr >= 0x101A && addr <= 0x1026) { xn++; fprintf(stderr, "[xf] frame %u reg %04X <- %08X (%g) guest lr %08X\n", g_frames, addr, v, fb(v), g_ctx ? g_ctx->lr : 0); }
    if (addr < 0x1100) gx_xf[addr] = v;
}
void gxr_xf_load_indexed(Ctx *c, int op, uint32_t w) {
    int arr = op == 0x20 ? 12 : op == 0x28 ? 13 : op == 0x30 ? 14 : 15;
    uint32_t idx = w >> 16, n = ((w >> 12) & 15) + 1, addr = w & 0xFFF;
    uint32_t src = (gx_cp[0xA0 + arr] & 0x03FFFFFFu) + idx * (gx_cp[0xB0 + arr] & 0xFF);
    for (uint32_t i = 0; i < n; i++) gxr_xf_write(addr + i, rt_r32(c, phys_ea(src) + 4 * i));
}

/* ---------------------------------------------------------------- fragment state */
static int g_frag_valid; static GxrFrag g_frag;
static void build_frag(Ctx *c, GxrFrag *f) {
    memset(f, 0, sizeof *f);
    uint32_t gm = gx_bp[0x00];
    f->nstages = (int)((gm >> 10) & 15) + 1; f->nchans = (int)((gm >> 4) & 7); f->cull = (int)((gm >> 14) & 3);
    for (int i = 0; i < f->nstages; i++) {
        GxrStage *s = &f->st[i]; uint32_t ce = gx_bp[0xC0 + 2 * i], ae = gx_bp[0xC1 + 2 * i], ord = gx_bp[0x28 + i / 2], ks = gx_bp[0xF6 + i / 2];
        s->cd = ce & 15; s->cc = (ce >> 4) & 15; s->cb = (ce >> 8) & 15; s->ca = (ce >> 12) & 15; s->cbias = (ce >> 16) & 3; s->csub = (ce >> 18) & 1;
        s->cclamp = (ce >> 19) & 1; s->cscale = (ce >> 20) & 3; s->cdest = (ce >> 22) & 3;
        s->rswap = ae & 3; s->tswap = (ae >> 2) & 3;
        s->ad = (ae >> 4) & 7; s->ac = (ae >> 7) & 7; s->ab = (ae >> 10) & 7; s->aa = (ae >> 13) & 7; s->abias = (ae >> 16) & 3; s->asub = (ae >> 18) & 1;
        s->aclamp = (ae >> 19) & 1; s->ascale = (ae >> 20) & 3; s->adest = (ae >> 22) & 3;
        if (i & 1) { s->texmap = (ord >> 12) & 7; s->texcoord = (ord >> 15) & 7; s->texen = (ord >> 18) & 1; s->chan = (ord >> 19) & 7; s->kc = (ks >> 14) & 31; s->ka = (ks >> 19) & 31; }
        else       { s->texmap = ord & 7; s->texcoord = (ord >> 3) & 7; s->texen = (ord >> 6) & 1; s->chan = (ord >> 7) & 7; s->kc = (ks >> 4) & 31; s->ka = (ks >> 9) & 31; }
        s->tsx = s->tsy = 1.f;
    }
    for (int t = 0; t < 4; t++) {
        uint32_t a = gx_bp[0xF6 + 2 * t], b = gx_bp[0xF7 + 2 * t];
        f->swap[t][0] = a & 3; f->swap[t][1] = (a >> 2) & 3; f->swap[t][2] = b & 3; f->swap[t][3] = (b >> 2) & 3;
    }
    memcpy(f->reg, g_tevreg[0], sizeof f->reg); memcpy(f->konst, g_tevreg[1], sizeof f->konst);
    uint32_t ac = gx_bp[0xF3];
    f->aref0 = ac & 255; f->aref1 = (ac >> 8) & 255; f->acomp0 = (ac >> 16) & 7; f->acomp1 = (ac >> 19) & 7; f->alogic = (ac >> 22) & 3;
    uint32_t zm = gx_bp[0x40], bl = gx_bp[0x41];
    f->ztest = zm & 1; f->zfunc = (zm >> 1) & 7; f->zupdate = (zm >> 4) & 1;
    f->blend = bl & 1; f->logic = (bl >> 1) & 1; f->color_update = (bl >> 3) & 1; f->alpha_update = (bl >> 4) & 1;
    f->dfactor = (bl >> 5) & 7; f->sfactor = (bl >> 8) & 7; f->bsub = (bl >> 11) & 1; f->logicop = (bl >> 12) & 15;
    uint32_t tl = gx_bp[0x20], br = gx_bp[0x21], off = gx_bp[0x59]; int ox = (int)(off & 0x3FF) * 2, oy = (int)((off >> 10) & 0x3FF) * 2;
    f->scissor[0] = (int)((tl >> 12) & 0x7FF) - ox; f->scissor[1] = (int)(tl & 0x7FF) - oy;
    f->scissor[2] = (int)((br >> 12) & 0x7FF) - ox + 1; f->scissor[3] = (int)(br & 0x7FF) - oy + 1;
    if (f->scissor[0] < 0) f->scissor[0] = 0;
    if (f->scissor[1] < 0) f->scissor[1] = 0;
    if (f->scissor[2] > GXR_EFB_W) f->scissor[2] = GXR_EFB_W;
    if (f->scissor[3] > GXR_EFB_H) f->scissor[3] = GXR_EFB_H;
    f->vp[0] = fb(gx_xf[0x101A]); f->vp[1] = fb(gx_xf[0x101B]); f->vp[2] = fb(gx_xf[0x101C]);   /* zscale: SDK writes 2^24 */
    f->vp[3] = fb(gx_xf[0x101D]) - 342.f; f->vp[4] = fb(gx_xf[0x101E]) - 342.f; f->vp[5] = fb(gx_xf[0x101F]);
    /* textures used by the stages */
    for (int i = 0; i < f->nstages; i++) {
        GxrStage *s = &f->st[i];
        if (!s->texen) continue;
        int u = s->texmap;
        if (!f->tex[u]) {
            f->tex[u] = gxr_tex_get(c, u, g_frames);
            uint32_t m0 = gx_bp[(u < 4 ? 0x80 : 0xA0) + (u & 3)];
            f->texwrap[u][0] = m0 & 3; f->texwrap[u][1] = (m0 >> 2) & 3; f->texlin[u] = (m0 >> 4) & 1;
        }
        if (f->tex[u]) {
            uint32_t ss = gx_bp[0x30 + 2 * s->texcoord] & 0xFFFF, ts = gx_bp[0x31 + 2 * s->texcoord] & 0xFFFF;
            if (ss) s->tsx = (float)(ss + 1) / (float)f->tex[u]->w;
            if (ts) s->tsy = (float)(ts + 1) / (float)f->tex[u]->h;
        }
    }
}

/* ---------------------------------------------------------------- vertex decode and transform */
typedef struct { int pmi, tmi[8]; float pos[3]; float col[2][4]; float tc[8][2]; } Vtx;
static const int CS[5] = { 1, 1, 2, 2, 4 };
static float rdc(const uint8_t *p, int fmt, int shift) {
    switch (fmt) {
    case 0: return (float)p[0] / (float)(1 << shift);
    case 1: return (float)(int8_t)p[0] / (float)(1 << shift);
    case 2: return (float)(uint16_t)(p[0] << 8 | p[1]) / (float)(1 << shift);
    case 3: return (float)(int16_t)(p[0] << 8 | p[1]) / (float)(1 << shift);
    default: { uint32_t u = (uint32_t)p[0] << 24 | p[1] << 16 | p[2] << 8 | p[3]; return fb(u); }
    }
}
static int color_bytes(int fmt) { static const int n[8] = { 2, 3, 4, 2, 3, 4, 0, 0 }; return n[fmt & 7]; }
static void rdcol(const uint8_t *p, int fmt, float *o) {
    float r = 1, g = 1, b = 1, a = 1; unsigned v;
    switch (fmt) {
    case 0: v = (unsigned)(p[0] << 8 | p[1]); r = ((v >> 11) & 31) / 31.f; g = ((v >> 5) & 63) / 63.f; b = (v & 31) / 31.f; break;
    case 1: case 2: r = p[0] / 255.f; g = p[1] / 255.f; b = p[2] / 255.f; break;
    case 3: v = (unsigned)(p[0] << 8 | p[1]); r = ((v >> 12) & 15) / 15.f; g = ((v >> 8) & 15) / 15.f; b = ((v >> 4) & 15) / 15.f; a = (v & 15) / 15.f; break;
    case 4: v = (unsigned)(p[0] << 16 | p[1] << 8 | p[2]); r = ((v >> 18) & 63) / 63.f; g = ((v >> 12) & 63) / 63.f; b = ((v >> 6) & 63) / 63.f; a = (v & 63) / 63.f; break;
    default: r = p[0] / 255.f; g = p[1] / 255.f; b = p[2] / 255.f; a = p[3] / 255.f; break;
    }
    o[0] = r; o[1] = g; o[2] = b; o[3] = a;
}
static const uint8_t *arr_ptr(Ctx *c, int arr, uint32_t idx) {
    return rt_ptr(c, phys_ea((gx_cp[0xA0 + arr] & 0x03FFFFFFu) + idx * (gx_cp[0xB0 + arr] & 0xFF)));
}

static void decode_vertex(Ctx *c, int vat, const uint8_t **curp, Vtx *v) {
    uint32_t lo = gx_cp[0x50], hi = gx_cp[0x60], a = gx_cp[0x70 + vat], b = gx_cp[0x80 + vat], cc = gx_cp[0x90 + vat];
    const uint8_t *cur = *curp;
    memset(v, 0, sizeof *v);
    v->pmi = (lo & 1) ? *cur++ : (int)(gx_cp[0x30] & 0x3F);
    for (int i = 0; i < 8; i++) v->tmi[i] = ((lo >> (1 + i)) & 1) ? *cur++ : i < 4 ? (int)((gx_cp[0x30] >> (6 + 6 * i)) & 0x3F) : (int)((gx_cp[0x40] >> (6 * (i - 4))) & 0x3F);
    v->col[0][0] = v->col[0][1] = v->col[0][2] = v->col[0][3] = 1.f; memcpy(v->col[1], v->col[0], sizeof v->col[1]);
    int pm = (lo >> 9) & 3;
    if (pm) {
        const uint8_t *sp = cur; int n = (a & 1) ? 3 : 2, fmt = (a >> 1) & 7, sh = (a >> 4) & 31;
        if (pm > 1) { uint32_t idx = pm == 2 ? cur[0] : (uint32_t)(cur[0] << 8 | cur[1]); cur += pm - 1; sp = arr_ptr(c, 0, idx); }
        for (int k = 0; k < n; k++) v->pos[k] = rdc(sp + k * CS[fmt > 4 ? 4 : fmt], fmt > 4 ? 4 : fmt, sh);
        if (pm == 1) cur += n * CS[fmt > 4 ? 4 : fmt];
    }
    int nm = (lo >> 11) & 3;
    if (nm) {
        int nbt = (a >> 9) & 1, fmt = (a >> 10) & 7;
        if (nm == 1) cur += (nbt ? 9 : 3) * CS[fmt > 4 ? 4 : fmt]; else cur += (nm - 1) * ((nbt && ((a >> 31) & 1)) ? 3 : 1);
    }
    for (int ch = 0; ch < 2; ch++) {
        int cm = (lo >> (13 + 2 * ch)) & 3, fmt = (int)((a >> (14 + 4 * ch)) & 7);
        if (!cm) continue;
        const uint8_t *sp = cur;
        if (cm > 1) { uint32_t idx = cm == 2 ? cur[0] : (uint32_t)(cur[0] << 8 | cur[1]); cur += cm - 1; sp = arr_ptr(c, 2 + ch, idx); }
        rdcol(sp, fmt, v->col[ch]);
        if (cm == 1) cur += color_bytes(fmt);
    }
    static const int sh_cnt[8] = { 21, 0, 9, 18, 27, 5, 14, 23 }, sh_fmt[8] = { 22, 1, 10, 19, 28, 6, 15, 24 }, sh_sh[8] = { 25, 4, 13, 22, 0, 9, 18, 27 };
    for (int i = 0; i < 8; i++) {
        int tm = (hi >> (2 * i)) & 3;
        if (!tm) continue;
        uint32_t w = i == 0 ? a : i < 5 ? b : cc, w2 = i == 0 ? a : i < 4 ? b : cc;
        int cnt = (int)((w >> sh_cnt[i]) & 1), fmt = (int)((w >> sh_fmt[i]) & 7), sh = (int)((w2 >> sh_sh[i]) & 31), n = cnt ? 2 : 1;
        if (fmt > 4) fmt = 4;
        const uint8_t *sp = cur;
        if (tm > 1) { uint32_t idx = tm == 2 ? cur[0] : (uint32_t)(cur[0] << 8 | cur[1]); cur += tm - 1; sp = arr_ptr(c, 4 + i, idx); }
        for (int k = 0; k < n; k++) v->tc[i][k] = rdc(sp + k * CS[fmt], fmt, sh);
        if (tm == 1) cur += n * CS[fmt];
    }
    *curp = cur;
}

static void mat3x4(const uint32_t *m, const float *in, float *out) {              /* out = M * (in0, in1, in2, in3) for 3 rows */
    for (int r = 0; r < 3; r++) out[r] = fb(m[r * 4]) * in[0] + fb(m[r * 4 + 1]) * in[1] + fb(m[r * 4 + 2]) * in[2] + fb(m[r * 4 + 3]) * in[3];
}
static void unpack_rgba(uint32_t v, float *o) { o[0] = (float)((v >> 24) & 255) / 255.f; o[1] = (float)((v >> 16) & 255) / 255.f; o[2] = (float)((v >> 8) & 255) / 255.f; o[3] = (float)(v & 255) / 255.f; }

static void transform(const Vtx *v, GxrVert *o, int ntg) {
    float in[4] = { v->pos[0], v->pos[1], v->pos[2], 1.f }, vw[3];
    mat3x4(&gx_xf[(v->pmi & 63) * 4], in, vw);
    float p0 = fb(gx_xf[0x1020]), p1 = fb(gx_xf[0x1021]), p2 = fb(gx_xf[0x1022]), p3 = fb(gx_xf[0x1023]), p4 = fb(gx_xf[0x1024]), p5 = fb(gx_xf[0x1025]);
    if (gx_xf[0x1026]) { o->x = p0 * vw[0] + p1; o->y = p2 * vw[1] + p3; o->z = p4 * vw[2] + p5; o->w = 1.f; }                  /* orthographic */
    else { o->x = p0 * vw[0] + p1 * vw[2]; o->y = p2 * vw[1] + p3 * vw[2]; o->z = p4 * vw[2] + p5; o->w = -vw[2]; }          /* perspective */
    /* colour channels (no lighting: lit channels use the material colour) */
    for (int ch = 0; ch < 2; ch++) {
        float mat[4]; unpack_rgba(gx_xf[0x100C + ch], mat);
        uint32_t cc = gx_xf[0x100E + ch], ac = gx_xf[0x1010 + ch];
        for (int k = 0; k < 3; k++) o->c[ch][k] = (cc & 1) ? v->col[ch][k] : mat[k];
        o->c[ch][3] = (ac & 1) ? v->col[ch][3] : mat[3];
    }
    for (int i = 0; i < 8; i++) o->t[i][0] = o->t[i][1] = 0, o->t[i][2] = 1;
    for (int i = 0; i < ntg && i < 8; i++) {
        uint32_t info = gx_xf[0x1040 + i]; int proj = info & 1, form = (info >> 1) & 1, type = (info >> 4) & 7, row = (info >> 7) & 31;
        float s[4] = { 0, 0, 1, 1 };                                               /* texgen input: geometry, a texture coordinate set, or nothing useful (normals, colours) */
        if (row == 0) { s[0] = v->pos[0]; s[1] = v->pos[1]; s[2] = form ? v->pos[2] : 1.f; }
        else if (row >= 5) { s[0] = v->tc[row - 5][0]; s[1] = v->tc[row - 5][1]; }
        float t[3] = { s[0], s[1], 1.f };
        if (type == 0) {
            float r[3]; mat3x4(&gx_xf[(v->tmi[i] & 63) * 4], s, r);
            t[0] = r[0]; t[1] = r[1]; t[2] = proj ? r[2] : 1.f;
            if (gx_xf[0x1012] & 1) {                                              /* dual-texture post transform */
                uint32_t pinfo = gx_xf[0x1050 + i]; float pin[4] = { t[0], t[1], t[2], 1.f }, pr[3];
                mat3x4(&gx_xf[0x500 + (pinfo & 63) * 4], pin, pr);
                if (pinfo & 0x100) { float l = sqrtf(pr[0] * pr[0] + pr[1] * pr[1] + pr[2] * pr[2]); if (l > 0) { pr[0] /= l; pr[1] /= l; pr[2] /= l; } }
                t[0] = pr[0]; t[1] = pr[1]; t[2] = pr[2];
            }
        }
        o->t[i][0] = t[0]; o->t[i][1] = t[1]; o->t[i][2] = t[2] != 0.f ? t[2] : 1.f;
    }
}

static GxrVert *g_vbuf, *g_tbuf; static size_t g_vcap, g_tcap;
void gxr_draw(Ctx *c, int op, const uint8_t *vd, int count) {
    if (!g_be || count <= 0) return;
    int prim = (op >> 3) & 7, vat = op & 7;
    if (prim == 1 || prim >= 5) return;                                          /* lines and points are not drawn */
    if (g_be == &gxr_soft_backend && !gxr_frame_wanted(g_frames)) return;        /* the software backend only draws frames that are dumped */
    if ((size_t)count > g_vcap) { g_vcap = (size_t)count * 2 + 64; g_vbuf = realloc(g_vbuf, g_vcap * sizeof *g_vbuf); }
    int ntg = (int)(gx_bp[0x00] & 15);
    const uint8_t *cur = vd;
    for (int i = 0; i < count; i++) { Vtx v; decode_vertex(c, vat, &cur, &v); transform(&v, &g_vbuf[i], ntg); }
    size_t ntri = prim == 0 ? (size_t)(count / 4) * 2 : prim == 2 ? (size_t)(count / 3) : count >= 3 ? (size_t)(count - 2) : 0;
    if (!ntri) return;
    if (ntri * 3 > g_tcap) { g_tcap = ntri * 3 * 2 + 96; g_tbuf = realloc(g_tbuf, g_tcap * sizeof *g_tbuf); }
    size_t n = 0;
    if (prim == 0) for (int i = 0; i + 3 < count; i += 4) { g_tbuf[n++] = g_vbuf[i]; g_tbuf[n++] = g_vbuf[i + 1]; g_tbuf[n++] = g_vbuf[i + 2]; g_tbuf[n++] = g_vbuf[i]; g_tbuf[n++] = g_vbuf[i + 2]; g_tbuf[n++] = g_vbuf[i + 3]; }
    else if (prim == 2) for (int i = 0; i + 2 < count; i += 3) { g_tbuf[n++] = g_vbuf[i]; g_tbuf[n++] = g_vbuf[i + 1]; g_tbuf[n++] = g_vbuf[i + 2]; }
    else if (prim == 3) for (int i = 0; i + 2 < count; i++) { if (i & 1) { g_tbuf[n++] = g_vbuf[i + 1]; g_tbuf[n++] = g_vbuf[i]; } else { g_tbuf[n++] = g_vbuf[i]; g_tbuf[n++] = g_vbuf[i + 1]; } g_tbuf[n++] = g_vbuf[i + 2]; }
    else if (prim == 4) for (int i = 1; i + 1 < count; i++) { g_tbuf[n++] = g_vbuf[0]; g_tbuf[n++] = g_vbuf[i]; g_tbuf[n++] = g_vbuf[i + 1]; }
    build_frag(c, &g_frag); g_frag_valid = 1;
    if (env_flipcull && (g_frag.cull == 1 || g_frag.cull == 2)) g_frag.cull = 3 - g_frag.cull;
    n_tris += n / 3;
    static int trace = -1, traced;
    if (trace < 0) trace = getenv("RT_GXR_TRACE") ? atoi(getenv("RT_GXR_TRACE")) : 0;
    if (traced < trace && g_frames >= (unsigned)(getenv("RT_GXR_TRACE_FROM") ? atoi(getenv("RT_GXR_TRACE_FROM")) : 0)) {
        traced++; const GxrFrag *f = &g_frag;
        fprintf(stderr, "[gxr-trace] frame %u draw op %02X vat %d n %d: stages %d chans %d cull %d z %d/%d/%d blend %d s%d d%d atest %d/%d %d/%d scissor %d,%d-%d,%d vp %g %g %g | %g %g %g\n",
                g_frames, op, vat, count, f->nstages, f->nchans, f->cull, f->ztest, f->zfunc, f->zupdate, f->blend, f->sfactor, f->dfactor, f->acomp0, f->aref0, f->acomp1, f->aref1,
                f->scissor[0], f->scissor[1], f->scissor[2], f->scissor[3], f->vp[0], f->vp[1], f->vp[2], f->vp[3], f->vp[4], f->vp[5]);
        { Vtx dv; const uint8_t *cur2 = vd; decode_vertex(c, vat, &cur2, &dv);
          fprintf(stderr, "    VCD %08X %08X VAT %08X %08X %08X vsize %d | first vertex: pmi %d pos %g %g %g (%zu bytes used)\n", gx_cp[0x50], gx_cp[0x60], gx_cp[0x70 + vat], gx_cp[0x80 + vat], gx_cp[0x90 + vat], gx_vtx_size(vat), dv.pmi, dv.pos[0], dv.pos[1], dv.pos[2], (size_t)(cur2 - vd));
          const uint32_t *m = &gx_xf[(dv.pmi & 63) * 4];
          fprintf(stderr, "    posmtx row0 %g %g %g %g row1 %g %g %g %g row2 %g %g %g %g\n", fb(m[0]), fb(m[1]), fb(m[2]), fb(m[3]), fb(m[4]), fb(m[5]), fb(m[6]), fb(m[7]), fb(m[8]), fb(m[9]), fb(m[10]), fb(m[11]));
          fprintf(stderr, "    proj %g %g %g %g %g %g ortho %u | vp raw %08X %08X %08X %08X %08X %08X\n", fb(gx_xf[0x1020]), fb(gx_xf[0x1021]), fb(gx_xf[0x1022]), fb(gx_xf[0x1023]), fb(gx_xf[0x1024]), fb(gx_xf[0x1025]), gx_xf[0x1026],
                  gx_xf[0x101A], gx_xf[0x101B], gx_xf[0x101C], gx_xf[0x101D], gx_xf[0x101E], gx_xf[0x101F]); }
        for (int i = 0; i < 3 && i < (int)n; i++) { const GxrVert *v = &g_tbuf[i];
            fprintf(stderr, "    v%d clip %g %g %g %g col %g %g %g %g t0 %g %g %g\n", i, v->x, v->y, v->z, v->w, v->c[0][0], v->c[0][1], v->c[0][2], v->c[0][3], v->t[0][0], v->t[0][1], v->t[0][2]); }
        for (int i = 0; i < f->nstages && i < 4; i++) { const GxrStage *t = &f->st[i];
            fprintf(stderr, "    stage %d: color abcd %d %d %d %d dest %d | alpha %d %d %d %d | tex %d coord %d en %d chan %d\n", i, t->ca, t->cb, t->cc, t->cd, t->cdest, t->aa, t->ab, t->ac, t->ad, t->texmap, t->texcoord, t->texen, t->chan); }
    }
    g_be->draw(&g_frag, g_tbuf, (int)n);
}

/* ---------------------------------------------------------------- BP: texture loads, TEV registers, EFB copies */
static void do_copy(Ctx *c, uint32_t ctrl) {
    int x = (int)(gx_bp[0x49] & 0x3FF), y = (int)((gx_bp[0x49] >> 10) & 0x3FF), w = (int)(gx_bp[0x4A] & 0x3FF) + 1, h = (int)((gx_bp[0x4A] >> 10) & 0x3FF) + 1;
    int to_xfb = (ctrl >> 14) & 1, clear = (ctrl >> 11) & 1, half = (ctrl >> 9) & 1;
    int fmt = (int)(((ctrl >> 4) & 7) | (((ctrl >> 3) & 1) << 3));
    uint32_t dest = gx_bp[0x4B] << 5, scale = gx_bp[0x4E] & 0x1FF; int stride = (int)(gx_bp[0x4D] & 0x3FF);
    if (x + w > GXR_EFB_W) w = GXR_EFB_W - x;
    if (y + h > GXR_EFB_H) h = GXR_EFB_H - y;
    if (g_be && w > 0 && h > 0) {
        if (to_xfb) {
            int oh = scale && scale != 256 ? (int)(((unsigned)h * 256u + scale / 2) / scale) : h;
            g_be->present(x, y, w, h, w, oh); n_copies_xfb++; g_frames++;
        } else if (fmt <= 10) {
            uint8_t *px = malloc((size_t)w * h * 4); g_be->read(x, y, w, h, px);
            int ow = w, oh = h;
            if (half) {                                                         /* 2x2 box filter */
                ow = w / 2; oh = h / 2; uint8_t *q = malloc((size_t)ow * oh * 4);
                for (int j = 0; j < oh; j++) for (int i = 0; i < ow; i++) for (int k = 0; k < 4; k++)
                    q[((size_t)j * ow + i) * 4 + k] = (uint8_t)((px[((size_t)(2 * j) * w + 2 * i) * 4 + k] + px[((size_t)(2 * j) * w + 2 * i + 1) * 4 + k] +
                                                                px[((size_t)(2 * j + 1) * w + 2 * i) * 4 + k] + px[((size_t)(2 * j + 1) * w + 2 * i + 1) * 4 + k] + 2) / 4);
                free(px); px = q;
            }
            if (ow > 0 && oh > 0) gxr_tex_encode(c, dest, fmt, ow, oh, px, stride);
            free(px); n_copies_tex++;
        } else n_copies_skip++;
    }
    if (clear && g_be) {
        uint32_t ar = gx_bp[0x4F], gb = gx_bp[0x50], z = gx_bp[0x51] & 0xFFFFFF;                       /* AR: red 0-7, alpha 8-15; GB: blue 0-7, green 8-15 */
        uint8_t col[4] = { (uint8_t)ar, (uint8_t)(gb >> 8), (uint8_t)gb, (uint8_t)(ar >> 8) };
        g_be->clear(x, y, w, h, (gx_bp[0x41] >> 3) & 1, (gx_bp[0x41] >> 4) & 1, (gx_bp[0x40] >> 4) & 1, col, (float)z / 16777216.f);
    }
}
void gxr_bp_write(Ctx *c, int reg, uint32_t val) {
    if (reg >= 0xE0 && reg <= 0xE7) {
        int i = (reg - 0xE0) / 2, type = (val >> 23) & 1;
        if (!(reg & 1)) { g_tevreg[type][i][0] = (int16_t)sext11(val); g_tevreg[type][i][3] = (int16_t)sext11(val >> 12); }
        else            { g_tevreg[type][i][2] = (int16_t)sext11(val); g_tevreg[type][i][1] = (int16_t)sext11(val >> 12); }
    } else if (reg == 0x65) {
        gxr_tlut_load(c, gx_bp[0x64] << 5, val & 0x3FF, ((val >> 10) & 0x7FF) * 16);
    } else if (reg == 0x52) do_copy(c, val);
}

void gxr_summary(void) {
    fprintf(stderr, "GXR: backend %s, %llu triangles, EFB copies: %llu to the display, %llu to textures (%llu in an unsupported format), %u frames\n",
            g_be ? g_be->name : "none", n_tris, n_copies_xfb, n_copies_tex, n_copies_skip, g_frames);
    if (g_be && g_be->stats) g_be->stats();
    (void)n_culled_all; (void)g_frag_valid;
}
