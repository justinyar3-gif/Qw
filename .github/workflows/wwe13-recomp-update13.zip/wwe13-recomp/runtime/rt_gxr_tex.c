/* GX textures: decoding of the console's tiled texture formats to RGBA8, palette (TLUT) memory, encoding of EFB copies into textures, and a
 * cache keyed by address / size / format that re-decodes when the pixels in guest memory change (checked once per frame).
 * Formats: 0 I4, 1 I8, 2 IA4, 3 IA8, 4 RGB565, 5 RGB5A3, 6 RGBA8, 8 C4, 9 C8, 10 C14X2, 14 CMPR. Layouts are from memory of the hardware
 * documentation / Dolphin; each was written to be self-consistent with the encoder and is unit-tested against hand-made tiles. */
#include "rt_gxr.h"
#include <stdlib.h>
#include <string.h>

static int bw(int f) { return (f == 0 || f == 8 || f == 14) ? 8 : (f == 1 || f == 2 || f == 9) ? 8 : 4; }
static int bh(int f) { return (f == 0 || f == 8 || f == 14) ? 8 : (f == 1 || f == 2 || f == 9) ? 4 : 4; }
static int bbytes(int f) { return f == 6 ? 64 : 32; }
int gxr_tex_bytes(int fmt, int w, int h) { return ((w + bw(fmt) - 1) / bw(fmt)) * ((h + bh(fmt) - 1) / bh(fmt)) * bbytes(fmt); }

static uint16_t tlut[0x80000];                                  /* palette memory, 16-bit entries, indexed by (offset << 9) / 2 + n */
void gxr_tlut_load(Ctx *c, uint32_t src, uint32_t tmem_off, uint32_t entries) {
    uint32_t base = (tmem_off << 9) >> 1;
    const uint8_t *p = rt_ptr(c, (src < 0x01800000u ? 0x80000000u | src : 0x90000000u | (src & 0x03FFFFFFu)));
    for (uint32_t i = 0; i < entries && base + i < 0x80000; i++) tlut[base + i] = (uint16_t)(p[2 * i] << 8 | p[2 * i + 1]);
}

static uint8_t e4(int v) { return (uint8_t)(v * 17); }
static uint8_t e5(int v) { return (uint8_t)((v << 3) | (v >> 2)); }
static uint8_t e6(int v) { return (uint8_t)((v << 2) | (v >> 4)); }
static uint8_t e3(int v) { return (uint8_t)((v << 5) | (v << 2) | (v >> 1)); }
static void put(uint8_t *o, int r, int g, int b, int a) { o[0] = (uint8_t)r; o[1] = (uint8_t)g; o[2] = (uint8_t)b; o[3] = (uint8_t)a; }
static void rgb565(uint8_t *o, unsigned v) { put(o, e5((v >> 11) & 31), e6((v >> 5) & 63), e5(v & 31), 255); }
static void rgb5a3(uint8_t *o, unsigned v) {
    if (v & 0x8000) put(o, e5((v >> 10) & 31), e5((v >> 5) & 31), e5(v & 31), 255);
    else put(o, e4((v >> 8) & 15), e4((v >> 4) & 15), e4(v & 15), e3((v >> 12) & 7));
}
static void tlut_color(uint8_t *o, unsigned v, int fmt) {
    if (fmt == 0) put(o, v & 255, v & 255, v & 255, v >> 8);          /* IA8: alpha in the high byte */
    else if (fmt == 1) rgb565(o, v);
    else rgb5a3(o, v);
}

void gxr_tex_decode(Ctx *c, uint32_t addr, int fmt, int w, int h, int tlut_off, int tlut_fmt, uint8_t *out) {
    const uint8_t *src = rt_ptr(c, addr < 0x01800000u ? 0x80000000u | addr : 0x90000000u | (addr & 0x03FFFFFFu));
    int tw = bw(fmt), th = bh(fmt), nbx = (w + tw - 1) / tw, nby = (h + th - 1) / th;
    uint32_t tbase = ((uint32_t)tlut_off << 9) >> 1;
    for (int by = 0; by < nby; by++) for (int bx = 0; bx < nbx; bx++) {
        const uint8_t *b = src + ((size_t)by * nbx + bx) * (size_t)bbytes(fmt);
        for (int ty = 0; ty < th; ty++) for (int tx = 0; tx < tw; tx++) {
            int x = bx * tw + tx, y = by * th + ty; if (x >= w || y >= h) continue;
            uint8_t *o = out + ((size_t)y * w + x) * 4; unsigned v;
            switch (fmt) {
            case 0: v = b[ty * 4 + tx / 2]; v = (tx & 1) ? v & 15 : v >> 4; put(o, e4(v), e4(v), e4(v), e4(v)); break;               /* I4 */
            case 1: v = b[ty * 8 + tx]; put(o, v, v, v, v); break;                                                                   /* I8 */
            case 2: v = b[ty * 8 + tx]; put(o, e4(v & 15), e4(v & 15), e4(v & 15), e4(v >> 4)); break;                               /* IA4 */
            case 3: v = b[(ty * 4 + tx) * 2]; put(o, b[(ty * 4 + tx) * 2 + 1], b[(ty * 4 + tx) * 2 + 1], b[(ty * 4 + tx) * 2 + 1], v); break;   /* IA8 */
            case 4: rgb565(o, (unsigned)(b[(ty * 4 + tx) * 2] << 8 | b[(ty * 4 + tx) * 2 + 1])); break;
            case 5: rgb5a3(o, (unsigned)(b[(ty * 4 + tx) * 2] << 8 | b[(ty * 4 + tx) * 2 + 1])); break;
            case 6: { int i = (ty * 4 + tx) * 2; put(o, b[i + 1], b[32 + i], b[32 + i + 1], b[i]); break; }                         /* AR block, then GB block */
            case 8: v = b[ty * 4 + tx / 2]; v = (tx & 1) ? v & 15 : v >> 4; tlut_color(o, tlut[(tbase + v) & 0x7FFFF], tlut_fmt); break;
            case 9: v = b[ty * 8 + tx]; tlut_color(o, tlut[(tbase + v) & 0x7FFFF], tlut_fmt); break;
            case 10: v = (unsigned)(b[(ty * 4 + tx) * 2] << 8 | b[(ty * 4 + tx) * 2 + 1]) & 0x3FFF; tlut_color(o, tlut[(tbase + v) & 0x7FFFF], tlut_fmt); break;
            case 14: {                                                                                                               /* CMPR: 2x2 sub-blocks of 4x4 */
                const uint8_t *sb = b + ((ty / 4) * 2 + (tx / 4)) * 8; int px = tx & 3, py = ty & 3;
                unsigned c0 = (unsigned)(sb[0] << 8 | sb[1]), c1 = (unsigned)(sb[2] << 8 | sb[3]); uint8_t p0[4], p1[4], pc[4];
                rgb565(p0, c0); rgb565(p1, c1);
                int idx = (sb[4 + py] >> (6 - 2 * px)) & 3;
                if (idx == 0) memcpy(pc, p0, 4); else if (idx == 1) memcpy(pc, p1, 4);
                else if (c0 > c1) { for (int k = 0; k < 3; k++) pc[k] = (uint8_t)(idx == 2 ? (2 * p0[k] + p1[k]) / 3 : (p0[k] + 2 * p1[k]) / 3); pc[3] = 255; }
                else if (idx == 2) { for (int k = 0; k < 3; k++) pc[k] = (uint8_t)((p0[k] + p1[k]) / 2); pc[3] = 255; }
                else put(pc, 0, 0, 0, 0);
                memcpy(o, pc, 4); break;
            }
            default: put(o, 255, 0, 255, 255); break;                                                                                  /* unknown format: magenta */
            }
        }
    }
}

/* ---- EFB copy -> texture. `rgba` is w x h (row 0 = top); fmt is the copy format: 0 R4, 1 Y8, 2 RA4, 3 RA8, 4 RGB565, 5 RGB5A3, 6 RGBA8, 7 A8, 8 R8, 9 G8, 10 B8 ---- */
void gxr_tex_encode(Ctx *c, uint32_t addr, int fmt, int w, int h, const uint8_t *rgba, int stride_blocks) {
    int tf = fmt == 0 ? 0 : (fmt == 1 || fmt >= 7) ? 1 : fmt == 2 ? 2 : fmt == 3 ? 3 : fmt;       /* texture format whose tile layout is used */
    int tw = bw(tf), th = bh(tf), nbx = (w + tw - 1) / tw, nby = (h + th - 1) / th;
    uint8_t *dst = rt_ptr(c, addr < 0x01800000u ? 0x80000000u | addr : 0x90000000u | (addr & 0x03FFFFFFu));
    size_t row_stride = stride_blocks ? (size_t)stride_blocks * 32 : (size_t)nbx * (size_t)bbytes(tf);
    for (int by = 0; by < nby; by++) for (int bx = 0; bx < nbx; bx++) {
        uint8_t *b = dst + (size_t)by * row_stride + (size_t)bx * (size_t)bbytes(tf);
        for (int ty = 0; ty < th; ty++) for (int tx = 0; tx < tw; tx++) {
            int x = bx * tw + tx, y = by * th + ty;
            if (x >= w) x = w - 1;
            if (y >= h) y = h - 1;
            const uint8_t *p = rgba + ((size_t)y * w + x) * 4; int r = p[0], g = p[1], bl = p[2], a = p[3];
            int yv = (int)(0.257f * r + 0.504f * g + 0.098f * bl + 16.f + 0.5f); if (yv > 255) yv = 255;
            int i8 = fmt == 1 ? yv : fmt == 7 ? a : fmt == 8 ? r : fmt == 9 ? g : fmt == 10 ? bl : r;
            switch (tf) {
            case 0: { int v = (i8 >> 4) & 15; uint8_t *q = &b[ty * 4 + tx / 2]; *q = (tx & 1) ? (uint8_t)((*q & 0xF0) | v) : (uint8_t)((*q & 0x0F) | (v << 4)); break; }
            case 1: b[ty * 8 + tx] = (uint8_t)i8; break;
            case 2: b[ty * 8 + tx] = (uint8_t)(((a >> 4) << 4) | (r >> 4)); break;
            case 3: b[(ty * 4 + tx) * 2] = (uint8_t)a; b[(ty * 4 + tx) * 2 + 1] = (uint8_t)r; break;
            case 4: { unsigned v = (unsigned)(((r >> 3) << 11) | ((g >> 2) << 5) | (bl >> 3)); b[(ty * 4 + tx) * 2] = (uint8_t)(v >> 8); b[(ty * 4 + tx) * 2 + 1] = (uint8_t)v; break; }
            case 5: {
                unsigned v = a >= 224 ? (unsigned)(0x8000 | ((r >> 3) << 10) | ((g >> 3) << 5) | (bl >> 3)) : (unsigned)(((a >> 5) << 12) | ((r >> 4) << 8) | ((g >> 4) << 4) | (bl >> 4));
                b[(ty * 4 + tx) * 2] = (uint8_t)(v >> 8); b[(ty * 4 + tx) * 2 + 1] = (uint8_t)v; break;
            }
            case 6: { int i = (ty * 4 + tx) * 2; b[i] = (uint8_t)a; b[i + 1] = (uint8_t)r; b[32 + i] = (uint8_t)g; b[32 + i + 1] = (uint8_t)bl; break; }
            default: break;
            }
        }
    }
}

/* ---- cache ---- */
static GxrTex *g_tex;
static uint64_t hash_bytes(const uint8_t *p, size_t n) {
    uint64_t h = 1469598103934665603ull; size_t i = 0;
    for (; i + 8 <= n; i += 8) { uint64_t v; memcpy(&v, p + i, 8); h = (h ^ v) * 1099511628211ull; h ^= h >> 29; }
    for (; i < n; i++) h = (h ^ p[i]) * 1099511628211ull;
    return h;
}
GxrTex *gxr_tex_get(Ctx *c, int unit, uint32_t frame) {
    uint32_t i0 = gx_bp[(unit < 4 ? 0x88 : 0xA8) + (unit & 3)], i3 = gx_bp[(unit < 4 ? 0x94 : 0xB4) + (unit & 3)], tl = gx_bp[(unit < 4 ? 0x98 : 0xB8) + (unit & 3)];
    int w = (int)(i0 & 0x3FF) + 1, h = (int)((i0 >> 10) & 0x3FF) + 1, fmt = (int)((i0 >> 20) & 15);
    uint32_t addr = (i3 & 0xFFFFFF) << 5; int ci = fmt == 8 || fmt == 9 || fmt == 10;
    int toff = ci ? (int)(tl & 0x3FF) : 0, tfmt = ci ? (int)((tl >> 10) & 3) : 0;
    if (!addr || fmt == 7 || fmt == 11 || fmt == 12 || fmt == 13 || fmt == 15) return NULL;
    GxrTex *t;
    for (t = g_tex; t; t = t->next) if (t->addr == addr && t->w == w && t->h == h && t->fmt == fmt && t->tlut_off == toff && t->tlut_fmt == tfmt) break;
    const uint8_t *src = rt_ptr(c, addr < 0x01800000u ? 0x80000000u | addr : 0x90000000u | (addr & 0x03FFFFFFu));
    if (t && t->frame_checked == frame) return t;
    uint64_t hs = hash_bytes(src, (size_t)gxr_tex_bytes(fmt, w, h));
    if (ci) { uint32_t b = ((uint32_t)toff << 9) >> 1; hs ^= hash_bytes((const uint8_t *)&tlut[b & 0x7FFFF], fmt == 8 ? 32 : 512) * 31; }
    uint32_t hv = (uint32_t)(hs ^ (hs >> 32));
    if (!t) {
        t = calloc(1, sizeof *t); t->addr = addr; t->w = w; t->h = h; t->fmt = fmt; t->tlut_off = toff; t->tlut_fmt = tfmt;
        t->rgba = malloc((size_t)w * h * 4); t->next = g_tex; g_tex = t; t->hash = hv + 1;
    }
    if (t->hash != hv) { gxr_tex_decode(c, addr, fmt, w, h, toff, tfmt, t->rgba); t->hash = hv; t->gen++; }
    t->frame_checked = frame;
    return t;
}
