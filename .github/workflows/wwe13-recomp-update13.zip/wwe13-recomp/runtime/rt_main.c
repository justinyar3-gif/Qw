/* boot main.dol [timeout_s=10] [trace_n=48] [--mmio-log] [--header header.bin] [--disc extracted_folder [--disc-fst]] [--aspect 16x9|4x3] [--no-pad] [--render soft|gles|off] */
#include "rt.h"
#include "rt_input.h"
#include "rt_gxr.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
Ctx *rt_ctx_new(void);
uint32_t rt_load_dol(Ctx *c, const char *path);
void rt_init_lowmem(Ctx *c);
int rt_run(Ctx *c, uint32_t entry, int timeout_s, int trace_n);
extern int rt_mmio_log;
void rt_log_list(const char *list);
int rt_di_open(const char *root, int use_fst);
void rt_di_boot(Ctx *c);
int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: %s main.dol [timeout_s] [trace_n] [--mmio-log]\n", argv[0]); return 1; }
    int timeout = argc > 2 && argv[2][0] != '-' ? atoi(argv[2]) : 10;
    int trace_n = argc > 3 && argv[3][0] != '-' ? atoi(argv[3]) : 48;
    for (int i = 2; i < argc; i++) if (!strcmp(argv[i], "--mmio-log")) rt_mmio_log = 1;
    for (int i = 2; i < argc; i++) if (!strcmp(argv[i], "--aspect")) {       /* console aspect-ratio setting: 16x9 (default, HD asset set) or 4x3 (SD set) */
        const char *v = i + 1 < argc ? argv[i + 1] : "";
        if (!strcmp(v, "16x9")) rt_sc_widescreen = 1;
        else if (!strcmp(v, "4x3")) rt_sc_widescreen = 0;
        else { fprintf(stderr, "--aspect expects 16x9 or 4x3\n"); return 1; }
    }
    {                                                                        /* graphics: --render soft (software rasterizer), or RT_GX_RENDER / RT_FRAME_DUMP in the environment */
        const char *rm = getenv("RT_GX_RENDER");
        for (int i = 2; i + 1 < argc; i++) if (!strcmp(argv[i], "--render")) rm = argv[i + 1];
        if (!rm && getenv("RT_FRAME_DUMP")) rm = "soft";
        if (rm && !strcmp(rm, "soft")) gxr_set_backend(&gxr_soft_backend);
        else if (rm && !strcmp(rm, "gles")) gxr_set_backend(&gxr_gles_backend);       /* OpenGL ES 3 (headless on a PC: RT_GL_HEADLESS=1 with Mesa) */
        else if (rm && strcmp(rm, "off")) { fprintf(stderr, "--render expects soft, gles or off\n"); return 1; }
    }
    rt_pad_init_from_env();                                                  /* RT_PAD_SCRIPT="A:300:10,..." presses buttons; RT_NO_PAD / --no-pad = no controller */
    for (int i = 2; i < argc; i++) if (!strcmp(argv[i], "--no-pad")) rt_pad_enable(0, 0);
    if (getenv("RT_CHECK_ZERO")) rt_chk_addr = (uint32_t)strtoul(getenv("RT_CHECK_ZERO"), 0, 16);
    if (getenv("RT_WATCH_MASK")) rt_watch_mask = (uint32_t)strtoul(getenv("RT_WATCH_MASK"), 0, 16);
    if (getenv("RT_WATCH")) rt_watch_addr = (uint32_t)strtoul(getenv("RT_WATCH"), 0, 16);
    if (getenv("RT_LOG_AT")) { rt_log_addr = (uint32_t)strtoul(getenv("RT_LOG_AT"), 0, 16); rt_log_list(getenv("RT_LOG_AT")); }   /* comma list allowed */
    if (getenv("RT_BREAK")) rt_break_addr = (uint32_t)strtoul(getenv("RT_BREAK"), 0, 16);
    Ctx *c = rt_ctx_new();
    uint32_t entry = rt_load_dol(c, argv[1]);
    rt_init_lowmem(c);
    for (int i = 2; i + 1 < argc; i++) {
        if (!strcmp(argv[i], "--disc")) {                /* extracted disc folder (sys/ + files/): serves /dev/di and provides the FST */
            int use_fst = 0; for (int k = 2; k < argc; k++) if (!strcmp(argv[k], "--disc-fst")) use_fst = 1;
            if (rt_di_open(argv[i + 1], use_fst)) return 2;
            rt_di_boot(c);
        }
    }
    for (int i = 2; i + 1 < argc; i++) {
        if (!strcmp(argv[i], "--header")) {              /* first 0x20 bytes of the disc header (game ID, maker, version, disc magic) */
            FILE *h = fopen(argv[i + 1], "rb"); uint8_t hb[0x20] = {0};
            if (!h || fread(hb, 1, sizeof hb, h) < 0x20) { fprintf(stderr, "cannot read 0x20 bytes from %s\n", argv[i + 1]); return 2; }
            fclose(h);
            for (uint32_t k = 0; k < 0x20; k++) rt_w8(c, 0x80000000u + k, hb[k]);
            for (uint32_t k = 0; k < 4; k++) rt_w8(c, 0x80003180u + k, hb[k]);     /* game ID copy (address from memory, unverified) */
            fprintf(stderr, "disc header: game ID %.6s\n", (char *)hb);
        }
    }
    fprintf(stderr, "loaded %s, entry 0x%08X\n", argv[1], entry);
    return rt_run(c, entry, timeout, trace_n);
}
