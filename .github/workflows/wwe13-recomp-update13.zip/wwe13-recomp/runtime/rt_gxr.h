/* GX renderer front end: turns the decoded GX command stream (rt_gx.c) into triangles with a fixed-function state snapshot,
 * and hands them to a backend (software rasterizer: rt_gxr_soft.c, OpenGL ES 3: rt_gxr_gles.c).
 *
 * Everything here follows the GX register layouts as I remember them from the SDK / Dolphin; none of it has been checked against a
 * real console. The boot is the test: what the game draws is compared by eye (RT_FRAME_DUMP). */
#ifndef RT_GXR_H
#define RT_GXR_H
#include "rt.h"

#define GXR_EFB_W 640
#define GXR_EFB_H 528

/* One transformed vertex. x,y,z,w are GX clip-space coordinates (perspective: w = -z_view; z_ndc = z/w is in [-1, 0]). */
typedef struct { float x, y, z, w; float c[2][4]; float t[8][3]; } GxrVert;

/* A decoded texture (always RGBA8, row-major). `gen` changes whenever the pixels change. */
typedef struct GxrTex { uint32_t addr, gen; int w, h, fmt, tlut_off, tlut_fmt; uint8_t *rgba; uint32_t hash, frame_checked; struct GxrTex *next; void *backend; } GxrTex;

typedef struct {
    int ca, cb, cc, cd, cbias, csub, cclamp, cscale, cdest;       /* colour combiner (selectors as in the BP register) */
    int aa, ab, ac, ad, abias, asub, aclamp, ascale, adest;       /* alpha combiner */
    int texmap, texcoord, texen, chan;                            /* order: which texture / coordinate set / colour channel feeds the stage */
    int kc, ka;                                                   /* constant colour / alpha selects */
    int rswap, tswap;                                             /* swap table numbers for the rasterized and the texture colour */
    float tsx, tsy;                                               /* texture coordinate scale relative to the texture size (normally 1) */
} GxrStage;

/* Everything the fragment stage and the blender need for one draw. */
typedef struct {
    int nstages, nchans;
    GxrStage st[16];
    uint8_t swap[4][4];                                           /* swap tables: output component n takes input component swap[t][n] */
    int16_t reg[4][4];                                            /* TEV registers PREV, C0, C1, C2 as r,g,b,a (signed 11-bit) */
    int16_t konst[4][4];                                          /* constant colours K0..K3 */
    int acomp0, acomp1, alogic, aref0, aref1;                     /* alpha test */
    int ztest, zfunc, zupdate;
    int blend, sfactor, dfactor, bsub, logic, logicop, color_update, alpha_update;
    int cull;                                                     /* 0 none, 1 back, 2 front, 3 all */
    int scissor[4];                                               /* x0, y0, x1, y1 (exclusive) in EFB pixels */
    GxrTex *tex[8];
    uint8_t texwrap[8][2], texlin[8];                             /* wrap s/t: 0 clamp, 1 repeat, 2 mirror; 1 = bilinear */
    float vp[6];                                                  /* viewport: screen = ndc * (vp[0], vp[1], vp[2]) + (vp[3], vp[4], vp[5]); z in 0..2^24 (the SDK writes 2^24 as the z scale and offset) */
    int chan_mat_vertex[2], chan_light[2];                        /* colour channel setup: material from vertex, lighting on */
    uint8_t chan_matreg[2][4], chan_ambreg[2][4];                 /* material / ambient register colours */
} GxrFrag;

typedef struct {
    const char *name;
    void (*draw)(const GxrFrag *f, const GxrVert *v, int nv);                           /* triangle list */
    void (*clear)(int x, int y, int w, int h, int color, int alpha, int z, const uint8_t rgba[4], float zval);   /* clear the enabled planes of an EFB rectangle (zval: 0..1) */
    void (*read)(int x, int y, int w, int h, uint8_t *rgba);                            /* read EFB colour, row 0 = top */
    void (*present)(int x, int y, int w, int h, int outw, int outh);                    /* EFB copy to the display: show this region */
    void (*flush)(void);
    void (*stats)(void);                                                                /* optional: print counters at exit */
} GxrBackend;

extern uint32_t gx_cp[256], gx_bp[256], gx_xf[0x1100];
void gxr_set_backend(const GxrBackend *b);                                              /* NULL = decode only (draws counted, nothing drawn) */
const GxrBackend *gxr_backend(void);
void gxr_set_ctx(Ctx *c);                                                               /* guest context of the writer (diagnostics only) */
void gxr_xf_write(uint32_t addr, uint32_t v);
void gxr_xf_load_indexed(Ctx *c, int op, uint32_t w);
void gxr_bp_write(Ctx *c, int reg, uint32_t val);                                       /* after the masked write; handles texture loads and EFB copies */
void gxr_draw(Ctx *c, int op, const uint8_t *vd, int count);                            /* op = draw command byte, vd = vertex data */
void gxr_summary(void);
uint32_t gxr_frames(void);

/* texture helpers (rt_gxr_tex.c) */
int gxr_tex_bytes(int fmt, int w, int h);
void gxr_tex_decode(Ctx *c, uint32_t addr, int fmt, int w, int h, int tlut_off, int tlut_fmt, uint8_t *out);
void gxr_tlut_load(Ctx *c, uint32_t src, uint32_t tmem_off, uint32_t entries);
void gxr_tex_encode(Ctx *c, uint32_t addr, int fmt, int w, int h, const uint8_t *rgba, int stride_blocks);
GxrTex *gxr_tex_get(Ctx *c, int unit, uint32_t frame);
int gx_vtx_size(int vat);                                                               /* bytes per vertex for an attribute table (rt_gx.c) */
void gxr_frame_sink(const uint8_t *rgba, int w, int h);                                 /* a finished frame: PNG dump (RT_FRAME_DUMP) and/or display */

/* backends */
extern const GxrBackend gxr_soft_backend;
const uint8_t *gxr_soft_efb(void);
int gxr_frame_wanted(unsigned n);                                                       /* will frame n be dumped? (software backend skips the others) */
void gxr_soft_stats(void);
int gxr_frame_dump_wanted(unsigned n);                                                  /* is frame n written as a PNG (RT_FRAME_DUMP)? backends read the picture back only then */
/* OpenGL ES 3 backend (rt_gxr_gles.c) */
extern const GxrBackend gxr_gles_backend;
int gxr_gles_start(void);                                                               /* creates the EGL context on the calling thread; 0 = not available */
void gxr_gles_set_window(void *anativewindow);                                          /* Android: where to show the picture (NULL = nowhere); any thread */
void gxr_gles_stats(void);
int gxr_png_write(const char *path, int w, int h, const uint8_t *rgba);
#endif
