/* Controller input: a virtual Classic Controller on Wii Remote slot 1 (channel 0).
 *
 * The game reads pads through the SDK's KPAD library (KPADReadEx at 0x80674DC0 is called once per frame for each of the four channels).
 * The Wii Remote itself is not emulated (no Bluetooth HID link), so that one function is replaced: it fills the game's KPADStatus buffer from
 * the state set here. The state comes from the touch screen on Android (rt_android.c), from the RT_PAD_SCRIPT environment variable, or stays
 * "nothing pressed". Button bits are the SDK's WPAD_BUTTON_CL_* / KPAD_BUTTON_CL_* values (also the inverted wire layout of the controller). */
#ifndef RT_INPUT_H
#define RT_INPUT_H
#include "rt.h"

#define RT_PAD_CHANNELS 4
enum {
    RT_CL_UP = 0x0001, RT_CL_LEFT = 0x0002, RT_CL_ZR = 0x0004, RT_CL_X = 0x0008, RT_CL_A = 0x0010, RT_CL_Y = 0x0020, RT_CL_B = 0x0040,
    RT_CL_ZL = 0x0080, RT_CL_R = 0x0200, RT_CL_PLUS = 0x0400, RT_CL_HOME = 0x0800, RT_CL_MINUS = 0x1000, RT_CL_L = 0x2000,
    RT_CL_DOWN = 0x4000, RT_CL_RIGHT = 0x8000
};
typedef struct {
    uint16_t buttons;            /* RT_CL_* bits */
    float lx, ly, rx, ry;        /* sticks, -1..1 (x right, y up) */
    float lt, rt;                /* analog triggers, 0..1 */
} rt_pad_state;

void rt_pad_set(int chan, const rt_pad_state *s);       /* any thread; values are quantized to 8 bits */
void rt_pad_get(int chan, rt_pad_state *s);
void rt_pad_enable(int chan, int on);                    /* channel 0 is on by default, 1..3 are off ("no controller") */
int rt_pad_enabled(int chan);
int rt_pad_parse_script(const char *spec);               /* "A:300:10,PLUS+B:500:5" = name[+name]:first_read:reads on channel 0; returns entries, -1 = syntax error */
void rt_pad_init_from_env(void);                         /* RT_PAD_SCRIPT, RT_NO_PAD */
void rt_pad_summary(void);                               /* one line to stderr: reads per channel, samples with buttons held, new presses */
void rt_hle_kpad_read_ex(Ctx *c);                        /* replaces KPADReadEx(chan, KPADStatus *buf, count, s32 *err): returns the sample count in r3 */
#endif
