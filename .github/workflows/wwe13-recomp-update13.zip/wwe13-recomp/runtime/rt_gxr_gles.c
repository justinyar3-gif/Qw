/* OpenGL ES 3.0 backend for the GX renderer (rt_gxr.c): the EFB is a 640x528 RGBA8 texture + 24 bit depth renderbuffer behind an FBO, every draw is one
 * glDrawArrays with the whole TEV pipeline in an uber shader (the stage setup is passed as uniforms), blending / depth / scissor / colour masks are GL state.
 *
 * GX clip space is mapped to GL clip space per vertex with one multiply-add each, so clipping, perspective correct interpolation and depth stay with the GPU:
 *     GX clip volume is -w <= z <= 0           ->  gl.z = 2 z + w  (so GL's near/far planes are GX's), glDepthRange = the viewport's z range
 *     screen x = x/w * vp0 + vp3 (EFB pixels)  ->  gl.x = x * 2 vp0 / W + w * (2 vp3 / W - 1)
 *     screen y = y/w * vp1 + vp4, row 0 on top ->  gl.y = y * 2 vp1 / H + w * (2 vp4 / H - 1)      (FBO row 0 = EFB row 0 = top; read-back needs no flip)
 * Face culling is done on the CPU (same sign convention as the software backend). Logic ops are not implemented (drawn without blending).
 *
 * No GL / EGL headers are needed: types, constants and prototypes are declared below and everything is resolved at run time (libEGL + eglGetProcAddress),
 * which is also how it works on Android. gxr_gles_start() makes its own EGL context (pbuffer, or the window given to gxr_gles_set_window) on the calling
 * thread: call it on the thread that renders (the guest thread). Tested here against the software backend with Mesa (llvmpipe, surfaceless EGL);
 * NOT tested on a phone. */
#include "rt_gxr.h"
#include <dlfcn.h>
#include <math.h>
#include <stdatomic.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern int rt_sc_widescreen;

/* ---------------------------------------------------------------- minimal GL / EGL declarations */
typedef unsigned int GLuint, GLenum, GLbitfield; typedef int GLint, GLsizei; typedef unsigned char GLboolean; typedef float GLfloat; typedef char GLchar; typedef long GLsizeiptr;
#define GL_TRIANGLES 4
#define GL_COLOR_BUFFER_BIT 0x4000
#define GL_DEPTH_BUFFER_BIT 0x100
#define GL_DEPTH_TEST 0xB71
#define GL_BLEND 0xBE2
#define GL_SCISSOR_TEST 0xC11
#define GL_TEXTURE_2D 0xDE1
#define GL_TEXTURE0 0x84C0
#define GL_FLOAT 0x1406
#define GL_UNSIGNED_BYTE 0x1401
#define GL_RGBA 0x1908
#define GL_RGBA8 0x8058
#define GL_ARRAY_BUFFER 0x8892
#define GL_STREAM_DRAW 0x88E0
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_VERTEX_SHADER 0x8B31
#define GL_COMPILE_STATUS 0x8B81
#define GL_LINK_STATUS 0x8B82
#define GL_INFO_LOG_LENGTH 0x8B84
#define GL_FRAMEBUFFER 0x8D40
#define GL_RENDERBUFFER 0x8D41
#define GL_COLOR_ATTACHMENT0 0x8CE0
#define GL_DEPTH_ATTACHMENT 0x8D00
#define GL_DEPTH_COMPONENT24 0x81A6
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#define GL_TEXTURE_MIN_FILTER 0x2801
#define GL_TEXTURE_MAG_FILTER 0x2800
#define GL_TEXTURE_WRAP_S 0x2802
#define GL_TEXTURE_WRAP_T 0x2803
#define GL_NEAREST 0x2600
#define GL_LINEAR 0x2601
#define GL_CLAMP_TO_EDGE 0x812F
#define GL_REPEAT 0x2901
#define GL_MIRRORED_REPEAT 0x8370
#define GL_FUNC_ADD 0x8006
#define GL_FUNC_REVERSE_SUBTRACT 0x800B
#define GL_PACK_ALIGNMENT 0xD05
#define GL_UNPACK_ALIGNMENT 0xCF5
#define GL_VERSION 0x1F02
#define GL_RENDERER 0x1F01

#define GLFUNCS(X) \
    X(GLenum, glGetError, (void)) X(const GLchar *, glGetString, (GLenum)) \
    X(GLuint, glCreateShader, (GLenum)) X(void, glShaderSource, (GLuint, GLsizei, const GLchar *const *, const GLint *)) X(void, glCompileShader, (GLuint)) \
    X(void, glGetShaderiv, (GLuint, GLenum, GLint *)) X(void, glGetShaderInfoLog, (GLuint, GLsizei, GLsizei *, GLchar *)) \
    X(GLuint, glCreateProgram, (void)) X(void, glAttachShader, (GLuint, GLuint)) X(void, glLinkProgram, (GLuint)) X(void, glUseProgram, (GLuint)) \
    X(void, glGetProgramiv, (GLuint, GLenum, GLint *)) X(void, glGetProgramInfoLog, (GLuint, GLsizei, GLsizei *, GLchar *)) X(GLint, glGetUniformLocation, (GLuint, const GLchar *)) \
    X(void, glUniform1i, (GLint, GLint)) X(void, glUniform1iv, (GLint, GLsizei, const GLint *)) X(void, glUniform2iv, (GLint, GLsizei, const GLint *)) \
    X(void, glUniform4iv, (GLint, GLsizei, const GLint *)) X(void, glUniform2fv, (GLint, GLsizei, const GLfloat *)) X(void, glUniform4fv, (GLint, GLsizei, const GLfloat *)) \
    X(void, glUniform4f, (GLint, GLfloat, GLfloat, GLfloat, GLfloat)) \
    X(void, glGenBuffers, (GLsizei, GLuint *)) X(void, glBindBuffer, (GLenum, GLuint)) X(void, glBufferData, (GLenum, GLsizeiptr, const void *, GLenum)) \
    X(void, glEnableVertexAttribArray, (GLuint)) X(void, glVertexAttribPointer, (GLuint, GLint, GLenum, GLboolean, GLsizei, const void *)) \
    X(void, glGenVertexArrays, (GLsizei, GLuint *)) X(void, glBindVertexArray, (GLuint)) X(void, glDrawArrays, (GLenum, GLint, GLsizei)) \
    X(void, glGenTextures, (GLsizei, GLuint *)) X(void, glBindTexture, (GLenum, GLuint)) X(void, glActiveTexture, (GLenum)) \
    X(void, glTexImage2D, (GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void *)) X(void, glTexParameteri, (GLenum, GLenum, GLint)) \
    X(void, glGenFramebuffers, (GLsizei, GLuint *)) X(void, glBindFramebuffer, (GLenum, GLuint)) X(void, glFramebufferTexture2D, (GLenum, GLenum, GLenum, GLuint, GLint)) \
    X(void, glGenRenderbuffers, (GLsizei, GLuint *)) X(void, glBindRenderbuffer, (GLenum, GLuint)) X(void, glRenderbufferStorage, (GLenum, GLenum, GLsizei, GLsizei)) \
    X(void, glFramebufferRenderbuffer, (GLenum, GLenum, GLenum, GLuint)) X(GLenum, glCheckFramebufferStatus, (GLenum)) \
    X(void, glViewport, (GLint, GLint, GLsizei, GLsizei)) X(void, glScissor, (GLint, GLint, GLsizei, GLsizei)) X(void, glEnable, (GLenum)) X(void, glDisable, (GLenum)) \
    X(void, glColorMask, (GLboolean, GLboolean, GLboolean, GLboolean)) X(void, glDepthMask, (GLboolean)) X(void, glDepthFunc, (GLenum)) X(void, glDepthRangef, (GLfloat, GLfloat)) \
    X(void, glClearColor, (GLfloat, GLfloat, GLfloat, GLfloat)) X(void, glClearDepthf, (GLfloat)) X(void, glClear, (GLbitfield)) \
    X(void, glBlendFuncSeparate, (GLenum, GLenum, GLenum, GLenum)) X(void, glBlendEquationSeparate, (GLenum, GLenum)) \
    X(void, glReadPixels, (GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, void *)) X(void, glPixelStorei, (GLenum, GLint)) X(void, glFlush, (void))
#define X(ret, name, args) static ret (*name) args;
GLFUNCS(X)
#undef X

typedef void *EGLDisplay, *EGLConfig, *EGLContext, *EGLSurface; typedef int EGLint; typedef unsigned int EGLBoolean, EGLenum;
#define EGL_NO_SURFACE ((EGLSurface)0)
#define EGL_NO_CONTEXT ((EGLContext)0)
#define EGL_NO_DISPLAY ((EGLDisplay)0)
#define EGL_OPENGL_ES_API 0x30A0
#define EGL_SURFACE_TYPE 0x3033
#define EGL_WINDOW_BIT 4
#define EGL_PBUFFER_BIT 1
#define EGL_RENDERABLE_TYPE 0x3040
#define EGL_OPENGL_ES3_BIT 0x40
#define EGL_RED_SIZE 0x3024
#define EGL_GREEN_SIZE 0x3023
#define EGL_BLUE_SIZE 0x3022
#define EGL_ALPHA_SIZE 0x3021
#define EGL_DEPTH_SIZE 0x3025
#define EGL_NONE 0x3038
#define EGL_CONTEXT_CLIENT_VERSION 0x3098
#define EGL_WIDTH 0x3057
#define EGL_HEIGHT 0x3056
#define EGL_PLATFORM_SURFACELESS_MESA 0x31DD
static void *(*eglGetProcAddress)(const char *);
static EGLDisplay (*eglGetDisplay)(void *);
static EGLDisplay (*eglGetPlatformDisplayEXT)(EGLenum, void *, const EGLint *);
static EGLBoolean (*eglInitialize)(EGLDisplay, EGLint *, EGLint *);
static EGLBoolean (*eglBindAPI)(EGLenum);
static EGLBoolean (*eglChooseConfig)(EGLDisplay, const EGLint *, EGLConfig *, EGLint, EGLint *);
static EGLContext (*eglCreateContext)(EGLDisplay, EGLConfig, EGLContext, const EGLint *);
static EGLSurface (*eglCreatePbufferSurface)(EGLDisplay, EGLConfig, const EGLint *);
static EGLSurface (*eglCreateWindowSurface)(EGLDisplay, EGLConfig, void *, const EGLint *);
static EGLBoolean (*eglDestroySurface)(EGLDisplay, EGLSurface);
static EGLBoolean (*eglMakeCurrent)(EGLDisplay, EGLSurface, EGLSurface, EGLContext);
static EGLBoolean (*eglSwapBuffers)(EGLDisplay, EGLSurface);
static EGLBoolean (*eglSwapInterval)(EGLDisplay, EGLint);
static EGLBoolean (*eglQuerySurface)(EGLDisplay, EGLSurface, EGLint, EGLint *);
static EGLint (*eglGetError)(void);

static EGLDisplay g_dpy; static EGLConfig g_cfg; static EGLContext g_ctx; static EGLSurface g_pbuf, g_win;
static _Atomic(void *) g_want_window; static atomic_uint g_window_gen; static unsigned g_cur_gen; static int g_started, g_failed, g_have_window_cfg;

/* ---------------------------------------------------------------- shaders */
static const char *VS =
    "#version 300 es\n"
    "layout(location=0) in vec4 a_pos; layout(location=1) in vec4 a_c0; layout(location=2) in vec4 a_c1;\n"
    "layout(location=3) in vec3 a_t0; layout(location=4) in vec3 a_t1; layout(location=5) in vec3 a_t2; layout(location=6) in vec3 a_t3;\n"
    "layout(location=7) in vec3 a_t4; layout(location=8) in vec3 a_t5; layout(location=9) in vec3 a_t6; layout(location=10) in vec3 a_t7;\n"
    "uniform vec4 u_xy;   /* (sx, bx, sy, by): gl.x = x*sx + w*bx, gl.y = y*sy + w*by */\n"
    "out vec4 v_c0; out vec4 v_c1; out vec3 v_t[8];\n"
    "void main() {\n"
    "  gl_Position = vec4(a_pos.x * u_xy.x + a_pos.w * u_xy.y, a_pos.y * u_xy.z + a_pos.w * u_xy.w, 2.0 * a_pos.z + a_pos.w, a_pos.w);\n"
    "  v_c0 = a_c0; v_c1 = a_c1;\n"
    "  v_t[0] = a_t0; v_t[1] = a_t1; v_t[2] = a_t2; v_t[3] = a_t3; v_t[4] = a_t4; v_t[5] = a_t5; v_t[6] = a_t6; v_t[7] = a_t7;\n"
    "}\n";

static const char *FS =
    "#version 300 es\n"
    "precision highp float; precision highp int;\n"
    "in vec4 v_c0; in vec4 v_c1; in vec3 v_t[8];\n"
    "uniform int u_n; uniform int u_hastex;\n"
    "uniform ivec4 u_cabcd[16]; uniform ivec4 u_cmisc[16];   /* a b c d | bias sub clamp scale */\n"
    "uniform ivec4 u_aabcd[16]; uniform ivec4 u_amisc[16];\n"
    "uniform ivec4 u_ord[16];    /* texmap texcoord texen chan */\n"
    "uniform ivec4 u_dst[16];    /* cdest adest rswap tswap */\n"
    "uniform ivec2 u_ks[16];     /* kc ka */\n"
    "uniform vec2 u_ts[16];      /* texcoord scale */\n"
    "uniform ivec4 u_swap[4];\n"
    "uniform vec4 u_reg[4]; uniform vec4 u_konst[4];\n"
    "uniform ivec4 u_at; uniform int u_alogic;   /* comp0 ref0 comp1 ref1 */\n"
    "uniform sampler2D u_tex0; uniform sampler2D u_tex1; uniform sampler2D u_tex2; uniform sampler2D u_tex3;\n"
    "uniform sampler2D u_tex4; uniform sampler2D u_tex5; uniform sampler2D u_tex6; uniform sampler2D u_tex7;\n"
    "out vec4 o_color;\n"
    "vec4 fetch(int u, vec2 uv) {\n"
    "  if (u == 0) return texture(u_tex0, uv); if (u == 1) return texture(u_tex1, uv); if (u == 2) return texture(u_tex2, uv); if (u == 3) return texture(u_tex3, uv);\n"
    "  if (u == 4) return texture(u_tex4, uv); if (u == 5) return texture(u_tex5, uv); if (u == 6) return texture(u_tex6, uv); return texture(u_tex7, uv);\n"
    "}\n"
    "float konst(int sel, int comp, bool alpha) {\n"
    "  if (sel < 8) { float k[8] = float[8](1.0, 0.875, 0.75, 0.625, 0.5, 0.375, 0.25, 0.125); return k[sel]; }\n"
    "  if (!alpha && sel >= 12 && sel <= 15) return u_konst[sel - 12][comp];\n"
    "  if (sel >= 16 && sel <= 31) return u_konst[(sel - 16) & 3][(sel - 16) >> 2];\n"
    "  return 1.0;\n"
    "}\n"
    "float bias_of(int b) { return b == 1 ? 0.5 : (b == 2 ? -0.5 : 0.0); }\n"
    "float scale_of(int s) { return s == 0 ? 1.0 : (s == 1 ? 2.0 : (s == 2 ? 4.0 : 0.5)); }\n"
    "bool cmpf(int f, int a, int b) {\n"
    "  if (f == 0) return false; if (f == 1) return a < b; if (f == 2) return a == b; if (f == 3) return a <= b;\n"
    "  if (f == 4) return a > b; if (f == 5) return a != b; if (f == 6) return a >= b; return true;\n"
    "}\n"
    "float pick(vec4 v, int i) { return i == 0 ? v.x : (i == 1 ? v.y : (i == 2 ? v.z : v.w)); }\n"
    "vec4 swz(vec4 v, ivec4 s) { return vec4(pick(v, s.x), pick(v, s.y), pick(v, s.z), pick(v, s.w)); }\n"
    "void main() {\n"
    "  vec4 reg[4] = vec4[4](u_reg[0], u_reg[1], u_reg[2], u_reg[3]);\n"
    "  vec4 col[2] = vec4[2](v_c0, v_c1);\n"
    "  vec3 tc[8] = vec3[8](v_t[0], v_t[1], v_t[2], v_t[3], v_t[4], v_t[5], v_t[6], v_t[7]);\n"
    "  for (int i = 0; i < 16; i++) {\n"
    "    if (i >= u_n) break;\n"
    "    ivec4 ord = u_ord[i]; ivec4 dst = u_dst[i];\n"
    "    vec4 ras = vec4(0.0), tex = vec4(0.0);\n"
    "    if (ord.w == 0 || ord.w == 1) ras = swz(col[ord.w], u_swap[dst.z]);\n"
    "    if (ord.z != 0 && ((u_hastex >> ord.x) & 1) != 0) {\n"
    "      vec3 q = tc[ord.y]; vec2 uv = q.xy / (q.z != 0.0 ? q.z : 1.0) * u_ts[i];\n"
    "      tex = swz(fetch(ord.x, uv), u_swap[dst.w]);\n"
    "    }\n"
    "    vec3 cin[16];\n"
    "    cin[0] = reg[0].rgb; cin[1] = vec3(reg[0].a); cin[2] = reg[1].rgb; cin[3] = vec3(reg[1].a); cin[4] = reg[2].rgb; cin[5] = vec3(reg[2].a);\n"
    "    cin[6] = reg[3].rgb; cin[7] = vec3(reg[3].a); cin[8] = tex.rgb; cin[9] = vec3(tex.a); cin[10] = ras.rgb; cin[11] = vec3(ras.a);\n"
    "    cin[12] = vec3(1.0); cin[13] = vec3(0.5);\n"
    "    cin[14] = vec3(konst(u_ks[i].x, 0, false), konst(u_ks[i].x, 1, false), konst(u_ks[i].x, 2, false)); cin[15] = vec3(0.0);\n"
    "    ivec4 cs = u_cabcd[i]; ivec4 cm = u_cmisc[i];\n"
    "    vec3 a = cin[cs.x], b = cin[cs.y], c = cin[cs.z], d = cin[cs.w];\n"
    "    vec3 v = mix(a, b, c);\n"
    "    v = (cm.y != 0 ? d - v : d + v) + bias_of(cm.x); v *= scale_of(cm.w);\n"
    "    vec4 res; res.rgb = cm.z != 0 ? clamp(v, 0.0, 1.0) : clamp(v, -4.0, 4.0);\n"
    "    float ain[8] = float[8](reg[0].a, reg[1].a, reg[2].a, reg[3].a, tex.a, ras.a, konst(u_ks[i].y, 3, true), 0.0);\n"
    "    ivec4 as = u_aabcd[i]; ivec4 am = u_amisc[i];\n"
    "    float av = mix(ain[as.x], ain[as.y], ain[as.z]);\n"
    "    av = (am.y != 0 ? ain[as.w] - av : ain[as.w] + av) + bias_of(am.x); av *= scale_of(am.w);\n"
    "    res.a = am.z != 0 ? clamp(av, 0.0, 1.0) : clamp(av, -4.0, 4.0);\n"
    "    int cd = dst.x & 3, ad = dst.y & 3;\n"
    "    reg[cd].rgb = res.rgb; reg[ad].a = res.a;\n"
    "  }\n"
    "  vec4 o = clamp(reg[0], 0.0, 1.0);\n"
    "  int av8 = int(floor(o.a * 255.0 + 0.5));\n"
    "  bool r0 = cmpf(u_at.x, av8, u_at.y), r1 = cmpf(u_at.z, av8, u_at.w);\n"
    "  bool pass = u_alogic == 0 ? (r0 && r1) : (u_alogic == 1 ? (r0 || r1) : (u_alogic == 2 ? (r0 != r1) : (r0 == r1)));\n"
    "  if (!pass) discard;\n"
    "  o_color = o;\n"
    "}\n";

static const char *PVS =
    "#version 300 es\n"
    "uniform vec4 u_rect; uniform vec4 u_uv;   /* gl rect (x0,y0,x1,y1) in ndc, texture rect (u0,v0,u1,v1) */\n"
    "out vec2 v_uv;\n"
    "void main() {\n"
    "  vec2 p = vec2((gl_VertexID & 1) == 0 ? 0.0 : 1.0, (gl_VertexID & 2) == 0 ? 0.0 : 1.0);\n"
    "  gl_Position = vec4(mix(u_rect.xy, u_rect.zw, p), 0.0, 1.0); v_uv = mix(u_uv.xy, u_uv.zw, vec2(p.x, 1.0 - p.y));\n"
    "}\n";
static const char *PFS =
    "#version 300 es\nprecision highp float; in vec2 v_uv; uniform sampler2D u_src; out vec4 o_color;\n"
    "void main() { o_color = vec4(texture(u_src, v_uv).rgb, 1.0); }\n";

/* ---------------------------------------------------------------- state */
static GLuint g_prog, g_pprog, g_vbo, g_vao, g_efb_tex, g_efb_rb, g_fbo, g_dummy_tex;
static struct { GLint n, hastex, cabcd, cmisc, aabcd, amisc, ord, dst, ks, ts, swap, reg, konst, at, alogic, tex[8], xy; } U;
static struct { GLint rect, uv, src; } PU;
static GxrVert *g_batch; static size_t g_batch_cap;
typedef struct { GLuint id; uint32_t gen; int minf, magf, ws, wt; } GlTex;
static unsigned long long n_draws, n_tris_drawn, n_swaps; static int g_win_w, g_win_h;

static void *sym(const char *name) {
    void *p = eglGetProcAddress ? eglGetProcAddress(name) : NULL;
    if (!p) { static void *h; if (!h) { h = dlopen("libGLESv2.so.2", RTLD_NOW | RTLD_GLOBAL); if (!h) h = dlopen("libGLESv2.so", RTLD_NOW | RTLD_GLOBAL); } if (h) p = dlsym(h, name); }
    return p;
}
static GLuint compile(GLenum type, const char *src) {
    GLuint s = glCreateShader(type); glShaderSource(s, 1, &src, NULL); glCompileShader(s);
    GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { char log[2048] = ""; glGetShaderInfoLog(s, sizeof log, NULL, log); fprintf(stderr, "[gles] shader compile failed:\n%s\n", log); return 0; }
    return s;
}
static GLuint link_prog(const char *vs, const char *fs) {
    GLuint v = compile(GL_VERTEX_SHADER, vs), f = compile(GL_FRAGMENT_SHADER, fs); if (!v || !f) return 0;
    GLuint p = glCreateProgram(); glAttachShader(p, v); glAttachShader(p, f); glLinkProgram(p);
    GLint ok = 0; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) { char log[2048] = ""; glGetProgramInfoLog(p, sizeof log, NULL, log); fprintf(stderr, "[gles] program link failed:\n%s\n", log); return 0; }
    return p;
}

/* ---------------------------------------------------------------- EGL */
static int load_egl(void) {
    static void *h;
    if (!h) { h = dlopen("libEGL.so.1", RTLD_NOW | RTLD_GLOBAL); if (!h) h = dlopen("libEGL.so", RTLD_NOW | RTLD_GLOBAL); }
    if (!h) { fprintf(stderr, "[gles] no libEGL\n"); return 0; }
#define E(n) do { *(void **)&n = dlsym(h, #n); if (!n) { fprintf(stderr, "[gles] libEGL lacks " #n "\n"); return 0; } } while (0)
    E(eglGetProcAddress); E(eglGetDisplay); E(eglInitialize); E(eglBindAPI); E(eglChooseConfig); E(eglCreateContext); E(eglCreatePbufferSurface);
    E(eglCreateWindowSurface); E(eglDestroySurface); E(eglMakeCurrent); E(eglSwapBuffers); E(eglSwapInterval); E(eglQuerySurface); E(eglGetError);
#undef E
    *(void **)&eglGetPlatformDisplayEXT = eglGetProcAddress("eglGetPlatformDisplayEXT");
    return 1;
}
static int egl_setup(void) {
    if (!load_egl()) return 0;
    int headless = getenv("RT_GL_HEADLESS") != NULL;                            /* Mesa surfaceless platform: no display server needed */
    if (headless && eglGetPlatformDisplayEXT) g_dpy = eglGetPlatformDisplayEXT(EGL_PLATFORM_SURFACELESS_MESA, NULL, NULL);
    else g_dpy = eglGetDisplay(NULL);
    EGLint maj, min;
    if (!g_dpy || !eglInitialize(g_dpy, &maj, &min)) { fprintf(stderr, "[gles] eglInitialize failed (0x%X)\n", eglGetError()); return 0; }
    eglBindAPI(EGL_OPENGL_ES_API);
    EGLint nc = 0;
    EGLint a1[] = { EGL_SURFACE_TYPE, EGL_WINDOW_BIT | EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_NONE };
    EGLint a2[] = { EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_NONE };
    if (eglChooseConfig(g_dpy, a1, &g_cfg, 1, &nc) && nc > 0) g_have_window_cfg = 1;
    else if (!(eglChooseConfig(g_dpy, a2, &g_cfg, 1, &nc) && nc > 0)) { fprintf(stderr, "[gles] no suitable EGL config (0x%X)\n", eglGetError()); return 0; }
    EGLint ca[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    g_ctx = eglCreateContext(g_dpy, g_cfg, EGL_NO_CONTEXT, ca);
    if (!g_ctx) { fprintf(stderr, "[gles] eglCreateContext failed (0x%X)\n", eglGetError()); return 0; }
    EGLint pa[] = { EGL_WIDTH, 16, EGL_HEIGHT, 16, EGL_NONE };
    g_pbuf = eglCreatePbufferSurface(g_dpy, g_cfg, pa);
    if (!eglMakeCurrent(g_dpy, g_pbuf ? g_pbuf : EGL_NO_SURFACE, g_pbuf ? g_pbuf : EGL_NO_SURFACE, g_ctx)) { fprintf(stderr, "[gles] eglMakeCurrent failed (0x%X)\n", eglGetError()); return 0; }
    return 1;
}
static void drop_window(void) {
    if (!g_win) return;
    eglMakeCurrent(g_dpy, g_pbuf, g_pbuf, g_ctx); eglDestroySurface(g_dpy, g_win); g_win = EGL_NO_SURFACE;
}
static void update_window(void) {                                                 /* follow gxr_gles_set_window (Android surfaces come and go) */
    unsigned gen = atomic_load(&g_window_gen);
    if (gen == g_cur_gen) return;
    g_cur_gen = gen;
    drop_window();
    void *w = atomic_load(&g_want_window);
    if (w && g_have_window_cfg) {
        g_win = eglCreateWindowSurface(g_dpy, g_cfg, w, NULL);
        if (g_win && eglMakeCurrent(g_dpy, g_win, g_win, g_ctx)) { const char *v = getenv("RT_GL_VSYNC"); eglSwapInterval(g_dpy, v ? atoi(v) : 1); }
        else { fprintf(stderr, "[gles] could not use the window surface (0x%X)\n", eglGetError()); drop_window(); }
    }
}
void gxr_gles_set_window(void *native_window) { atomic_store(&g_want_window, native_window); atomic_fetch_add(&g_window_gen, 1); }

/* ---------------------------------------------------------------- resources */
static int gl_setup(void) {
#define X(ret, name, args) *(void **)&name = sym(#name); if (!name) { fprintf(stderr, "[gles] missing GL function " #name "\n"); return 0; }
    GLFUNCS(X)
#undef X
    fprintf(stderr, "[gles] %s / %s\n", glGetString(GL_RENDERER), glGetString(GL_VERSION));
    g_prog = link_prog(VS, FS); g_pprog = link_prog(PVS, PFS); if (!g_prog || !g_pprog) return 0;
#define UL(f, n) U.f = glGetUniformLocation(g_prog, n)
    UL(n, "u_n"); UL(hastex, "u_hastex"); UL(cabcd, "u_cabcd"); UL(cmisc, "u_cmisc"); UL(aabcd, "u_aabcd"); UL(amisc, "u_amisc"); UL(ord, "u_ord"); UL(dst, "u_dst"); UL(ks, "u_ks");
    UL(ts, "u_ts"); UL(swap, "u_swap"); UL(reg, "u_reg"); UL(konst, "u_konst"); UL(at, "u_at"); UL(alogic, "u_alogic"); UL(xy, "u_xy");
#undef UL
    for (int i = 0; i < 8; i++) { char n[16]; snprintf(n, sizeof n, "u_tex%d", i); U.tex[i] = glGetUniformLocation(g_prog, n); }
    PU.rect = glGetUniformLocation(g_pprog, "u_rect"); PU.uv = glGetUniformLocation(g_pprog, "u_uv"); PU.src = glGetUniformLocation(g_pprog, "u_src");

    glGenVertexArrays(1, &g_vao); glBindVertexArray(g_vao); glGenBuffers(1, &g_vbo); glBindBuffer(GL_ARRAY_BUFFER, g_vbo);
    const size_t S = sizeof(GxrVert);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 4, GL_FLOAT, 0, (GLsizei)S, (void *)offsetof(GxrVert, x));
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 4, GL_FLOAT, 0, (GLsizei)S, (void *)offsetof(GxrVert, c[0]));
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 4, GL_FLOAT, 0, (GLsizei)S, (void *)offsetof(GxrVert, c[1]));
    for (int i = 0; i < 8; i++) { glEnableVertexAttribArray(3 + i); glVertexAttribPointer(3 + i, 3, GL_FLOAT, 0, (GLsizei)S, (void *)(offsetof(GxrVert, t) + 12 * (size_t)i)); }

    glGenTextures(1, &g_efb_tex); glBindTexture(GL_TEXTURE_2D, g_efb_tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, GXR_EFB_W, GXR_EFB_H, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);     /* only sampled to show the picture */
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenRenderbuffers(1, &g_efb_rb); glBindRenderbuffer(GL_RENDERBUFFER, g_efb_rb); glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, GXR_EFB_W, GXR_EFB_H);
    glGenFramebuffers(1, &g_fbo); glBindFramebuffer(GL_FRAMEBUFFER, g_fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, g_efb_tex, 0);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, g_efb_rb);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) { fprintf(stderr, "[gles] the EFB framebuffer is incomplete\n"); return 0; }
    glGenTextures(1, &g_dummy_tex); glBindTexture(GL_TEXTURE_2D, g_dummy_tex);
    { static const uint8_t white[4] = { 255, 255, 255, 255 }; glPixelStorei(GL_UNPACK_ALIGNMENT, 1); glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, white); }
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    /* the EFB starts black, like the console's */
    glDisable(GL_SCISSOR_TEST); glColorMask(1, 1, 1, 1); glDepthMask(1); glClearColor(0, 0, 0, 0); glClearDepthf(1.f); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    return 1;
}

/* ---------------------------------------------------------------- backend */
static GLenum zfunc_gl(int f) { static const GLenum t[8] = { 0x200, 0x201, 0x202, 0x203, 0x204, 0x205, 0x206, 0x207 }; return t[f & 7]; }
static GLenum src_factor(int f) { static const GLenum t[8] = { 0, 1, 0x306, 0x307, 0x302, 0x303, 0x304, 0x305 }; return t[f & 7]; }   /* zero one dstclr invdstclr srca invsrca dsta invdsta */
static GLenum dst_factor(int f) { static const GLenum t[8] = { 0, 1, 0x300, 0x301, 0x302, 0x303, 0x304, 0x305 }; return t[f & 7]; }   /* zero one srcclr invsrcclr srca invsrca dsta invdsta */

static void bind_tex(const GxrFrag *f, int u) {
    glActiveTexture(GL_TEXTURE0 + (GLenum)u);
    GxrTex *t = f->tex[u];
    if (!t) { glBindTexture(GL_TEXTURE_2D, g_dummy_tex); return; }
    GlTex *g = t->backend;
    if (!g) { g = calloc(1, sizeof *g); t->backend = g; glGenTextures(1, &g->id); g->gen = 0xFFFFFFFFu; g->minf = g->magf = g->ws = g->wt = -1; }
    glBindTexture(GL_TEXTURE_2D, g->id);
    if (g->gen != t->gen) { glPixelStorei(GL_UNPACK_ALIGNMENT, 1); glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, t->w, t->h, 0, GL_RGBA, GL_UNSIGNED_BYTE, t->rgba); g->gen = t->gen; }
    int filt = f->texlin[u] ? GL_LINEAR : GL_NEAREST;
    static const GLint wr[3] = { GL_CLAMP_TO_EDGE, GL_REPEAT, GL_MIRRORED_REPEAT };
    int ws = wr[f->texwrap[u][0] > 2 ? 0 : f->texwrap[u][0]], wt = wr[f->texwrap[u][1] > 2 ? 0 : f->texwrap[u][1]];
    if (g->minf != filt) { glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filt); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filt); g->minf = filt; }
    if (g->ws != ws) { glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, ws); g->ws = ws; }
    if (g->wt != wt) { glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wt); g->wt = wt; }
}

static void set_uniforms(const GxrFrag *f) {
    GLint cabcd[16][4] = {{0}}, cmisc[16][4] = {{0}}, aabcd[16][4] = {{0}}, amisc[16][4] = {{0}}, ord[16][4] = {{0}}, dst[16][4] = {{0}}, ks[16][2] = {{0}}, swp[4][4];
    GLfloat ts[16][2], reg[4][4], kon[4][4];
    for (int i = 0; i < 16; i++) { ts[i][0] = ts[i][1] = 1.f; }
    int hastex = 0;
    for (int i = 0; i < f->nstages && i < 16; i++) {
        const GxrStage *s = &f->st[i];
        cabcd[i][0] = s->ca; cabcd[i][1] = s->cb; cabcd[i][2] = s->cc; cabcd[i][3] = s->cd; cmisc[i][0] = s->cbias; cmisc[i][1] = s->csub; cmisc[i][2] = s->cclamp; cmisc[i][3] = s->cscale;
        aabcd[i][0] = s->aa; aabcd[i][1] = s->ab; aabcd[i][2] = s->ac; aabcd[i][3] = s->ad; amisc[i][0] = s->abias; amisc[i][1] = s->asub; amisc[i][2] = s->aclamp; amisc[i][3] = s->ascale;
        ord[i][0] = s->texmap & 7; ord[i][1] = s->texcoord & 7; ord[i][2] = s->texen; ord[i][3] = s->chan;
        dst[i][0] = s->cdest; dst[i][1] = s->adest; dst[i][2] = s->rswap & 3; dst[i][3] = s->tswap & 3; ks[i][0] = s->kc; ks[i][1] = s->ka; ts[i][0] = s->tsx; ts[i][1] = s->tsy;
    }
    for (int u = 0; u < 8; u++) if (f->tex[u]) hastex |= 1 << u;
    for (int t = 0; t < 4; t++) for (int k = 0; k < 4; k++) swp[t][k] = f->swap[t][k] & 3;
    for (int r = 0; r < 4; r++) for (int k = 0; k < 4; k++) { reg[r][k] = f->reg[r][k] / 255.f; kon[r][k] = f->konst[r][k] / 255.f; }
    glUniform1i(U.n, f->nstages); glUniform1i(U.hastex, hastex);
    glUniform4iv(U.cabcd, 16, &cabcd[0][0]); glUniform4iv(U.cmisc, 16, &cmisc[0][0]); glUniform4iv(U.aabcd, 16, &aabcd[0][0]); glUniform4iv(U.amisc, 16, &amisc[0][0]);
    glUniform4iv(U.ord, 16, &ord[0][0]); glUniform4iv(U.dst, 16, &dst[0][0]); glUniform2iv(U.ks, 16, &ks[0][0]); glUniform2fv(U.ts, 16, &ts[0][0]);
    glUniform4iv(U.swap, 4, &swp[0][0]); glUniform4fv(U.reg, 4, &reg[0][0]); glUniform4fv(U.konst, 4, &kon[0][0]);
    glUniform4iv(U.at, 1, (GLint[4]){ f->acomp0, f->aref0, f->acomp1, f->aref1 }); glUniform1i(U.alogic, f->alogic);
    for (int u = 0; u < 8; u++) glUniform1i(U.tex[u], u);
}

static void impl_draw(const GxrFrag *f, const GxrVert *v, int nv) {
    if (nv < 3) return;
    int sx0 = f->scissor[0], sy0 = f->scissor[1], sx1 = f->scissor[2], sy1 = f->scissor[3];
    if (sx1 <= sx0 || sy1 <= sy0) return;
    if (!g_batch || (size_t)nv > g_batch_cap) { g_batch_cap = (size_t)nv * 2 + 96; g_batch = realloc(g_batch, g_batch_cap * sizeof *g_batch); }
    size_t n = 0;
    for (int i = 0; i + 2 < nv; i += 3) {                                           /* CPU face culling, same convention as the software backend */
        const GxrVert *a = &v[i], *b = &v[i + 1], *c = &v[i + 2];
        if (f->cull) {
            if (f->cull == 3) continue;
            double det = (double)a->x * ((double)b->y * c->w - (double)c->y * b->w) - (double)a->y * ((double)b->x * c->w - (double)c->x * b->w) + (double)a->w * ((double)b->x * c->y - (double)c->x * b->y);
            double sgn = (a->w > 0 && b->w > 0 && c->w > 0) ? 1.0 : 0.0;           /* with a vertex behind the eye the sign is ambiguous: do not cull */
            double area = det * sgn * ((double)f->vp[0] * f->vp[1] > 0 ? 1.0 : -1.0);
            if (f->cull == 1 && area < 0) continue;
            if (f->cull == 2 && area > 0) continue;
        }
        g_batch[n++] = *a; g_batch[n++] = *b; g_batch[n++] = *c;
    }
    if (!n) return;
    update_window();
    glBindFramebuffer(GL_FRAMEBUFFER, g_fbo); glViewport(0, 0, GXR_EFB_W, GXR_EFB_H);
    glUseProgram(g_prog); glBindVertexArray(g_vao);
    for (int u = 0; u < 8; u++) bind_tex(f, u);
    set_uniforms(f);
    const float W = (float)GXR_EFB_W, H = (float)GXR_EFB_H;
    glUniform4f(U.xy, 2.f * f->vp[0] / W, 2.f * f->vp[3] / W - 1.f, 2.f * f->vp[1] / H, 2.f * f->vp[4] / H - 1.f);
    glEnable(GL_SCISSOR_TEST); glScissor(sx0, sy0, sx1 - sx0, sy1 - sy0);
    float zn = (f->vp[5] - f->vp[2]) / 16777216.f, zf = f->vp[5] / 16777216.f; if (zn < 0) zn = 0; if (zf > 1) zf = 1;
    glDepthRangef(zn, zf);
    if (f->ztest) { glEnable(GL_DEPTH_TEST); glDepthFunc(zfunc_gl(f->zfunc)); glDepthMask(f->zupdate ? 1 : 0); } else { glDisable(GL_DEPTH_TEST); glDepthMask(0); }
    glColorMask(f->color_update ? 1 : 0, f->color_update ? 1 : 0, f->color_update ? 1 : 0, f->alpha_update ? 1 : 0);
    if (f->blend && !f->logic) {
        glEnable(GL_BLEND);
        GLenum sf = src_factor(f->sfactor), df = dst_factor(f->dfactor);
        glBlendFuncSeparate(sf, df, sf, df);
        glBlendEquationSeparate(f->bsub ? GL_FUNC_REVERSE_SUBTRACT : GL_FUNC_ADD, f->bsub ? GL_FUNC_REVERSE_SUBTRACT : GL_FUNC_ADD);
    } else glDisable(GL_BLEND);
    glBindBuffer(GL_ARRAY_BUFFER, g_vbo);
    glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(n * sizeof(GxrVert)), g_batch, GL_STREAM_DRAW);
    glDrawArrays(GL_TRIANGLES, 0, (GLsizei)n);
    n_draws++; n_tris_drawn += n / 3;
    glActiveTexture(GL_TEXTURE0);
}

static void impl_clear(int x, int y, int w, int h, int color, int alpha, int z, const uint8_t rgba[4], float zval) {
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > GXR_EFB_W) w = GXR_EFB_W - x;
    if (y + h > GXR_EFB_H) h = GXR_EFB_H - y;
    if (w <= 0 || h <= 0 || (!color && !alpha && !z)) return;
    glBindFramebuffer(GL_FRAMEBUFFER, g_fbo); glEnable(GL_SCISSOR_TEST); glScissor(x, y, w, h);
    glColorMask(color ? 1 : 0, color ? 1 : 0, color ? 1 : 0, alpha ? 1 : 0); glDepthMask(z ? 1 : 0);
    glClearColor(rgba[0] / 255.f, rgba[1] / 255.f, rgba[2] / 255.f, rgba[3] / 255.f); glClearDepthf(zval);
    glClear((GLbitfield)((color || alpha ? GL_COLOR_BUFFER_BIT : 0) | (z ? GL_DEPTH_BUFFER_BIT : 0)));
    glColorMask(1, 1, 1, 1); glDepthMask(1);
}
static void impl_read(int x, int y, int w, int h, uint8_t *out) {
    glBindFramebuffer(GL_FRAMEBUFFER, g_fbo); glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(x, y, w, h, GL_RGBA, GL_UNSIGNED_BYTE, out);
}
/* The picture is shown fitted into the window (4:3 or 16:9 as the console's aspect-ratio setting says). */
static void impl_present(int x, int y, int w, int h) {
    update_window();
    if (!g_win) return;
    EGLint ww = 0, wh = 0; eglQuerySurface(g_dpy, g_win, EGL_WIDTH, &ww); eglQuerySurface(g_dpy, g_win, EGL_HEIGHT, &wh);
    if (ww <= 0 || wh <= 0) return;
    g_win_w = ww; g_win_h = wh;
    float aspect = rt_sc_widescreen ? 16.f / 9.f : 4.f / 3.f, wa = (float)ww / (float)wh, sx = 1.f, sy = 1.f;
    if (wa > aspect) sx = aspect / wa; else sy = wa / aspect;
    glBindFramebuffer(GL_FRAMEBUFFER, 0); glViewport(0, 0, ww, wh);
    glDisable(GL_SCISSOR_TEST); glDisable(GL_DEPTH_TEST); glDisable(GL_BLEND); glColorMask(1, 1, 1, 1);
    glClearColor(0, 0, 0, 1); glClear(GL_COLOR_BUFFER_BIT);
    glUseProgram(g_pprog); glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, g_efb_tex); glUniform1i(PU.src, 0);
    glUniform4f(PU.rect, -sx, -sy, sx, sy);
    glUniform4f(PU.uv, (float)x / GXR_EFB_W, (float)y / GXR_EFB_H, (float)(x + w) / GXR_EFB_W, (float)(y + h) / GXR_EFB_H);
    glBindVertexArray(0);                                                       /* the quad comes from gl_VertexID: no vertex arrays */
    glDrawArrays(0x0005 /* GL_TRIANGLE_STRIP */, 0, 4);
    if (eglSwapBuffers(g_dpy, g_win)) n_swaps++;
    else { fprintf(stderr, "[gles] eglSwapBuffers failed (0x%X): the window is gone\n", eglGetError()); drop_window(); }       /* until the app hands over a new surface */
}
static void impl_flush(void) { glFlush(); }

/* ---------------------------------------------------------------- the GL thread
 * An EGL context belongs to one thread, but the guest's threads (host threads that run one at a time) may all issue graphics. So every GL call runs on a
 * thread of its own and the caller waits for it: a synchronous call costs one wake-up each way. */
#include <pthread.h>
static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER; static pthread_cond_t g_cv = PTHREAD_COND_INITIALIZER;
static void (*g_job)(void *); static void *g_job_arg; static int g_job_state;         /* 0 idle, 1 posted, 2 finished */
static pthread_t g_gl_thread;
static void *gl_thread_main(void *unused) {
    (void)unused;
    pthread_mutex_lock(&g_mu);
    for (;;) {
        while (g_job_state != 1) pthread_cond_wait(&g_cv, &g_mu);
        void (*fn)(void *) = g_job; void *arg = g_job_arg;
        pthread_mutex_unlock(&g_mu); fn(arg); pthread_mutex_lock(&g_mu);
        g_job_state = 2; pthread_cond_broadcast(&g_cv);
    }
    return NULL;
}
static pthread_mutex_t g_call_mu = PTHREAD_MUTEX_INITIALIZER;                    /* one caller at a time */
static void run_gl(void (*fn)(void *), void *arg) {
    pthread_mutex_lock(&g_call_mu); pthread_mutex_lock(&g_mu);
    g_job = fn; g_job_arg = arg; g_job_state = 1; pthread_cond_broadcast(&g_cv);
    while (g_job_state != 2) pthread_cond_wait(&g_cv, &g_mu);
    g_job_state = 0; pthread_mutex_unlock(&g_mu); pthread_mutex_unlock(&g_call_mu);
}
static void job_start(void *r) { *(int *)r = egl_setup() && gl_setup(); if (*(int *)r) update_window(); }

/* Starts the GL thread, creates the context there and everything else. Returns 0 if OpenGL ES 3 is not available (the caller then falls back to another backend). */
int gxr_gles_start(void) {
    if (g_started) return !g_failed;
    g_started = 1;
    int ok = 0;
    if (pthread_create(&g_gl_thread, NULL, gl_thread_main, NULL) == 0) run_gl(job_start, &ok);
    if (!ok) { g_failed = 1; fprintf(stderr, "[gles] OpenGL ES 3 backend is not available\n"); return 0; }
    return 1;
}
static int ensure(void) { return g_started ? !g_failed : gxr_gles_start(); }

typedef struct { const GxrFrag *f; const GxrVert *v; int nv; } DrawArgs;
typedef struct { int x, y, w, h, color, alpha, z; const uint8_t *rgba; float zval; } ClearArgs;
typedef struct { int x, y, w, h; uint8_t *out; } ReadArgs;
static void job_draw(void *p) { DrawArgs *a = p; impl_draw(a->f, a->v, a->nv); }
static void job_clear(void *p) { ClearArgs *a = p; impl_clear(a->x, a->y, a->w, a->h, a->color, a->alpha, a->z, a->rgba, a->zval); }
static void job_read(void *p) { ReadArgs *a = p; impl_read(a->x, a->y, a->w, a->h, a->out); }
static void job_present(void *p) { ReadArgs *a = p; impl_present(a->x, a->y, a->w, a->h); }
static void job_flush(void *p) { (void)p; impl_flush(); }

static void be_draw(const GxrFrag *f, const GxrVert *v, int nv) {
    if (!ensure()) return;
    DrawArgs a = { f, v, nv }; run_gl(job_draw, &a);
}
static void be_clear(int x, int y, int w, int h, int color, int alpha, int z, const uint8_t rgba[4], float zval) {
    if (!ensure()) return;
    ClearArgs a = { x, y, w, h, color, alpha, z, rgba, zval }; run_gl(job_clear, &a);
}
static void be_read(int x, int y, int w, int h, uint8_t *out) {
    if (!ensure()) { memset(out, 0, (size_t)w * h * 4); return; }
    ReadArgs a = { x, y, w, h, out }; run_gl(job_read, &a);
}
static void be_present(int x, int y, int w, int h, int outw, int outh) {
    if (!ensure()) return;
    ReadArgs a = { x, y, w, h, NULL }; run_gl(job_present, &a);
    if (gxr_frame_dump_wanted(gxr_frames())) {                                  /* a PNG was asked for: read the picture back and scale it to the size the game displays */
        uint8_t *src = malloc((size_t)w * h * 4), *o = malloc((size_t)outw * outh * 4);
        be_read(x, y, w, h, src);
        for (int j = 0; j < outh; j++) for (int i = 0; i < outw; i++) {
            const uint8_t *p = &src[((size_t)((long)j * h / outh) * w + (size_t)((long)i * w / outw)) * 4]; uint8_t *q = &o[((size_t)j * outw + i) * 4];
            q[0] = p[0]; q[1] = p[1]; q[2] = p[2]; q[3] = 255;
        }
        gxr_frame_sink(o, outw, outh); free(src); free(o);
    }
}
static void be_flush(void) { if (g_started && !g_failed) run_gl(job_flush, NULL); }
void gxr_gles_stats(void) { fprintf(stderr, "GXR gles: %llu draws, %llu triangles, %llu swaps\n", n_draws, n_tris_drawn, n_swaps); }
const GxrBackend gxr_gles_backend = { "opengles3", be_draw, be_clear, be_read, be_present, be_flush, gxr_gles_stats };
