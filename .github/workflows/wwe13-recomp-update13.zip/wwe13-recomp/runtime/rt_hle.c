/* Reusable high-level emulation helpers for SDK routines. */
#include "rt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* PowerPC EABI varargs: integers in r3..r10, doubles in f1..f8, the rest on the stack at r1+8. */
typedef struct { Ctx *c; int gpr, fpr; uint32_t stack; } Va;
static uint32_t va_int(Va *v) {
    if (v->gpr <= 10) return v->c->r[v->gpr++];
    uint32_t x = rt_r32(v->c, v->stack); v->stack += 4; return x;
}
static uint64_t va_int64(Va *v) {
    if (v->gpr <= 10) {
        if (v->gpr % 2 == 0) v->gpr++;                       /* 64-bit values start on an odd register */
        if (v->gpr <= 9) { uint64_t hi = v->c->r[v->gpr], lo = v->c->r[v->gpr + 1]; v->gpr += 2; return hi << 32 | lo; }
        v->gpr = 11;
    }
    v->stack = (v->stack + 7) & ~7u;
    uint64_t x = rt_r64(v->c, v->stack); v->stack += 8; return x;
}
static double va_dbl(Va *v) {
    if (v->fpr <= 8) return v->c->ps[v->fpr++][0];
    v->stack = (v->stack + 7) & ~7u;
    double d = rt_u2d(rt_r64(v->c, v->stack)); v->stack += 8; return d;
}
static void guest_str(Ctx *c, uint32_t a, char *out, size_t n) {
    size_t i = 0;
    if (a) for (; i + 1 < n; i++) { out[i] = (char)rt_r8(c, a + (uint32_t)i); if (!out[i]) break; }
    out[i] = 0;
}

/* Formats the guest printf string at `fmt` into out. First variadic integer register is `first_gpr`. */
void rt_guest_format(Ctx *c, uint32_t fmt, int first_gpr, char *out, size_t cap) {
    Va v = { c, first_gpr, 1, c->r[1] + 8 };
    char f[512]; guest_str(c, fmt, f, sizeof f);
    size_t o = 0;
    for (const char *p = f; *p && o + 64 < cap; ) {
        if (*p != '%') { out[o++] = *p++; continue; }
        char spec[32]; int n = 0; spec[n++] = *p++;
        while (*p && strchr("-+ #0", *p)) spec[n++] = *p++;
        if (*p == '*') { n += snprintf(spec + n, 12, "%d", (int)va_int(&v)); p++; }
        else while (*p >= '0' && *p <= '9') spec[n++] = *p++;
        if (*p == '.') { spec[n++] = *p++; if (*p == '*') { n += snprintf(spec + n, 12, "%d", (int)va_int(&v)); p++; }
                         else while (*p >= '0' && *p <= '9') spec[n++] = *p++; }
        int ll = 0, h = 0;
        while (*p == 'l' || *p == 'h') { if (*p == 'l') ll++; else h++; p++; }
        char conv = *p ? *p++ : 0;
        spec[n] = 0;
        char tmp[300];
        switch (conv) {
        case '%': tmp[0] = '%'; tmp[1] = 0; break;
        case 'd': case 'i': { strcat(spec, ll > 1 ? "lld" : "d");
            if (ll > 1) snprintf(tmp, sizeof tmp, spec, (long long)va_int64(&v)); else snprintf(tmp, sizeof tmp, spec, (int)va_int(&v)); break; }
        case 'u': case 'x': case 'X': case 'o': { char s2[3] = { ll > 1 ? 'l' : conv, ll > 1 ? 'l' : 0, 0 };
            strcat(spec, ll > 1 ? "ll" : ""); size_t l = strlen(spec); spec[l] = conv; spec[l + 1] = 0; (void)s2;
            if (ll > 1) snprintf(tmp, sizeof tmp, spec, (unsigned long long)va_int64(&v)); else snprintf(tmp, sizeof tmp, spec, va_int(&v)); break; }
        case 'c': strcat(spec, "c"); snprintf(tmp, sizeof tmp, spec, (int)va_int(&v)); break;
        case 'p': snprintf(tmp, sizeof tmp, "0x%08X", va_int(&v)); break;
        case 's': { char s[256]; guest_str(c, va_int(&v), s, sizeof s); strcat(spec, "s"); snprintf(tmp, sizeof tmp, spec, s); break; }
        case 'f': case 'e': case 'g': case 'E': case 'G': { size_t l = strlen(spec); spec[l] = conv; spec[l + 1] = 0;
            snprintf(tmp, sizeof tmp, spec, va_dbl(&v)); break; }
        default: snprintf(tmp, sizeof tmp, "%%?%c", conv ? conv : '$'); break;
        }
        size_t l = strlen(tmp); if (o + l < cap) { memcpy(out + o, tmp, l); o += l; }
        (void)h;
    }
    out[o] = 0;
}

/* SCGetAspectRatio(): the SDK's SC library reads the IPL.AR item (0 = 4:3, 1 = 16:9) from /shared2/sys/SYSCONF on the NAND. NAND/ISFS is not
 * emulated (the file would read back as zeros, which the SDK treats as 4:3), so the answer is a runtime setting instead. Default 16:9,
 * which makes the game pick its HD asset list; `--aspect 4x3` selects the SD list. */
int rt_sc_widescreen = 1;
void rt_hle_sc_get_aspect_ratio(Ctx *c) { c->r[3] = rt_sc_widescreen ? 1u : 0u; }

/* OSReport(fmt, ...) / similar printf-style routines: format string in r3. */
void rt_hle_os_report(Ctx *c) {
    char buf[1024]; rt_guest_format(c, c->r[3], 4, buf, sizeof buf);
    fprintf(stderr, "[OSReport] %s", buf);
    size_t n = strlen(buf); if (n == 0 || buf[n - 1] != '\n') fputc('\n', stderr);
}
