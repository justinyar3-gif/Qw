/* DOL loader, low-memory setup and the boot harness (watchdog + crash dump). */
#include "rt.h"
#include <pthread.h>
#include "rt_compat.h"
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void rt_mmio_summary(void);
void rt_gx_summary(void);
void rt_di_summary(void);
void rt_pad_summary(void);
void rt_watch_dump_ring(void);
pthread_t rt_cur_thread(void);
uint32_t rt_cur_context(void);
Ctx *rt_cur_ctx(void);
static Ctx *g_ctx;
static int g_trace_n = 48;

Ctx *rt_ctx_new(void) {
    Ctx *c = calloc(1, sizeof *c);
    c->mem1 = calloc(1, 0x1800000);
    c->mem2 = calloc(1, 0x4000000);
    c->lc = calloc(1, 0x4000);
    if (!c->mem1 || !c->mem2 || !c->lc) { fprintf(stderr, "out of memory\n"); exit(2); }
    g_ctx = c;
    return c;
}

static uint32_t be32(const uint8_t *p) { return (uint32_t)p[0] << 24 | p[1] << 16 | p[2] << 8 | p[3]; }

/* Copies every DOL section into guest memory, zeroes BSS, returns the entry point. */
uint32_t rt_load_dol(Ctx *c, const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) { perror(path); exit(2); }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *d = malloc((size_t)n);
    if (fread(d, 1, (size_t)n, f) != (size_t)n || n < 0x100) { fprintf(stderr, "bad DOL\n"); exit(2); }
    fclose(f);
    for (int i = 0; i < 18; i++) {
        uint32_t off = be32(d + 4 * i), addr = be32(d + 0x48 + 4 * i), size = be32(d + 0x90 + 4 * i);
        if (!size) continue;
        if (off + size > (uint32_t)n) { fprintf(stderr, "section %d out of range\n", i); exit(2); }
        memcpy(rt_ptr(c, addr), d + off, size);
    }
    /* The DOL's BSS range overlaps a data section (the small-constants area addressed through r2), so it must
     * not be cleared after the sections are copied. Memory starts zeroed, and the game's own startup code
     * clears the BSS parts it needs. (Clearing it here wiped initialized constants and broke the boot.) */
    uint32_t entry = be32(d + 0xE0);
    free(d);
    return entry;
}

/* Values the IPL/bootloader leaves in low memory. From memory of Dolphin's HLE boot;
 * unverified. Wrong values show up as odd OSInit behavior during bring-up. */
void rt_init_lowmem(Ctx *c) {
    static const struct { uint32_t a, v; } t[] = {
        {0x80000018, 0x5D1C9EA3}, {0x80000020, 0x0D15EA5E}, {0x80000024, 1},
        {0x80000028, 0x01800000}, {0x8000002C, 0x00000023}, {0x80000034, 0x81800000},
        {0x800000EC, 0x81800000}, {0x800000F0, 0x01800000},
        {0x800000F8, 243000000}, {0x800000FC, 729000000},
        {0x80003100, 0x01800000}, {0x80003104, 0x01800000}, {0x80003108, 0x81800000}, {0x80003110, 0x81700000},
        {0x80003118, 0x04000000}, {0x8000311C, 0x04000000}, {0x80003120, 0x93400000},
        {0x80003124, 0x90002000}, {0x80003128, 0x933E0000},
        {0x80003130, 0x933E0000}, {0x80003134, 0x93400000}, {0x80003138, 0x00000011},
    };
    for (unsigned i = 0; i < sizeof t / sizeof t[0]; i++) rt_w32(c, t[i].a, t[i].v);
}

/* Guest OS threads (SDK OSThread list at 0x800000DC; field offsets from the public SDK headers). Shows who is waiting on what. */
static int guest_ptr_ok(uint32_t a) { return (a >= 0x80000000u && a < 0x81800000u) || (a >= 0x90000000u && a < 0x94000000u); }
static void dump_threads(Ctx *c) {
    uint32_t t = rt_r32(c, 0x800000DC), cur = rt_r32(c, 0x800000E4);
    if (!guest_ptr_ok(t)) return;
    fprintf(stderr, "guest threads (OSThread: state 1 ready, 2 running, 4 waiting, 8 dead; current %08X):\n", cur);
    for (int n = 0; n < 64 && guest_ptr_ok(t); n++, t = rt_r32(c, t + 0x2FC)) {
        uint32_t q = rt_r32(c, t + 0x2DC);
        fprintf(stderr, "  thread %08X state %u prio %d (base %d) waiting-on-queue %08X stack %08X..%08X ctx-lr %08X ctx-srr0 %08X%s\n", t,
                rt_r16(c, t + 0x2C8), (int32_t)rt_r32(c, t + 0x2D0), (int32_t)rt_r32(c, t + 0x2D4), q, rt_r32(c, t + 0x308), rt_r32(c, t + 0x304),
                rt_r32(c, t + 0x84), rt_r32(c, t + 0x198), t == cur ? "  <- current" : "");
    }
}

static void dump_state(const char *why) {
    fprintf(stderr, "\n=== %s ===\n", why);
    if (g_ctx) {
        Ctx *c = g_ctx;
        fprintf(stderr, "lr=%08X ctr=%08X msr=%08X\n", c->lr, c->ctr, c->msr);
        for (int i = 0; i < 32; i += 8)
            fprintf(stderr, "r%-2d %08X %08X %08X %08X %08X %08X %08X %08X\n", i, c->r[i], c->r[i+1], c->r[i+2],
                    c->r[i+3], c->r[i+4], c->r[i+5], c->r[i+6], c->r[i+7]);
        const char *dump = getenv("RT_DUMP");      /* RT_DUMP=809831C8:64 : hex-dump guest memory in the report */
        if (dump) {
            uint32_t a = (uint32_t)strtoul(dump, 0, 16); const char *colon = strchr(dump, ':');
            uint32_t n = colon ? (uint32_t)strtoul(colon + 1, 0, 0) : 64;
            for (uint32_t o = 0; o < n; o += 16) {
                fprintf(stderr, "  %08X:", a + o);
                for (uint32_t k = 0; k < 16 && o + k < n; k += 4) fprintf(stderr, " %08X", rt_r32(c, a + o + k));
                fputc('\n', stderr);
            }
        }
    }
    if (g_ctx) dump_threads(g_ctx);
    rt_trace_dump(g_trace_n);
    rt_mmio_summary();
    rt_gx_summary();
    rt_di_summary();
    rt_pad_summary();
}
static pthread_t g_guest_th;
static void print_stack(void) {
    void *bt[64];
    int n = backtrace(bt, 64);
    fprintf(stderr, "guest call stack, innermost first (func_XXXXXXXX = guest address; link with -rdynamic):\n");
    fflush(stderr);
    backtrace_symbols_fd(bt, n, 2);
}
static void on_usr1(int sig) {                 /* runs on the guest thread */
    (void)sig;
    char why[96]; snprintf(why, sizeof why, "TIMEOUT (guest still running; running thread context %08X)", rt_cur_context());
    dump_state(why);
    print_stack();
    _exit(3);
}
static void on_signal(int sig) {
    if (sig == SIGALRM) {                      /* main thread: ask the guest thread to report itself */
        pthread_kill(rt_cur_thread(), SIGUSR1);          /* report the thread that is actually running */
        sleep(2); _exit(3);
    }
    dump_state(sig == SIGSEGV ? "SIGSEGV (host crash or stack overflow)" : "ABORT");
    print_stack();
    _exit(4);
}

/* Called by every guest host thread: own signal stack + crash/timeout reporting. */
void rt_thread_init_signals(void) {
#ifdef __ANDROID__
    return;      /* ART owns SIGSEGV/SIGUSR1 (implicit null checks, stack probes): installing the crash and timeout reporters would break the Java side */
#endif
    stack_t ss = { .ss_sp = malloc(1 << 16), .ss_size = 1 << 16 };
    sigaltstack(&ss, 0);
    struct sigaction sa = { .sa_handler = on_signal, .sa_flags = SA_ONSTACK };
    sigaction(SIGSEGV, &sa, 0); sigaction(SIGABRT, &sa, 0);
    struct sigaction su = { .sa_handler = on_usr1, .sa_flags = SA_ONSTACK };
    sigaction(SIGUSR1, &su, 0);
}
void rt_break_hook(uint32_t addr) {
    char why[64]; snprintf(why, sizeof why, "BREAK: guest function %08X entered", addr);
    dump_state(why); print_stack(); _exit(5);
}
void rt_log_hook(uint32_t addr) {
    static int n, lost; Ctx *c = rt_cur_ctx();
    if (c && !lost && rt_r32(c, 0x800000E4) == 0 && rt_r32(c, 0x800000D4) == 0 && rt_cur_context() == 0x80902E98) {
        lost = 1;                                         /* the main thread entered the scheduler with no current thread/context */
        fprintf(stderr, "[at %08X] LOST: OSCurrentThread and OSCurrentContext are both 0 (fiber %08X). Recent guest functions:\n", addr, rt_cur_context());
        rt_trace_dump(70);
        if (rt_watch_addr) rt_watch_dump_ring();
        fprintf(stderr, "low memory 0x800000C0..FF:\n");
        for (uint32_t o = 0xC0; o < 0x100; o += 16) fprintf(stderr, "  %08X: %08X %08X %08X %08X\n", 0x80000000u + o, rt_r32(c, 0x80000000u + o), rt_r32(c, 0x80000000u + o + 4), rt_r32(c, 0x80000000u + o + 8), rt_r32(c, 0x80000000u + o + 12));
    }
    static int cap = -1;                                    /* RT_LOG_MAX=N raises the 400-line cap */
    if (cap < 0) cap = getenv("RT_LOG_MAX") ? atoi(getenv("RT_LOG_MAX")) : 400;
    if (!c || n++ > cap) return;
    fprintf(stderr, "[at %08X] fiber %08X r3=%08X r4=%08X lr=%08X | OSCurrentThread=%08X OSCurrentContext=%08X msr=%04X\n", addr,
            rt_cur_context(), c->r[3], c->r[4], c->lr, rt_r32(c, 0x800000E4), rt_r32(c, 0x800000D4), c->msr);
    if (getenv("RT_LOG_FPR")) fprintf(stderr, "    f1..f6 = %g %g %g %g %g %g\n", c->ps[1][0], c->ps[2][0], c->ps[3][0], c->ps[4][0], c->ps[5][0], c->ps[6][0]);   /* RT_LOG_FPR=1: float arguments */
    const char *pr = getenv("RT_LOG_PTR");                  /* RT_LOG_PTR=4: also show 32 bytes of guest memory at that register's value */
    if (pr) {
        uint32_t p = c->r[atoi(pr) & 31];
        if ((p >= 0x80000000u && p < 0x81800000u) || (p >= 0x90000000u && p < 0x94000000u)) {
            fprintf(stderr, "    [%08X]:", p);
            for (uint32_t k = 0; k < 32; k += 4) fprintf(stderr, " %08X", rt_r32(c, p + k));
            fputc('\n', stderr);
        }
    }
}
void rt_chk_hook(uint32_t fn) {
    static uint32_t prev = 0xFFFFFFFF; static int done; Ctx *c = rt_cur_ctx();
    if (!c || done) return;
    uint32_t v = rt_r32(c, rt_chk_addr);
    if (prev != 0 && prev != 0xFFFFFFFF && v == 0) {
        done = 1;
        fprintf(stderr, "[check] word %08X went %08X -> 0 (fiber %08X); function entered just now: %08X\n", rt_chk_addr, prev, rt_cur_context(), fn);
        fprintf(stderr, "[check] this Ctx %p: mem1=%p mem2=%p lc=%p; original Ctx g_ctx %p: mem1=%p\n", (void *)c, (void *)c->mem1, (void *)c->mem2,
                (void *)c->lc, (void *)g_ctx, (void *)g_ctx->mem1);
        fprintf(stderr, "[check] value via this Ctx: %08X, via original: %08X\n", rt_r32(c, rt_chk_addr), rt_r32(g_ctx, rt_chk_addr));
        rt_trace_dump(48); if (rt_watch_addr) rt_watch_dump_ring(); print_stack();
    }
    prev = v;
}
typedef struct { Ctx *c; uint32_t entry; } RunArgs;
static void *run_guest(void *p) {
    RunArgs *a = p;
    rt_thread_init_signals();
    rt_fiber_main_init(a->c);
    rt_irq_init(a->c);
    rt_call_indirect(a->c, a->entry);
    return 0;
}

/* Runs the guest on a 1 GB-stack thread (lifted code recurses like the original). */
int rt_run(Ctx *c, uint32_t entry, int timeout_s, int trace_n) {
    g_trace_n = trace_n; rt_trace_on = 1;
#ifndef __ANDROID__
    signal(SIGALRM, on_signal);
    alarm((unsigned)timeout_s);                /* 0 = no watchdog */
#endif
    RunArgs a = { c, entry };
    pthread_t th; int started = 0;
    for (size_t stack = (size_t)1 << 30; stack >= ((size_t)256 << 20) && !started; stack >>= 1) {     /* 1 GB; smaller if the system refuses */
        pthread_attr_t at; pthread_attr_init(&at); pthread_attr_setstacksize(&at, stack);
        started = pthread_create(&th, &at, run_guest, &a) == 0;
        if (!started) fprintf(stderr, "cannot create a guest thread with a %zu MB stack\n", stack >> 20);
    }
    if (!started) { perror("pthread_create"); return 2; }
    g_guest_th = th;
    pthread_join(th, 0);
    fprintf(stderr, "guest entry point returned\n");
    return 0;
}
