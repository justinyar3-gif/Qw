/* Portability shims. Android's libc only has backtrace()/backtrace_symbols_fd() from API level 33; the runtime uses them for crash
 * and timeout reports, so on older Android versions they become no-ops (the report then has no host call stack). */
#ifndef RT_COMPAT_H
#define RT_COMPAT_H
#if defined(__ANDROID__) && __ANDROID_API__ < 33
static inline int backtrace(void **buf, int n) { (void)buf; (void)n; return 0; }
static inline void backtrace_symbols_fd(void *const *buf, int n, int fd) { (void)buf; (void)n; (void)fd; }
#else
#include <execinfo.h>
#endif
#endif
