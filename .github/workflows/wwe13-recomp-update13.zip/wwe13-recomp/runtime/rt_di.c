/* Virtual Wii disc for /dev/di: serves partition reads from an extracted disc folder.
 *
 * The folder is what Dolphin's "Extract Entire Disc" (or `wit extract`) writes for the game partition:
 *     <root>/sys/{boot.bin,bi2.bin,apploader.img,fst.bin,main.dol}      (also accepted: <root>/DATA/sys, or <root> itself)
 *     <root>/files/...                                                    (the game's files)
 * The game finds files by name in the FST that the apploader would have loaded into memory (pointer at
 * 0x80000038), then asks IOS to read byte ranges of the partition. We do both halves from the same fst.bin:
 * rt_di_boot() puts the FST in guest memory, and rt_di_read() maps a partition offset back to a file.
 * Anything not backed by a file (alignment gaps, files missing from the folder) reads as zeros, and each
 * missing file is reported once, which also tells you which file the game needs next.
 *
 * By default the file table is BUILT FROM THE FOLDER (every file at its real size), so it can never disagree
 * with the files you actually have; sys/fst.bin is then not needed. With use_fst=1 the original sys/fst.bin is
 * used as is (exact disc layout), which only works if the folder is the very image that fst.bin came from:
 * files whose size differs from the FST entry are reported.
 *
 * Disc offsets in the FST and in the DI read command are stored shifted right by 2.
 * Environment: RT_DI_LOG=1 logs every read. */
#include "rt.h"
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct { uint64_t start, end; char *path; int fd; int state; } Extent;   /* state: 0 untouched, 1 open, 2 missing */
typedef struct { uint64_t start; uint8_t *data; size_t len; const char *name; } Blob;

static Extent *ext; static int next_, cap_ext;
static Blob blobs[5]; static int nblobs;
static uint8_t hdr[0x440];
static uint8_t *fst; static size_t fst_len;
static int have_disc, log_all = -1;
static unsigned long long n_reads, n_bytes;

static uint32_t be32(const uint8_t *p) { return (uint32_t)p[0] << 24 | p[1] << 16 | p[2] << 8 | p[3]; }

static char *join(const char *a, const char *b) {                 /* "a/b" in a fresh allocation, never truncated */
    size_t n = strlen(a) + strlen(b) + 2; char *s = malloc(n);
    if (!s) { fprintf(stderr, "out of memory\n"); exit(2); }
    snprintf(s, n, "%s/%s", a, b); return s;
}
static uint8_t *slurp(const char *dir, const char *name, size_t *len) {
    char *p = join(dir, name); FILE *f = fopen(p, "rb"); free(p);
    if (!f) return 0;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *d = malloc(n > 0 ? (size_t)n : 1);
    if (!d || (n > 0 && fread(d, 1, (size_t)n, f) != (size_t)n)) { fclose(f); free(d); return 0; }
    fclose(f); *len = (size_t)n; return d;
}
static int is_file(const char *dir, const char *name) {
    char *p = join(dir, name); struct stat st; int ok = stat(p, &st) == 0 && S_ISREG(st.st_mode); free(p); return ok;
}
static void ext_add(uint64_t start, uint64_t len, char *path) {
    if (next_ == cap_ext) { cap_ext = cap_ext ? cap_ext * 2 : 512; ext = realloc(ext, (size_t)cap_ext * sizeof *ext); if (!ext) exit(2); }
    ext[next_++] = (Extent){ start, start + len, path, -1, 0 };
}
static int cmp_ext(const void *a, const void *b) {
    const Extent *x = a, *y = b; return x->start < y->start ? -1 : x->start > y->start;
}

/* Builds the extent table from fst.bin. Returns the number of files, or -1 if the FST is malformed. */
static int parse_fst(const char *files_dir) {
    if (fst_len < 12 || be32(fst) >> 24 != 1) return -1;
    uint32_t n = be32(fst + 8);
    if (n < 1 || (size_t)n * 12 > fst_len) return -1;
    const uint8_t *names = fst + (size_t)n * 12; size_t names_len = fst_len - (size_t)n * 12;
    char path[1024]; size_t plen[64]; uint32_t endidx[64]; int depth = 0; path[0] = 0;
    for (uint32_t i = 1; i < n; i++) {
        while (depth > 0 && i >= endidx[depth - 1]) depth--;
        const uint8_t *e = fst + 12 * (size_t)i;
        uint32_t w = be32(e), off = be32(e + 4), len = be32(e + 8), no = w & 0xFFFFFF;
        if (no >= names_len) return -1;
        size_t base = depth ? plen[depth - 1] : 0, nl = strnlen((const char *)names + no, names_len - no);
        if (base + nl + 2 >= sizeof path || nl == names_len - no) return -1;
        memcpy(path + base, names + no, nl); path[base + nl] = 0;
        if (w >> 24) {                                                         /* directory: entries up to index `len` belong to it */
            if (depth >= 64 || len <= i || len > n) return -1;
            path[base + nl] = '/'; path[base + nl + 1] = 0;
            plen[depth] = base + nl + 1; endidx[depth++] = len;
        } else {
            char *full = join(files_dir, path); struct stat st;
            if (stat(full, &st) == 0 && (uint64_t)st.st_size != len)
                fprintf(stderr, "[di] WARNING: %s is %lld bytes but fst.bin says %u; the folder is not the image fst.bin came from\n", path, (long long)st.st_size, len);
            ext_add((uint64_t)off << 2, len, full);
        }
    }
    qsort(ext, (size_t)next_, sizeof *ext, cmp_ext);
    return next_;
}


/* ---- file table built from the folder ---- */
typedef struct { uint8_t *e; size_t ne, cap_e; char *names; size_t nl, cap_n; uint64_t next_off; } Synth;
#define SYNTH_FIRST_FILE 0x1000000ull        /* above the system area (boot.bin .. main.dol .. original fst) */
#define SYNTH_ALIGN      0x8000ull

static void synth_put(uint8_t *p, uint32_t v) { p[0] = (uint8_t)(v >> 24); p[1] = (uint8_t)(v >> 16); p[2] = (uint8_t)(v >> 8); p[3] = (uint8_t)v; }
static uint32_t synth_entry(Synth *s, int is_dir, const char *name, uint32_t a, uint32_t b) {
    size_t nl = strlen(name) + 1;
    if (s->nl + nl > s->cap_n) { s->cap_n = (s->nl + nl) * 2 + 4096; s->names = realloc(s->names, s->cap_n); }
    if ((s->ne + 1) * 12 > s->cap_e) { s->cap_e = (s->ne + 1) * 24 + 1200; s->e = realloc(s->e, s->cap_e); }
    if (!s->names || !s->e) { fprintf(stderr, "out of memory\n"); exit(2); }
    uint8_t *p = s->e + s->ne * 12;
    synth_put(p, ((uint32_t)is_dir << 24) | (uint32_t)s->nl); synth_put(p + 4, a); synth_put(p + 8, b);
    memcpy(s->names + s->nl, name, nl); s->nl += nl;
    return (uint32_t)s->ne++;
}
static int cmp_name(const void *a, const void *b) { return strcasecmp(*(char *const *)a, *(char *const *)b); }
static int synth_dir(Synth *s, const char *dirpath, uint32_t parent, int depth) {
    DIR *d = opendir(dirpath); if (!d || depth > 32) { if (d) closedir(d); return -1; }
    char **list = 0; size_t n = 0, cap = 0; struct dirent *de;
    while ((de = readdir(d))) {
        if (de->d_name[0] == '.') continue;                  /* ., .., hidden files */
        if (n == cap) { cap = cap ? cap * 2 : 64; list = realloc(list, cap * sizeof *list); if (!list) exit(2); }
        list[n++] = strdup(de->d_name);
    }
    closedir(d);
    qsort(list, n, sizeof *list, cmp_name);
    int rc = 0;
    for (size_t i = 0; i < n && !rc; i++) {
        char *full = join(dirpath, list[i]); struct stat st;
        if (stat(full, &st) != 0) { free(full); continue; }
        if (S_ISDIR(st.st_mode)) {
            uint32_t idx = synth_entry(s, 1, list[i], parent, 0);
            rc = synth_dir(s, full, idx, depth + 1);
            synth_put(s->e + idx * 12 + 8, (uint32_t)s->ne);       /* next entry after this directory */
            free(full);
        } else if (S_ISREG(st.st_mode)) {
            uint64_t off = (s->next_off + SYNTH_ALIGN - 1) & ~(SYNTH_ALIGN - 1);
            if (((off + (uint64_t)st.st_size) >> 2) > 0xFFFFFFFFull) { fprintf(stderr, "[di] disc image would exceed 16 GB\n"); rc = -1; free(full); break; }
            synth_entry(s, 0, list[i], (uint32_t)(off >> 2), (uint32_t)st.st_size);
            ext_add(off, (uint64_t)st.st_size, full);              /* takes ownership of `full` */
            s->next_off = off + (uint64_t)st.st_size;
        } else free(full);
    }
    for (size_t i = 0; i < n; i++) free(list[i]);
    free(list);
    return rc;
}
static int build_fst_from_folder(const char *files_dir) {
    Synth s = { 0 }; s.next_off = SYNTH_FIRST_FILE;
    synth_entry(&s, 1, "", 0, 0);                            /* root */
    if (synth_dir(&s, files_dir, 0, 0)) return -1;
    synth_put(s.e + 8, (uint32_t)s.ne);
    fst_len = s.ne * 12 + s.nl; fst = malloc(fst_len);
    if (!fst) exit(2);
    memcpy(fst, s.e, s.ne * 12); memcpy(fst + s.ne * 12, s.names, s.nl);
    free(s.e); free(s.names);
    qsort(ext, (size_t)next_, sizeof *ext, cmp_ext);
    return next_;
}

static void add_blob(uint64_t start, uint8_t *data, size_t len, const char *name) {
    if (data && nblobs < 5) blobs[nblobs++] = (Blob){ start, data, len, name };
}

/* root: the extracted folder. use_fst: trust sys/fst.bin instead of building the table from the folder.
 * Returns 0 on success, otherwise prints why and returns -1. */
int rt_di_open(const char *root, int use_fst) {
    char *sys = 0, *files = 0;
    static const char *const sys_sub[] = { "sys", "DATA/sys", 0 };           /* last candidate: the folder itself */
    static const char *const base_sub[] = { 0, "DATA", 0 };                  /* where "files" lives relative to root */
    for (int i = 0; i < 3 && !sys; i++) {
        char *s = sys_sub[i] ? join(root, sys_sub[i]) : strdup(root);
        if (is_file(s, "fst.bin") && is_file(s, "boot.bin")) {
            char *base = base_sub[i] ? join(root, base_sub[i]) : strdup(root);
            files = join(base, "files"); free(base); sys = s;
        } else free(s);
    }
    if (!sys) { fprintf(stderr, "[di] %s: no sys/fst.bin + sys/boot.bin found (expected an extracted disc folder)\n", root); return -1; }
    size_t bl = 0, l2 = 0;
    uint8_t *boot = slurp(sys, "boot.bin", &bl);
    if (use_fst) fst = slurp(sys, "fst.bin", &fst_len);
    if (!boot || bl < 0x430 || (use_fst && !fst)) { fprintf(stderr, "[di] cannot read boot.bin%s in %s\n", use_fst ? " / fst.bin" : "", sys); return -1; }
    memcpy(hdr, boot, bl < sizeof hdr ? bl : sizeof hdr);
    add_blob(0, boot, bl, "boot.bin");
    uint8_t *bi2 = slurp(sys, "bi2.bin", &l2);                            /* separate statements: argument evaluation order is unspecified */
    add_blob(0x440, bi2, l2, "bi2.bin");
    size_t al = 0; uint8_t *app = slurp(sys, "apploader.img", &al);
    add_blob(0x2440, app, al, "apploader.img");
    size_t dl = 0; uint8_t *dol = slurp(sys, "main.dol", &dl);
    add_blob((uint64_t)be32(boot + 0x420) << 2, dol, dl, "main.dol");
    int nf;
    if (use_fst) {
        add_blob((uint64_t)be32(boot + 0x424) << 2, fst, fst_len, "fst.bin");
        nf = parse_fst(files);
        if (nf < 0) { fprintf(stderr, "[di] fst.bin in %s is not a valid FST\n", sys); return -1; }
    } else {
        nf = build_fst_from_folder(files);
        if (nf < 0) { fprintf(stderr, "[di] cannot read the folder %s\n", files); return -1; }
    }
    have_disc = 1;
    fprintf(stderr, "[di] disc folder %s: game %.6s, %d files, file table %s, files under %s%s\n", root, hdr, nf,
            use_fst ? "from sys/fst.bin" : "built from the folder", files, dol ? "" : " (no sys/main.dol; reads of the DOL area return zeros)");
    return 0;
}

static void copy_overlap(uint8_t *dst, uint64_t pos, uint32_t len, uint64_t s, const uint8_t *src, size_t slen) {
    uint64_t end = pos + len, send = s + slen;
    if (end <= s || pos >= send) return;
    uint64_t a = pos > s ? pos : s, z = end < send ? end : send;
    memcpy(dst + (a - pos), src + (a - s), (size_t)(z - a));
}

/* Fills dst[0..len) with partition bytes [pos, pos+len). Unbacked bytes are zero. */
void rt_di_read(uint8_t *dst, uint64_t pos, uint32_t len) {
    if (log_all < 0) log_all = getenv("RT_DI_LOG") != 0;
    memset(dst, 0, len);
    n_reads++; n_bytes += len;
    if (log_all) fprintf(stderr, "[di] read pos 0x%llX len %u\n", (unsigned long long)pos, len);
    for (int i = 0; i < nblobs; i++) copy_overlap(dst, pos, len, blobs[i].start, blobs[i].data, blobs[i].len);
    int lo = 0, hi = next_;                                   /* first extent that ends after pos */
    while (lo < hi) { int m = (lo + hi) / 2; if (ext[m].end <= pos) lo = m + 1; else hi = m; }
    for (int i = lo; i < next_ && ext[i].start < pos + len; i++) {
        Extent *e = &ext[i];
        if (e->end == e->start) continue;
        if (e->state == 0) {
            e->fd = open(e->path, O_RDONLY); e->state = e->fd >= 0 ? 1 : 2;
            if (e->state == 2) fprintf(stderr, "[di] MISSING FILE %s (game read %u bytes at partition offset 0x%llX)\n", e->path, len, (unsigned long long)pos);
            else if (log_all) fprintf(stderr, "[di] opened %s\n", e->path);
        }
        if (e->state != 1) continue;
        uint64_t a = pos > e->start ? pos : e->start, z = pos + len < e->end ? pos + len : e->end;
        size_t want = (size_t)(z - a), got = 0;
        while (got < want) {
            ssize_t r = pread(e->fd, dst + (a - pos) + got, want - got, (off_t)(a - e->start + got));
            if (r <= 0) { fprintf(stderr, "[di] short read of %s (file smaller than the FST says?)\n", e->path); break; }
            got += (size_t)r;
        }
    }
}

/* Called for ioctls on /dev/di. `req` is the guest address of the IOS request. Returns 1 if handled (the caller
 * reports success), 0 if not (the caller keeps its generic reply). Commands: 0x70 read disc ID, 0x71 read. */
int rt_di_ioctl(Ctx *c, uint32_t req) {
    if (!have_disc) return 0;
    uint32_t ioc = rt_r32(c, req + 0xC), in = 0x80000000u | rt_r32(c, req + 0x10);
    uint32_t out = rt_r32(c, req + 0x18), out_len = rt_r32(c, req + 0x1C);
    if (!out || !out_len) return ioc == 0x70 || ioc == 0x71;
    uint8_t *dst = rt_ptr(c, 0x80000000u | out);
    if (ioc == 0x70) { rt_di_read(dst, 0, out_len < 0x20 ? out_len : 0x20); return 1; }
    if (ioc == 0x71) {
        uint32_t len = rt_r32(c, in + 4), pos = rt_r32(c, in + 8);
        if (len > out_len) len = out_len;
        rt_di_read(dst, (uint64_t)pos << 2, len);
        return 1;
    }
    return 0;
}

/* Does what the apploader does for the game: FST into memory, pointer + size in low memory, and the disc header.
 * The FST goes at the very top of MEM1 (0x81800000), ABOVE the arena (which ends at 0x81700000): inside the arena
 * the game's own heaps zero and reuse it. (Found on the real boot: the FST read back as zeros and every DVDOpen failed.) */
void rt_di_boot(Ctx *c) {
    if (!have_disc) return;
    uint32_t size = (uint32_t)((fst_len + 31) & ~31u), addr = 0x81800000u - size;
    memcpy(rt_ptr(c, addr), fst, fst_len);
    rt_w32(c, 0x80000038u, addr); rt_w32(c, 0x8000003Cu, size);
    for (uint32_t k = 0; k < 0x20; k++) rt_w8(c, 0x80000000u + k, hdr[k]);
    for (uint32_t k = 0; k < 4; k++) rt_w8(c, 0x80003180u + k, hdr[k]);
    fprintf(stderr, "[di] FST (%zu bytes) loaded at %08X, pointer set at 0x80000038\n", fst_len, addr);
}

void rt_di_summary(void) {
    if (!have_disc) return;
    int opened = 0, missing = 0;
    for (int i = 0; i < next_; i++) { opened += ext[i].state == 1; missing += ext[i].state == 2; }
    fprintf(stderr, "DI: %llu reads, %llu bytes; %d files touched, %d of them missing from the folder\n", n_reads, n_bytes, opened + missing, missing);
}
