#include "rt.h"
#include <stdio.h>
#include <stdlib.h>
#include "rt_compat.h"

int rt_trace_on = 0;
static uint32_t trace_ring[256];
static unsigned trace_pos;
uint32_t rt_chk_addr;                          /* RT_CHECK_ZERO=800000E4: report when this word goes from non-zero to zero */
__attribute__((weak)) void rt_chk_hook(uint32_t fn) { (void)fn; }
uint32_t rt_log_addr;                           /* RT_LOG_AT=805E0300: log (non-fatal) each time this function is entered */
__attribute__((weak)) void rt_log_hook(uint32_t addr) { (void)addr; }
uint32_t rt_break_addr;                       /* RT_BREAK=0x805DB680: stop and report when this function is entered */
__attribute__((weak)) void rt_break_hook(uint32_t addr) { (void)addr; }
static uint32_t log_more[8]; static int n_log_more;
void rt_log_list(const char *list) {                 /* RT_LOG_AT=addr1,addr2,...: the first goes to rt_log_addr, the rest are kept here */
    const char *p = list; int first = 1;
    while (p && *p) {
        char *end; uint32_t a = (uint32_t)strtoul(p, &end, 16);
        if (end == p) break;
        if (first) first = 0; else if (n_log_more < 8) log_more[n_log_more++] = a;
        p = *end == ',' ? end + 1 : end;
        if (*end != ',') break;
    }
}
void rt_trace_hit(uint32_t addr) {
    trace_ring[trace_pos++ & 255] = addr;
    if (rt_chk_addr) rt_chk_hook(addr);
    if (addr == rt_log_addr) rt_log_hook(addr);
    for (int i = 0; i < n_log_more; i++) if (addr == log_more[i]) rt_log_hook(addr);
    if (addr == rt_break_addr) rt_break_hook(addr);
}
void rt_trace_dump(int last_n) {
    if (last_n > 256) last_n = 256;
    if ((unsigned)last_n > trace_pos) last_n = (int)trace_pos;
    fprintf(stderr, "last %d function entries (oldest first), %u total:\n", last_n, trace_pos);
    for (int i = last_n; i >= 1; i--)
        fprintf(stderr, "  %08X\n", trace_ring[(trace_pos - i) & 255]);
}
void rt_unimpl(Ctx *c, uint32_t insn, uint32_t pc) {
    (void)c; fprintf(stderr, "UNIMPLEMENTED instruction 0x%08X at 0x%08X\n", insn, pc); abort();
}
void rt_trap(Ctx *c, uint32_t pc) {
    (void)c; fprintf(stderr, "Trap instruction (tw/twi, usually a failed assertion) taken at 0x%08X\n", pc); abort();
}
void rt_bad_access(uint32_t addr) {
    fprintf(stderr, "Bad guest memory access at 0x%08X\n", addr); abort();
}
void rt_fell_off(Ctx *c, uint32_t pc) {
    (void)c; fprintf(stderr, "Execution fell off the end of lifted code at 0x%08X\n", pc); abort();
}
static rt_func find_func(uint32_t addr) {
    if (addr < 0x01800000u) addr |= 0x80000000u;      /* physical MEM1 address (translation off) */
    uint32_t lo = 0, hi = rt_func_count;
    while (lo < hi) {
        uint32_t mid = (lo + hi) / 2;
        if (rt_func_table[mid].addr == addr) return rt_func_table[mid].fn;
        if (rt_func_table[mid].addr < addr) lo = mid + 1; else hi = mid;
    }
    return 0;
}
/* Code that is not in main.dol cannot be run: the game links modules (RSO) into its heap at runtime, e.g. the Home Button Menu
 * (HbmRso.rso, entry point `_prolog`). A call or jump to such an address logs once per target and returns 0 so the rest of the game
 * can run. Targets outside the heap are still fatal, and RT_STRICT=1 makes all of them fatal. */
static int rt_unlifted_ok(Ctx *c, uint32_t addr, const char *what) {
    uint32_t a = addr & 0x1FFFFFFFu;
    int heap = (a >= 0x00900000u && a < 0x01800000u) || (a >= 0x10000000u && a < 0x14000000u);
    if (!heap || getenv("RT_STRICT")) return 0;
    static uint32_t seen[64]; static unsigned n;
    for (unsigned i = 0; i < n; i++) if (seen[i] == addr) { c->r[3] = 0; return 1; }
    if (n < 64) seen[n++] = addr;
    fprintf(stderr, "[rt] %s into code that was not lifted: 0x%08X (a module loaded at runtime?); returning 0 (RT_STRICT=1 makes this fatal)\n", what, addr);
    c->r[3] = 0;
    return 1;
}
void rt_call_indirect(Ctx *c, uint32_t addr) {
    rt_func f = find_func(addr);
    if (!f) {
        if (rt_unlifted_ok(c, addr, "call")) return;
        fprintf(stderr, "Indirect call to unknown target 0x%08X\n", addr); abort();
    }
    f(c);
}
/* bctr: also used for switch jump tables, whose targets are inside functions and
 * need real jump-table recovery (milestone 3). */
void rt_jump_indirect(Ctx *c, uint32_t addr) {
    rt_func f = find_func(addr);
    if (!f) {
        if (rt_unlifted_ok(c, addr, "jump")) return;
        fprintf(stderr, "Indirect jump to unknown target 0x%08X (jump table?)\n", addr); abort();
    }
    f(c);
}

/* RT_WATCH=800000E4 : every store into that 8-byte block is reported with the guest call stack (first 60 hits). */
uint32_t rt_watch_addr, rt_watch_mask = ~7u;
static struct { uint32_t addr, lr, r1; uint64_t val; int size; void *ctx; } wring[64];
static unsigned wpos;
void rt_watch_dump_ring(void) {
    fprintf(stderr, "last %u watched writes (oldest first):\n", wpos > 64 ? 64 : wpos);
    for (unsigned i = wpos > 64 ? 64 : wpos; i >= 1; i--) {
        unsigned k = (wpos - i) & 63;
        fprintf(stderr, "  write%d 0x%08X <- 0x%llX  lr=%08X r1=%08X ctx=%p\n", wring[k].size * 8, wring[k].addr,
                (unsigned long long)wring[k].val, wring[k].lr, wring[k].r1, wring[k].ctx);
    }
}
void rt_watch_hit(Ctx *c, uint32_t addr, uint64_t val, int size) {
    static int n, max = -1, stack, ring;
    if (max < 0) { max = getenv("RT_WATCH_MAX") ? atoi(getenv("RT_WATCH_MAX")) : 60; stack = getenv("RT_WATCH_STACK") != 0; ring = getenv("RT_WATCH_RING") != 0; }
    if (ring) {                                       /* silent: remember the last 64 hits, dump with rt_watch_dump_ring() */
        unsigned k = wpos++ & 63; wring[k].addr = addr; wring[k].val = val; wring[k].size = size;
        wring[k].lr = c->lr; wring[k].r1 = c->r[1]; wring[k].ctx = c; return;
    }
    if (n++ >= max) return;
    fprintf(stderr, "[watch] write%d 0x%08X <- 0x%llX  (r1=%08X lr=%08X)\n", size * 8, addr, (unsigned long long)val, c->r[1], c->lr);
    if (!stack) return;
    void *bt[24]; int k = backtrace(bt, 24); fflush(stderr);
    backtrace_symbols_fd(bt + 1, k > 14 ? 13 : k - 1, 2);
}
