/* Time base, decrementer, and delivery of interrupts into lifted code.
 *
 * Nothing preempts recompiled code, so interrupts are taken at poll points (RT_POLL).
 * Delivery mimics the exception vector: the interrupted registers are written into the
 * current OSContext (pointer at 0x800000D4), then the handler registered in the OS
 * exception table (0x80003000 + 4*exception) is called with r3 = exception, r4 = context.
 * The handler normally ends in OSLoadContext(context); that routine's rfi carries the
 * sentinel SRR0 (RT_IRQ_PC) and unwinds back to the poll site (rt_exc_return). */
#include "rt.h"
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

volatile int rt_irq_pending;
static atomic_int dec_fire, vi_tick;
static volatile int dec_armed;
static volatile int64_t dec_expiry;                /* in timebase ticks */
static uint64_t t0_ns;

static uint64_t now_ns(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}
static int64_t tb_now(void) { return (int64_t)((double)(now_ns() - t0_ns) * 0.06075) + 1000000; }

uint32_t rt_mftb(Ctx *c, int upper) {
    (void)c; uint64_t t = (uint64_t)tb_now(); return upper ? (uint32_t)(t >> 32) : (uint32_t)t;
}
void rt_set_dec(Ctx *c, uint32_t v) {
    (void)c; int32_t s = (int32_t)v;
    dec_expiry = tb_now() + s; dec_armed = 1; atomic_store(&dec_fire, 0);
    if (s <= 0) { atomic_store(&dec_fire, 1); dec_armed = 0; rt_irq_recompute(); }
}
uint32_t rt_get_dec(Ctx *c) { (void)c; return (uint32_t)(dec_expiry - tb_now()); }

void rt_irq_recompute(void) {
    rt_irq_pending = atomic_load(&dec_fire) || atomic_load(&vi_tick) || rt_hw_ext_pending();
}

/* Helper thread: only raises flags; all guest-visible state is touched by the running guest thread. */
extern volatile uint32_t rt_aid_period_us;           /* rt_mmio.c: AI DMA buffer period, 0 = stopped */
static void *timer_main(void *arg) {
    (void)arg; int64_t next_vi = tb_now(); uint64_t next_aid = now_ns();
    for (;;) {
        usleep(500);
        uint32_t aid = rt_aid_period_us; uint64_t tn = now_ns();
        if (aid && tn >= next_aid) { next_aid = tn + (uint64_t)aid * 1000; rt_irq_pending = 1; }   /* the guest decides whether AIINT is due */
        else if (!aid) next_aid = tn;
        int64_t t = tb_now();
        if (dec_armed && t >= dec_expiry) { dec_armed = 0; atomic_store(&dec_fire, 1); rt_irq_pending = 1; }
        if (t >= next_vi) { next_vi += 1012500; atomic_store(&vi_tick, 1); rt_irq_pending = 1; }   /* 60 Hz */
    }
    return 0;
}
void rt_irq_init(Ctx *c) {
    (void)c; t0_ns = now_ns();
    pthread_t th; pthread_create(&th, 0, timer_main, 0); pthread_detach(th);
}

/* ---- delivery ---- */
static int take_exception(void) {
    if (atomic_exchange(&vi_tick, 0)) rt_hw_vi_retrace();
    if (rt_hw_ext_pending()) return 4;                  /* external interrupt (level-triggered) */
    if (atomic_exchange(&dec_fire, 0)) return 8;        /* decrementer */
    rt_irq_recompute();
    return -1;
}
void rt_poll_slow(Ctx *c) {
    if (!(c->msr & 0x8000u) || c->irq_depth >= 3) return;
    if (rt_r32(c, 0x800000D4) == 0) return;             /* OS has no current context yet */
    int e = take_exception();
    if (e >= 0) rt_deliver_exception(c, (uint32_t)e);
    rt_irq_recompute();
}

void rt_deliver_exception(Ctx *c, int exc) {
    uint32_t ctx = rt_r32(c, 0x800000D4);
    if (rt_r32(c, 0x800000E4)) rt_fiber_note_context(c, ctx);     /* a thread (not idle) was interrupted */
    for (int i = 0; i < 32; i++) rt_w32(c, ctx + 4u * i, c->r[i]);
    rt_w32(c, ctx + 0x80, rt_mfcr(c)); rt_w32(c, ctx + 0x84, c->lr);
    rt_w32(c, ctx + 0x88, c->ctr);     rt_w32(c, ctx + 0x8C, rt_get_xer(c));
    for (int i = 1; i < 8; i++) rt_w32(c, ctx + 0x1A4 + 4u * i, c->spr[912 + i]);
    rt_w32(c, ctx + 0x198, RT_IRQ_PC); rt_w32(c, ctx + 0x19C, c->msr);
    rt_w16(c, ctx + 0x1A2, rt_r16(c, ctx + 0x1A2) | 2u);          /* OS_CONTEXT_STATE_EXC */
    double fpr[32][2]; uint32_t fpscr = c->fpscr; memcpy(fpr, c->ps, sizeof fpr);
    c->msr &= ~0x8000u;                                           /* handlers run with EE off */
    uint32_t handler = rt_r32(c, 0x80003000u + 4u * (uint32_t)exc);
    if (!handler) { fprintf(stderr, "exception %d with no handler\n", exc); abort(); }
    int depth = c->irq_depth;
    if (setjmp(c->irq_jb[depth]) == 0) {
        c->irq_depth = depth + 1;
        c->r[3] = (uint32_t)exc; c->r[4] = ctx;
        rt_call_indirect(c, handler);
        /* handler returned with blr: resume the interrupted code from the saved context */
        c->irq_depth = depth;
        rt_w16(c, ctx + 0x1A2, rt_r16(c, ctx + 0x1A2) & ~2u);
        for (int i = 0; i < 32; i++) c->r[i] = rt_r32(c, ctx + 4u * i);
        c->lr = rt_r32(c, ctx + 0x84); c->ctr = rt_r32(c, ctx + 0x88);
        rt_mtcrf(c, 0xFF, rt_r32(c, ctx + 0x80)); rt_set_xer(c, rt_r32(c, ctx + 0x8C));
        c->msr = rt_r32(c, ctx + 0x19C);
    }                                                             /* else: returned through rt_exc_return */
    memcpy(c->ps, fpr, sizeof fpr); c->fpscr = fpscr;
}

/* The tail of OSLoadContext for a context that was saved by an exception: restore every
 * register from memory, then "rfi" to the sentinel = unwind to rt_deliver_exception. */
void rt_exc_return(Ctx *c, uint32_t ctx) {
    rt_w16(c, ctx + 0x1A2, rt_r16(c, ctx + 0x1A2) & ~2u);
    for (int i = 0; i < 32; i++) c->r[i] = rt_r32(c, ctx + 4u * i);
    c->lr = rt_r32(c, ctx + 0x84); c->ctr = rt_r32(c, ctx + 0x88);
    rt_mtcrf(c, 0xFF, rt_r32(c, ctx + 0x80)); rt_set_xer(c, rt_r32(c, ctx + 0x8C));
    for (int i = 1; i < 8; i++) c->spr[912 + i] = rt_r32(c, ctx + 0x1A4 + 4u * i);
    c->msr = rt_r32(c, ctx + 0x19C);
    uint32_t srr0 = rt_r32(c, ctx + 0x198);
    if (srr0 != RT_IRQ_PC || c->irq_depth <= 0) {
        fprintf(stderr, "rt_exc_return: context %08X has srr0=%08X depth=%d (not an interrupt context)\n",
                ctx, srr0, c->irq_depth);
        abort();
    }
    c->irq_depth--;
    longjmp(c->irq_jb[c->irq_depth], 1);
}
