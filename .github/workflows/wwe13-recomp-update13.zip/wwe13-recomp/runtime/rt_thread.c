/* Guest threads as host threads, plus the SDK's OSSaveContext / OSLoadContext semantics.
 *
 * Each guest thread gets its own host thread and its own Ctx (register file); only the thread
 * holding the baton runs. The SDK scheduler (lifted, unmodified) picks the next thread and
 * ends with OSLoadContext(next). We implement that call as follows:
 *   - target is the running thread: just return. In the SDK's SelectThread, the code after the
 *     call is the function epilogue, so returning equals "resume from OSSaveContext".
 *   - target is another thread: park this host thread here and wake the target. When this
 *     thread is scheduled again, the call returns (or, if its context was saved by an
 *     interrupt, finishes as an exception return).
 *   - target never ran: start a new host thread from its saved context. */
#include "rt.h"
#include "rt_compat.h"
#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct RtFiber {
    Ctx *c; pthread_t th; sem_t wake;
    uint32_t ctx_addr, entry, exit_lr;
    int resume_exc;
    struct RtFiber *next;
} RtFiber;
static RtFiber *fibers, *cur;

__attribute__((weak)) void rt_thread_init_signals(void) {}
pthread_t rt_cur_thread(void) { return cur ? cur->th : pthread_self(); }   /* the thread holding the baton */
Ctx *rt_cur_ctx(void) { return cur ? cur->c : 0; }
uint32_t rt_cur_context(void) { return cur ? cur->ctx_addr : 0; }

static RtFiber *lookup(uint32_t ctx) {
    for (RtFiber *f = fibers; f; f = f->next) if (f->ctx_addr == ctx) return f;
    return 0;
}
void rt_fiber_main_init(Ctx *c) {
    RtFiber *f = calloc(1, sizeof *f);
    f->c = c; c->fiber = f; sem_init(&f->wake, 0, 0); f->th = pthread_self();
    fibers = cur = f;
}
void rt_fiber_note_context(Ctx *c, uint32_t ctx) { if (c->fiber && !c->fiber->ctx_addr) c->fiber->ctx_addr = ctx; }

static void *fiber_main(void *p) {
    RtFiber *f = p;
    rt_thread_init_signals();
    sem_wait(&f->wake);
    Ctx *c = f->c;
    rt_call_indirect(c, f->entry);                 /* the thread function */
    c->lr = 0;
    rt_call_indirect(c, f->exit_lr);               /* its blr goes to the exit routine (OSExitThread) */
    fprintf(stderr, "guest thread %08X came back from its exit routine\n", f->ctx_addr);
    abort();
}
static RtFiber *fiber_new(Ctx *from, uint32_t ctx) {
    RtFiber *f = calloc(1, sizeof *f);
    Ctx *c = malloc(sizeof *c);
    memcpy(c, from, sizeof *c);
    c->irq_depth = 0; c->fiber = f; f->c = c; f->ctx_addr = ctx;
    for (int i = 0; i < 32; i++) c->r[i] = rt_r32(c, ctx + 4u * i);
    c->lr = rt_r32(c, ctx + 0x84); c->ctr = rt_r32(c, ctx + 0x88);
    rt_mtcrf(c, 0xFF, rt_r32(c, ctx + 0x80)); rt_set_xer(c, rt_r32(c, ctx + 0x8C));
    for (int i = 1; i < 8; i++) c->spr[912 + i] = rt_r32(c, ctx + 0x1A4 + 4u * i);
    c->msr = rt_r32(c, ctx + 0x19C);
    f->entry = rt_r32(c, ctx + 0x198); f->exit_lr = c->lr;
    sem_init(&f->wake, 0, 0);
    f->next = fibers; fibers = f;
    pthread_attr_t at; pthread_attr_init(&at); pthread_attr_setstacksize(&at, (size_t)64 << 20);
    if (pthread_create(&f->th, &at, fiber_main, f)) { perror("pthread_create"); abort(); }
    fprintf(stderr, "[threads] new guest thread: context %08X entry %08X sp %08X r3 %08X\n", ctx, f->entry, c->r[1], c->r[3]);
    return f;
}
static void fiber_switch(RtFiber *to) {
    RtFiber *from = cur;
    cur = to;
    sem_post(&to->wake);
    sem_wait(&from->wake);
}

void rt_os_save_context(Ctx *c) {
    uint32_t x = c->r[3];
    for (int i = 13; i < 32; i++) rt_w32(c, x + 0x34 + 4u * (uint32_t)(i - 13), c->r[i]);
    for (int i = 1; i < 8; i++) rt_w32(c, x + 0x1A4 + 4u * i, c->spr[912 + i]);   /* GQR1..7 (GQR0 is not saved) */
    rt_w32(c, x + 0x80, rt_mfcr(c)); rt_w32(c, x + 0x84, c->lr); rt_w32(c, x + 0x198, c->lr);
    rt_w32(c, x + 0x19C, c->msr);    rt_w32(c, x + 0x88, c->ctr); rt_w32(c, x + 0x8C, rt_get_xer(c));
    rt_w32(c, x + 4, c->r[1]); rt_w32(c, x + 8, c->r[2]);
    rt_w32(c, x + 0xC, 1);                           /* r3 seen by whoever loads this context */
    c->r[3] = 0;
    rt_fiber_note_context(c, x);
}

void rt_os_load_context(Ctx *c) {
    uint32_t x = c->r[3];
    RtFiber *me = c->fiber, *target = lookup(x);
    uint16_t st = rt_r16(c, x + 0x1A2);
    int exc = (st & 2) != 0;
    if (!target) target = exc ? me : fiber_new(c, x);
    if (target == me && !me->ctx_addr) me->ctx_addr = x;
    if (target == me) {
        if (exc) rt_exc_return(c, x);                /* handler finished: back to the interrupted code */
        return;                                      /* switching to ourselves: fall through (see header) */
    }
    target->resume_exc = exc;
    if (exc) rt_w16(c, x + 0x1A2, st & ~2u);
    static int log_sched = -1, nsw;                          /* RT_SCHED_LOG=1: first 200 switches; RT_SCHED_LOG=N: first N */
    if (log_sched < 0) { const char *e = getenv("RT_SCHED_LOG"); log_sched = e ? (atoi(e) > 1 ? atoi(e) : 200) : 0; }
    if (log_sched && nsw++ < log_sched)
        fprintf(stderr, "[sched] #%d %08X -> %08X%s  (state me=%u target=%u, cur thread %08X, run-queue bits %08X)\n", nsw, me->ctx_addr, x,
                exc ? " (interrupted thread)" : "", rt_r16(c, me->ctx_addr + 0x2C8), rt_r16(c, x + 0x2C8),
                rt_r32(c, 0x800000E4), rt_r32(c, c->r[13] - 0x1C58));
    { const char *w = getenv("RT_SCHED_STACK");              /* RT_SCHED_STACK=925BC230: guest stack when that thread blocks */
      if (w && (uint32_t)strtoul(w, 0, 16) == me->ctx_addr) {
          void *bt[40]; int n = backtrace(bt, 40);
          fprintf(stderr, "[sched] thread %08X blocks; call stack:\n", me->ctx_addr); fflush(stderr);
          backtrace_symbols_fd(bt, n, 2);
      } }
    fiber_switch(target);
    if (me->resume_exc) { me->resume_exc = 0; rt_exc_return(c, me->ctx_addr); }
}
