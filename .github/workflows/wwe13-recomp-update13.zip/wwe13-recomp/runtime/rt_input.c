/* Virtual Classic Controller for the game's KPAD reads. See rt_input.h.
 *
 * KPADStatus layout used (0xF0 bytes per sample; checked against the copy loop in the game's KPADReadEx, which moves 30 doublewords per sample and
 * stores dev_type at +0x5C, wpad_err at +0x5D, dpd_valid_fg at +0x5E, data_format at +0x5F):
 *   +0x00 hold, +0x04 trig, +0x08 release   (Wii Remote core buttons: none pressed)
 *   +0x5C dev_type (2 = Classic Controller), +0x5D wpad_err, +0x5E dpd_valid_fg (0: pointer not valid), +0x5F data_format (8 = classic + acc + dpd)
 *   +0x60 ex_status.cl: hold, trig, release (u32), lstick (x,y f32), rstick (x,y f32), ltrigger, rtrigger (f32)
 * The ex_status.cl order and the data_format number are from my memory of the SDK headers, not from this game's code: unverified. */
#include "rt_input.h"
#include <math.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

static _Atomic uint64_t g_state[RT_PAD_CHANNELS];       /* bits 0-15 buttons, then int8 lx, ly, rx, ry, then uint8 lt, rt */
static _Atomic int g_enabled[RT_PAD_CHANNELS] = { 1, 0, 0, 0 };

static uint64_t q8(float v, float lo, float scale) { if (!(v > lo)) v = lo; if (v > 1.f) v = 1.f; return (uint64_t)(uint8_t)(int8_t)lrintf(v * scale); }
void rt_pad_set(int chan, const rt_pad_state *s) {
    if (chan < 0 || chan >= RT_PAD_CHANNELS) return;
    uint64_t v = s->buttons;
    v |= q8(s->lx, -1.f, 127.f) << 16 | q8(s->ly, -1.f, 127.f) << 24 | q8(s->rx, -1.f, 127.f) << 32 | q8(s->ry, -1.f, 127.f) << 40;
    v |= (uint64_t)(uint8_t)lrintf((s->lt < 0 ? 0 : s->lt > 1 ? 1 : s->lt) * 255.f) << 48 | (uint64_t)(uint8_t)lrintf((s->rt < 0 ? 0 : s->rt > 1 ? 1 : s->rt) * 255.f) << 56;
    atomic_store_explicit(&g_state[chan], v, memory_order_relaxed);
}
void rt_pad_get(int chan, rt_pad_state *s) {
    memset(s, 0, sizeof *s);
    if (chan < 0 || chan >= RT_PAD_CHANNELS) return;
    uint64_t v = atomic_load_explicit(&g_state[chan], memory_order_relaxed);
    s->buttons = (uint16_t)v;
    s->lx = (int8_t)(v >> 16) / 127.f; s->ly = (int8_t)(v >> 24) / 127.f; s->rx = (int8_t)(v >> 32) / 127.f; s->ry = (int8_t)(v >> 40) / 127.f;
    s->lt = (uint8_t)(v >> 48) / 255.f; s->rt = (uint8_t)(v >> 56) / 255.f;
}
void rt_pad_enable(int chan, int on) { if (chan >= 0 && chan < RT_PAD_CHANNELS) atomic_store(&g_enabled[chan], on != 0); }
int rt_pad_enabled(int chan) { return chan >= 0 && chan < RT_PAD_CHANNELS && atomic_load(&g_enabled[chan]); }

/* ---- scripted presses (headless runs and tests) ---- */
typedef struct { uint16_t buttons; uint32_t first, count; } ScriptEntry;
static ScriptEntry g_script[32]; static int g_nscript; static uint32_t g_reads0;     /* channel-0 reads since the script was set */
static const struct { const char *name; uint16_t bit; } kNames[] = {
    { "UP", RT_CL_UP }, { "DOWN", RT_CL_DOWN }, { "LEFT", RT_CL_LEFT }, { "RIGHT", RT_CL_RIGHT }, { "A", RT_CL_A }, { "B", RT_CL_B },
    { "X", RT_CL_X }, { "Y", RT_CL_Y }, { "L", RT_CL_L }, { "R", RT_CL_R }, { "ZL", RT_CL_ZL }, { "ZR", RT_CL_ZR },
    { "PLUS", RT_CL_PLUS }, { "START", RT_CL_PLUS }, { "MINUS", RT_CL_MINUS }, { "HOME", RT_CL_HOME },
};
int rt_pad_parse_script(const char *spec) {
    g_nscript = 0; g_reads0 = 0;
    if (!spec) return 0;
    const char *p = spec;
    while (*p) {
        uint16_t bits = 0;
        for (;;) {                                           /* name[+name]* */
            size_t n = strcspn(p, "+:,"); int ok = 0;
            for (size_t i = 0; i < sizeof kNames / sizeof kNames[0]; i++)
                if (strlen(kNames[i].name) == n && !strncasecmp(p, kNames[i].name, n)) { bits |= kNames[i].bit; ok = 1; }
            if (!ok) return g_nscript = 0, -1;
            p += n;
            if (*p == '+') { p++; continue; }
            break;
        }
        char *e; if (*p++ != ':') return g_nscript = 0, -1;
        unsigned long first = strtoul(p, &e, 10); if (e == p || *e != ':') return g_nscript = 0, -1;
        p = e + 1; unsigned long cnt = strtoul(p, &e, 10); if (e == p || cnt == 0) return g_nscript = 0, -1;
        p = e;
        if (g_nscript == 32) return g_nscript = 0, -1;
        g_script[g_nscript++] = (ScriptEntry){ bits, (uint32_t)first, (uint32_t)cnt };
        if (*p == ',') p++; else if (*p) return g_nscript = 0, -1;
    }
    return g_nscript;
}
void rt_pad_init_from_env(void) {
    if (getenv("RT_NO_PAD")) rt_pad_enable(0, 0);
    const char *s = getenv("RT_PAD_SCRIPT");
    if (s && rt_pad_parse_script(s) < 0) fprintf(stderr, "RT_PAD_SCRIPT: expected name[+name]:first_read:reads,... (names: A B X Y L R ZL ZR UP DOWN LEFT RIGHT PLUS START MINUS HOME)\n");
    else if (s) fprintf(stderr, "[pad] script: %d entries\n", g_nscript);
}

static uint32_t g_nread[RT_PAD_CHANNELS], g_nheld[RT_PAD_CHANNELS], g_ntrig[RT_PAD_CHANNELS];
void rt_pad_summary(void) {
    fprintf(stderr, "PAD: KPADReadEx calls per channel %u %u %u %u; samples with a button held on channel 0: %u, new presses: %u\n",
            g_nread[0], g_nread[1], g_nread[2], g_nread[3], g_nheld[0], g_ntrig[0]);
}

/* ---- KPADReadEx replacement ---- */
enum { KS_HOLD = 0x00, KS_TRIG = 0x04, KS_RELEASE = 0x08, KS_DEV = 0x5C, KS_ERR = 0x5D, KS_DPD = 0x5E, KS_FMT = 0x5F, KS_CL = 0x60, KS_SIZE = 0xF0 };
enum { DEV_CLASSIC = 2, FMT_CLASSIC_BTN_ACC_DPD = 8, ERR_NO_CONTROLLER = -2 };
static void put_f(Ctx *c, uint32_t a, float f) { uint32_t u; memcpy(&u, &f, 4); rt_w32(c, a, u); }

void rt_hle_kpad_read_ex(Ctx *c) {
    int32_t chan = (int32_t)c->r[3]; uint32_t buf = c->r[4], max = c->r[5], errp = c->r[6];
    static uint16_t prev[RT_PAD_CHANNELS];
    int32_t err = 0; uint32_t got = 0;
    if (chan >= 0 && chan < RT_PAD_CHANNELS) g_nread[chan]++;
    if (!rt_pad_enabled(chan)) err = ERR_NO_CONTROLLER;
    else if (max >= 1 && buf) {
        rt_pad_state s; rt_pad_get(chan, &s);
        if (chan == 0) {                                         /* scripted presses add to the live state */
            for (int i = 0; i < g_nscript; i++) if (g_reads0 >= g_script[i].first && g_reads0 < g_script[i].first + g_script[i].count) s.buttons |= g_script[i].buttons;
            g_reads0++;
        }
        if (s.buttons & RT_CL_L) s.lt = 1.f;                      /* a pressed shoulder button reads as a fully pressed trigger */
        if (s.buttons & RT_CL_R) s.rt = 1.f;
        uint16_t hold = s.buttons, was = prev[chan];
        prev[chan] = hold;
        if (hold) g_nheld[chan]++;
        if (hold & ~was) g_ntrig[chan]++;
        for (uint32_t o = 0; o < KS_SIZE; o += 4) rt_w32(c, buf + o, 0);
        rt_w8(c, buf + KS_DEV, DEV_CLASSIC); rt_w8(c, buf + KS_ERR, 0); rt_w8(c, buf + KS_DPD, 0); rt_w8(c, buf + KS_FMT, FMT_CLASSIC_BTN_ACC_DPD);
        rt_w32(c, buf + KS_CL + 0, hold); rt_w32(c, buf + KS_CL + 4, (uint16_t)(hold & ~was)); rt_w32(c, buf + KS_CL + 8, (uint16_t)(was & ~hold));
        put_f(c, buf + KS_CL + 0x0C, s.lx); put_f(c, buf + KS_CL + 0x10, s.ly); put_f(c, buf + KS_CL + 0x14, s.rx); put_f(c, buf + KS_CL + 0x18, s.ry);
        put_f(c, buf + KS_CL + 0x1C, s.lt); put_f(c, buf + KS_CL + 0x20, s.rt);
        got = 1;
    }
    if (errp) rt_w32(c, errp, (uint32_t)err);
    c->r[3] = got;
}
