/* Hardware register window (0xCC00xxxx / 0xCD00xxxx). Bring-up model: registers act
 * like plain memory (write then read back), every distinct access is recorded, and
 * specific registers get real behavior in rt_mmio_special() as boot demands. */
#include "rt.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SLOTS 16384
typedef struct { uint32_t key, val; uint8_t used; } Slot;
static Slot tab[SLOTS];
int rt_mmio_log = 0;                     /* 1 = print every access */
uint64_t rt_wgpipe_bytes = 0;            /* GX command bytes written to 0xCC008000 */
static struct { uint32_t addr; uint8_t write, size; uint32_t val; } seen[1024];
static unsigned nseen;
static unsigned long long total;
static struct { uint32_t addr, val; uint8_t write; } recent[16];
static unsigned recent_pos;

static Slot *slot_for(uint32_t key) {
    unsigned h = (key >> 2) * 2654435761u % SLOTS;
    while (tab[h].used && tab[h].key != key) h = (h + 1) % SLOTS;
    if (!tab[h].used) { tab[h].used = 1; tab[h].key = key; }
    return &tab[h];
}
static void note(uint32_t addr, int write, int size, uint32_t val) {
    total++;
    recent[recent_pos & 15].addr = addr; recent[recent_pos & 15].val = val; recent[recent_pos & 15].write = (uint8_t)write;
    recent_pos++;
    if (rt_mmio_log) fprintf(stderr, "MMIO %s%d 0x%08X %s 0x%X\n", write ? "write" : "read", size * 8, addr,
                             write ? "<-" : "->", val);
    for (unsigned i = 0; i < nseen; i++)
        if (seen[i].addr == addr && seen[i].write == write) return;
    if (nseen < 1024) { seen[nseen].addr = addr; seen[nseen].write = (uint8_t)write; seen[nseen].size = (uint8_t)size;
                        seen[nseen].val = val; nseen++; }
}
/* ---- EXI (external interface): channel 0 device 1 is the IPL chip holding the RTC and SRAM ---- */
#include <time.h>
typedef struct { uint32_t csr, mar, len, cr, data; } ExiChan;
static ExiChan exi[3];
static struct { uint32_t cmd; int got, pos; int region; } ipl;      /* region: 1 RTC, 2 SRAM, 3 UART, 4 ROM */
static uint8_t sram[64];

static void ipl_reset(void) { memset(&ipl, 0, sizeof ipl); }
static void ipl_write_byte(uint8_t b) {
    if (ipl.got < 4) {
        ipl.cmd = (ipl.cmd << 8) | b;
        if (++ipl.got == 4) {
            uint32_t k = ipl.cmd & 0x7FFFFF00u;
            ipl.region = k == 0x20000000u ? 1 : k == 0x20000100u ? 2 : k == 0x20010000u ? 3 : 4;
            ipl.pos = 0;
        }
    } else if (ipl.region == 2 && (ipl.cmd >> 31)) sram[ipl.pos++ & 63] = b;
}
static uint8_t ipl_read_byte(void) {
    if (ipl.got < 4) return 0;
    if (ipl.region == 1) {
        uint32_t t = (uint32_t)(time(0) - 946684800);   /* seconds since 2000-01-01 */
        return (uint8_t)(t >> (24 - 8 * (ipl.pos++ & 3)));
    }
    if (ipl.region == 2) return sram[ipl.pos++ & 63];
    return 0;
}
static void exi_transfer(Ctx *c, int ch) {
    ExiChan *e = &exi[ch];
    int dma = (e->cr >> 1) & 1, rw = (e->cr >> 2) & 3;
    unsigned len = dma ? e->len : ((e->cr >> 4) & 3) + 1;
    int on_ipl = ch == 0 && ((e->csr >> 7) & 7) == 2;
    uint8_t *mem = dma ? rt_ptr(c, 0x80000000u | e->mar) : 0;
    if (rw == 1 || rw == 2) {                                   /* write (or read/write) */
        for (unsigned i = 0; i < len; i++) {
            uint8_t b = dma ? mem[i] : (uint8_t)(e->data >> (24 - 8 * i));
            if (on_ipl) ipl_write_byte(b);
        }
    }
    if (rw == 0 || rw == 2) {                                   /* read */
        uint32_t out = 0;
        for (unsigned i = 0; i < len; i++) {
            uint8_t b = on_ipl ? ipl_read_byte() : 0;
            if (dma) mem[i] = b; else out |= (uint32_t)b << (24 - 8 * i);
        }
        if (!dma) e->data = out;
    }
    if (rt_chk_addr) rt_chk_hook(0xAAAA0001u);                  /* debug marker: after an EXI transfer */
    e->cr &= ~1u;                                               /* transfer done */
    e->csr |= 0x8;                                              /* TCINT */
}
/* ---- DSP interface (0xCC005000): control register + mailboxes. No DSP ucode is run; the DSP is
 * modeled only as far as the SDK's init handshake needs (reset clears, IROM posts 0x8071FEED). ---- */
static struct { uint16_t ctrl; uint32_t to_dsp, from_dsp; int to_valid, from_valid; } dsp;
static uint8_t *aram;                                         /* 16 MB auxiliary RAM, reached only through DMA */
static uint32_t ar_mm, ar_ar;
static void ar_dma(Ctx *c, uint32_t cnt) {
    uint32_t len = cnt & 0x7FFFFFFFu, to_main = cnt >> 31;
    if (!aram) aram = calloc(1, 0x1000000);
    for (uint32_t i = 0; i < len; i++) {
        uint32_t a = ar_ar + i;
        uint8_t *mm = rt_ptr(c, 0x80000000u | (ar_mm + i));
        if (to_main) *mm = a < 0x1000000 ? aram[a] : 0;
        else if (a < 0x1000000) aram[a] = *mm;
    }
    if (rt_chk_addr) rt_chk_hook(0xAAAA0002u);                  /* debug marker: after an ARAM DMA */
    dsp.ctrl |= 0x20;                                           /* ARINT: DMA complete */
}
static struct { uint32_t cr, vr, it, base_cnt; uint64_t base_ns; } ai;
static uint64_t ai_now_ns(void);
/* ---- AI DMA (the DSP interface's audio streaming buffer, 0xCC005030..503A). The SDK points it at a small PCM buffer
 * (AX uses 3 ms frames: 0x180 bytes = 96 stereo samples at 32 kHz) and gets an AIINT (control register bit 3) each time the
 * buffer has been played; that interrupt is what clocks the whole audio engine (AX frames, and Wwise on top of it).
 * Registers: 5030 start address bits 16..28, 5032 start address bits 5..15, 5036 bit 15 = playing, bits 0..14 = length in
 * 32-byte blocks, 503A = blocks left. Sample rate: AI control register bit 6 (DSPFR) 0 = 32 kHz, 1 = 48 kHz.
 * Timing is wall-clock; a guest that falls behind gets one coalesced interrupt, like the pending flag of the real chip.
 * No audio is output yet: the buffer contents are ignored. ---- */
static struct { uint16_t hi, lo, ctl; uint64_t t0_ns; } aid;
volatile uint32_t rt_aid_period_us;                           /* 0 while stopped; read by the timer thread to wake the guest */
static uint64_t aid_period_ns(void) {
    uint64_t bytes = (uint64_t)(aid.ctl & 0x7FFF) * 32;
    return bytes ? bytes / 4 * 1000000000ull / ((ai.cr & 0x40) ? 48000ull : 32000ull) : 0;
}
static void aid_update(void) {
    if (!(aid.ctl & 0x8000)) return;
    uint64_t per = aid_period_ns(); if (!per) return;
    uint64_t now = ai_now_ns();
    if (now - aid.t0_ns >= per) { dsp.ctrl |= 8; aid.t0_ns = now - (now - aid.t0_ns) % per; }       /* AIINT */
}
static int aid_access(uint32_t off, int write, uint32_t *v) {
    switch (off) {
    case 0x5030: if (write) aid.hi = (uint16_t)(*v & 0x1FFF); else *v = aid.hi; return 1;
    case 0x5032: if (write) aid.lo = (uint16_t)(*v & 0xFFE0); else *v = aid.lo; return 1;
    case 0x5036:
        if (!write) { *v = aid.ctl; return 1; }
        if (((*v ^ aid.ctl) & 0x8000) || (*v & 0x7FFF) != (aid.ctl & 0x7FFF)) aid.t0_ns = ai_now_ns();    /* started or re-sized: restart the buffer */
        aid.ctl = (uint16_t)(*v & 0xFFFF);
        rt_aid_period_us = (aid.ctl & 0x8000) ? (uint32_t)(aid_period_ns() / 1000) : 0;
        if (getenv("RT_DSP_LOG")) fprintf(stderr, "[dsp] AI DMA %s: buffer 0x%08X, %u bytes, period %u us\n", (aid.ctl & 0x8000) ? "started" : "stopped",
                                          ((uint32_t)aid.hi << 16) | aid.lo, (aid.ctl & 0x7FFFu) * 32, rt_aid_period_us);
        return 1;
    case 0x503A: {
        if (write) return 1;
        uint64_t per = aid_period_ns(), len = aid.ctl & 0x7FFF;
        if (!(aid.ctl & 0x8000) || !per) { *v = 0; return 1; }
        uint64_t done = (ai_now_ns() - aid.t0_ns) * len / per;
        *v = (uint32_t)(len - (done > len ? len : done));
        return 1;
    }
    }
    return 0;
}
static int dsp_special_(Ctx *c, uint32_t off, int write, uint32_t *v);
/* The DSP's boot ROM takes the ucode address/lengths as mails (0x80F3A001 iram_mmem_addr, 0x80F3C002 iram_len, 0x80F3A002 iram_addr,
 * 0x80F3B002 dram_len, 0x80F3D001 init_vec, each followed by its value), then jumps to the uploaded ucode, which announces itself with
 * the mail 0xDCD10000 (DSP_INIT) and a DSP interrupt. No ucode runs here: when the init vector arrives we post that announcement. */
static uint32_t pi_intmr_dbg(void);
/* DSP -> CPU mails go through a small queue: the real mailbox holds one mail and the DSP waits until the CPU has read it. */
static uint32_t dsp_mq[16]; static unsigned dsp_mq_head, dsp_mq_tail;
static void dsp_mail_pump(void) {
    if (dsp.from_valid || dsp_mq_head == dsp_mq_tail) return;
    dsp.from_dsp = dsp_mq[dsp_mq_head++ % 16]; dsp.from_valid = 1; dsp.ctrl |= 0x80; rt_irq_recompute();                 /* DSPINT */
    if (getenv("RT_DSP_LOG")) fprintf(stderr, "[dsp] DSP posts mail 0x%08X; DSP control now 0x%X, PI interrupt mask 0x%X\n", dsp.from_dsp, dsp.ctrl, pi_intmr_dbg());
}
static void dsp_post_mail(uint32_t m) { dsp_mq[dsp_mq_tail++ % 16] = m; dsp_mail_pump(); }
static void dsp_cpu_mail(Ctx *c, uint32_t m) {             /* the mailbox keeps 31 bits: bit 15 of the high half is the status flag */
    static uint32_t cmd, iram_mmem, iram_len, iram_addr; static int payload, nmail;
    m &= 0x7FFFFFFFu;
    if (payload) {
        payload = 0;
        if (cmd == 0x00F3A001u) iram_mmem = m;
        if (cmd == 0x00F3A002u) iram_len = m;
        if (cmd == 0x00F3C002u) iram_addr = m;
        if (cmd == 0x00F3D001u) {
            const char *dir = getenv("RT_DSP_DUMP");              /* RT_DSP_DUMP=dir: save each uploaded ucode image (stays local: it comes from the disc) */
            if (getenv("RT_DSP_LOG") || dir) fprintf(stderr, "[dsp] boot task: ucode at 0x%08X, %u bytes -> IRAM 0x%X, entry 0x%X\n", 0x80000000u | iram_mmem, iram_len, iram_addr, m);
            if (dir && iram_len && iram_len <= 0x10000) {
                char path[512]; snprintf(path, sizeof path, "%s/dsp_ucode_%08X.bin", dir, 0x80000000u | iram_mmem);
                FILE *f = fopen(path, "wb");
                if (f) { fwrite(rt_ptr(c, 0x80000000u | iram_mmem), 1, iram_len, f); fclose(f); fprintf(stderr, "[dsp] wrote %s\n", path); }
            }
            dsp_post_mail(0xDCD10000u);
        }
        return;
    }
    if ((m >> 16) == 0x00F3u) { cmd = m; payload = 1; return; }
    /* The AX ucode's mail protocol (as the SDK's DSP task layer and AX library use it; no mixing is done yet):
     *   CPU 0xBABExxxx (xxxx = list size), then the list's physical address -> the DSP runs the command list, then yields (DSP_YIELD);
     *   CPU 0xCDD10001 (MAIL_RESUME-style request) -> DSP_RESUME; CPU 0xCDD10003 (continue) needs no answer. */
    static int next_is_list; static uint32_t list_size; static int nlists;
    if (next_is_list) {
        next_is_list = 0;
        if (getenv("RT_DSP_LOG") && nlists < 3) {
            fprintf(stderr, "[dsp] AX command list #%d at 0x%08X, %u words:", nlists, m, list_size);
            for (uint32_t i = 0; i < list_size && i < 64; i++) fprintf(stderr, "%s%04X", i % 16 ? " " : "\n    ", rt_r16(c, 0x80000000u | (m + 2 * i)));
            fputc('\n', stderr);
        }
        nlists++;
        dsp_post_mail(0xDCD10002u);                               /* DSP_YIELD: list done */
        return;
    }
    if ((m & 0x7FFF0000u) == 0x3ABE0000u) { next_is_list = 1; list_size = m & 0xFFFF; return; }
    if (m == 0x4DD10001u) { dsp_post_mail(0xDCD10001u); return; }  /* DSP_RESUME */
    if (m == 0x4DD10003u) return;
    if (getenv("RT_DSP_LOG") && nmail++ < 200) fprintf(stderr, "[dsp] CPU mail 0x%08X is not understood (no answer)\n", m);
}
/* RT_DSP_LOG=1: log DSP interface accesses (mailboxes, control, ARAM DMA), skipping repeats of the same access. */
static int dsp_special(Ctx *c, uint32_t off, int write, uint32_t *v) {
    static int on = -1, last_off = -1, last_w = -1; static uint32_t last_v; static unsigned n;
    if (on < 0) on = getenv("RT_DSP_LOG") != 0;
    uint32_t in = write ? *v : 0;
    int r = dsp_special_(c, off, write, v);
    if (on && r && n < 400) {
        uint32_t val = write ? in : *v;
        if ((int)off != last_off || write != last_w || val != last_v) {
            n++; last_off = (int)off; last_w = write; last_v = val;
            fprintf(stderr, "[dsp] %s 0x%04X %s 0x%X\n", write ? "write" : "read ", off, write ? "<-" : "->", val);
        }
    }
    return r;
}
static int dsp_special_(Ctx *c, uint32_t off, int write, uint32_t *v) {
    switch (off) {
    case 0x5030: case 0x5032: case 0x5036: case 0x503A: return aid_access(off, write, v);
    case 0x5020: if (write) ar_mm = *v & 0x03FFFFFF; else *v = ar_mm; return 1;
    case 0x5024: if (write) ar_ar = *v; else *v = ar_ar; return 1;
    case 0x5028: if (write) { if (*v & 0x7FFFFFFFu) ar_dma(c, *v); } else *v = 0; return 1;
    case 0x5000: case 0x5002:                                   /* CPU -> DSP mailbox */
        if (!write) { *v = (off == 0x5000 ? (dsp.to_dsp >> 16) | (dsp.to_valid ? 0x8000 : 0) : dsp.to_dsp & 0xFFFF); return 1; }
        if (off == 0x5000) dsp.to_dsp = (dsp.to_dsp & 0xFFFF) | ((*v & 0x7FFF) << 16);
        else { dsp.to_dsp = (dsp.to_dsp & 0xFFFF0000u) | (*v & 0xFFFF); dsp.to_valid = 0; /* DSP consumes instantly */ dsp_cpu_mail(c, dsp.to_dsp); }
        return 1;
    case 0x5004: case 0x5006:                                   /* DSP -> CPU mailbox */
        if (write) return 1;
        if (off == 0x5004) *v = (dsp.from_dsp >> 16) | (dsp.from_valid ? 0x8000 : 0);
        else { *v = dsp.from_dsp & 0xFFFF; dsp.from_valid = 0; dsp_mail_pump(); }  /* reading the low half consumes the mail; the next one moves in */
        return 1;
    case 0x500A: {                                              /* DSP control */
        aid_update();
        if (!write) { *v = dsp.ctrl; return 1; }
        uint16_t nv = (uint16_t)*v, was_halt = dsp.ctrl & 4;
        uint16_t flags = dsp.ctrl & 0x00A8;                     /* AI(3) ARAM(5) DSP(7) interrupt flags: write 1 to clear */
        dsp.ctrl = (uint16_t)((nv & ~0x00A8 & ~0x0201 & ~0x0002) | (flags & ~nv));
        if (nv & 1) { dsp.to_valid = dsp.from_valid = 0; dsp.to_dsp = dsp.from_dsp = 0; dsp_mq_head = dsp_mq_tail = 0; }   /* reset completes at once */
        if (was_halt && !(dsp.ctrl & 4)) { dsp.from_dsp = 0x8071FEEDu; dsp.from_valid = 1; }  /* IROM boot mail */
        rt_irq_recompute();
        return 1;
    }
    }
    return 0;
}
/* ---- AI (audio interface, 0x0D006C00 on the Wii, 0x0C006C00 GameCube-style): control, volume, sample counter,
 * interrupt timing. No sound is produced yet. The sample counter runs in real time while PSTAT is set, because the
 * SDK's AIInit measures it: with the counter stuck at 0 the main thread spun on 0xCD006C08 forever.
 * AICR bits: 0 PSTAT (play), 1 AFR (0 = 32 kHz, 1 = 48 kHz), 2 AIINTMSK, 3 AIINT (write 1 clears), 4 AIINTVLD,
 * 5 SCRESET (write 1 resets the counter), 6 DSPFR. The AI interrupt itself is not raised yet. ---- */
static uint64_t ai_now_ns(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec; }
static uint32_t ai_count(void) {
    if (!(ai.cr & 1)) return ai.base_cnt;
    return ai.base_cnt + (uint32_t)((ai_now_ns() - ai.base_ns) * ((ai.cr & 2) ? 48000ull : 32000ull) / 1000000000ull);
}
static int ai_special(uint32_t off, int write, uint32_t *v) {
    switch (off) {
    case 0x00:
        if (!write) { *v = ai.cr; return 1; }
        ai.base_cnt = (*v & 0x20) ? 0 : ai_count();             /* commit the elapsed samples under the old settings */
        ai.base_ns = ai_now_ns();
        ai.cr = (*v & ~0x28u) | (ai.cr & 0x08u & ~*v);
        return 1;
    case 0x04: if (write) ai.vr = *v; else *v = ai.vr; return 1;
    case 0x08: if (!write) *v = ai_count(); return 1;
    case 0x0C: if (write) ai.it = *v; else *v = ai.it; return 1;
    }
    return 0;
}
/* ---- PI interrupt cause/mask, Hollywood IPC (IOS mailbox), VI display interrupts ---- */
uint32_t rt_gx_pe_irq_bits(void);
int rt_gx_pe_access(uint32_t a, int write, int size, uint32_t *v);
void rt_gx_fifo_write(Ctx *c, uint64_t v, int size);
static uint32_t pi_intmr, hw_irqflag, hw_irqmask, vi_di[4];
static struct { uint32_t ppcmsg, armmsg; int y1, y2, iy1, iy2; } ipc;
static uint32_t reply_q[64]; static unsigned rq_head, rq_tail;
static void ipc_update(void);
static void ipc_try_deliver(void) {                      /* IOS delivers one reply at a time, after the PPC acked the last */
    if (!ipc.y1 && rq_head != rq_tail) { ipc.armmsg = reply_q[rq_head++ % 64]; ipc.y1 = 1; }
}
void rt_ipc_post_reply(Ctx *c, uint32_t req) {           /* a finished request: queue its reply */
    (void)c; reply_q[rq_tail++ % 64] = req; ipc_try_deliver(); ipc_update();
}
static void ipc_update(void) {
    if ((ipc.y1 && ipc.iy1) || (ipc.y2 && ipc.iy2)) hw_irqflag |= 0x40000000u; else hw_irqflag &= ~0x40000000u;
    rt_irq_recompute();
}
static uint32_t pi_intmr_dbg(void) { return pi_intmr; }
static uint32_t pi_intsr(void) {
    uint32_t v = 0;
    aid_update();
    if (hw_irqflag & hw_irqmask) v |= 1u << 14;                          /* Hollywood (IPC, ...) */
    v |= rt_gx_pe_irq_bits();                                            /* pixel engine: token (9), finish (10) */
    if (((dsp.ctrl & 0x80) && (dsp.ctrl & 0x100)) || ((dsp.ctrl & 0x20) && (dsp.ctrl & 0x40)) || ((dsp.ctrl & 8) && (dsp.ctrl & 0x10)))
        v |= 1u << 6;                                                    /* DSP (6): DSPINT, ARAM DMA done, AI DMA done, each with its mask bit */
    for (int i = 0; i < 4; i++) if ((vi_di[i] & 0x80000000u) && (vi_di[i] & 0x10000000u)) v |= 1u << 8;   /* VI */
    return v;
}
int rt_hw_ext_pending(void) { return (pi_intsr() & pi_intmr) != 0; }
void rt_hw_vi_retrace(void) { for (int i = 0; i < 4; i++) if (vi_di[i] & 0x10000000u) vi_di[i] |= 0x80000000u; }
static int hw_special(Ctx *c, uint32_t a, int write, uint32_t *v) {
    uint32_t blk = a & 0x1FFFFF00u, off = a & 0xFF;
    if (blk == 0x0C003000u && off == 0x00) { if (!write) *v = pi_intsr(); return 1; }
    if (blk == 0x0C003000u && off == 0x04) { if (write) { pi_intmr = *v; rt_irq_recompute(); } else *v = pi_intmr; return 1; }
    if (blk != 0x0D000000u) return 0;
    switch (off) {
    case 0x00: if (write) ipc.ppcmsg = *v; else *v = ipc.ppcmsg; return 1;
    case 0x08: if (!write) *v = ipc.armmsg; return 1;
    case 0x04:
        if (!write) { *v = (uint32_t)(ipc.y2 << 1 | ipc.y1 << 2 | ipc.iy1 << 4 | ipc.iy2 << 5); return 1; }
        if (*v & 4) { ipc.y1 = 0; ipc_try_deliver(); }                   /* write 1 clears the reply flag; next queued reply */
        if (*v & 2) ipc.y2 = 0;                                          /* ... and the ack flag */
        ipc.iy1 = (*v >> 4) & 1; ipc.iy2 = (*v >> 5) & 1;
        if (*v & 1) {                                                    /* request sent: ack now, reply now or later */
            ipc.y2 = 1;
            uint32_t req = ipc.ppcmsg;
            int pend = rt_ios_request(c, req);
            if (rt_chk_addr) rt_chk_hook(0xAAAA0003u);               /* debug marker: after an IOS request */
            if (pend == 0) { reply_q[rq_tail++ % 64] = req; ipc_try_deliver(); }
        }
        ipc_update();
        return 1;
    case 0x30: if (write) { hw_irqflag &= ~(*v & ~0x40000000u); ipc_update(); } else *v = hw_irqflag; return 1;
    case 0x34: if (write) { hw_irqmask = *v; rt_irq_recompute(); } else *v = hw_irqmask; return 1;
    }
    return 0;
}
/* Return 1 and set *v if the register has special behavior. */
static int mmio_special(Ctx *c, uint32_t addr, int write, uint32_t *v) {
    if (hw_special(c, addr, write, v)) return 1;
    uint32_t off = addr & 0xFFFF;
    if ((addr & 0x1FFF0000u) != 0x0D000000u && (addr & 0x1FFF0000u) != 0x0C000000u) return 0;
    if ((addr & 0x1FFF0000u) == 0x0C000000u && off >= 0x5000 && off < 0x5200) return dsp_special(c, off, write, v);
    if (off >= 0x6C00 && off < 0x6C10) return ai_special(off & 0xF, write, v);
    if (off < 0x6800 || off >= 0x6800 + 3 * 0x14) return 0;
    int ch = (int)((off - 0x6800) / 0x14);
    ExiChan *e = &exi[ch];
    switch ((off - 0x6800) % 0x14) {
    case 0x00:
        if (!write) { *v = e->csr; return 1; }
        if (((*v >> 7) & 7) != ((e->csr >> 7) & 7) && ch == 0) ipl_reset();   /* (de)selection restarts a session */
        e->csr = (e->csr & ~0x80Au & ~0x3FFu) | (*v & 0x3FFu & ~0x80Au) | (e->csr & 0x80Au & ~*v);
        return 1;
    case 0x04: if (write) e->mar = *v; else *v = e->mar; return 1;
    case 0x08: if (write) e->len = *v; else *v = e->len; return 1;
    case 0x0C:
        if (!write) { *v = e->cr; return 1; }
        e->cr = *v;
        if (e->cr & 1) exi_transfer(c, ch);
        return 1;
    default: if (write) e->data = *v; else *v = e->data; return 1;
    }
}
/* VI display interrupt registers DI0..3 (0xCC002030..3C): 32-bit registers the SDK writes as halves.
 * Bit 28 enables, bit 31 is the status; software clears the status by writing it as 0. */
static int vi_di_access(uint32_t a, int write, int size, uint32_t *v) {
    if (a < 0x0C002030u || a >= 0x0C002040u) return 0;
    uint32_t *r = &vi_di[(a - 0x0C002030u) >> 2];
    unsigned sh = size == 4 ? 0 : size == 2 ? 16 - 8 * (a & 2) : 24 - 8 * (a & 3);
    uint32_t mask = size == 4 ? 0xFFFFFFFFu : size == 2 ? 0xFFFFu : 0xFFu;
    if (!write) { *v = (*r >> sh) & mask; return 1; }
    uint32_t old = *r, nw = (old & ~(mask << sh)) | ((*v & mask) << sh);
    *r = (nw & 0x7FFFFFFFu) | (old & nw & 0x80000000u);
    rt_irq_recompute();
    return 1;
}
uint64_t rt_mmio_read(Ctx *c, uint32_t addr, int size) {
    uint32_t a = addr & 0x1FFFFFFFu, v = 0;
    if (vi_di_access(a, 0, size, &v)) { note(0xC0000000u | (a & 0x0FFFFFFF), 0, size, v); return v; }
    if (a >= 0x0C001000u && a < 0x0C001040u && rt_gx_pe_access(a, 0, size, &v)) return v;
    Slot *s = slot_for(a & ~3u);
    if (!mmio_special(c, a, 0, &v)) {
        v = s->val;
        if (size == 1) v = (v >> (24 - 8 * (a & 3))) & 0xFF;
        else if (size == 2) v = (v >> (16 - 8 * (a & 2))) & 0xFFFF;
    }
    note(0xC0000000u | (a & 0x0FFFFFFF), 0, size, v);
    return v;
}
void rt_mmio_write(Ctx *c, uint32_t addr, uint64_t val, int size) {
    uint32_t a = addr & 0x1FFFFFFFu, v = (uint32_t)val;
    if (size == 2) v &= 0xFFFFu; else if (size == 1) v &= 0xFFu;      /* rt_w16/rt_w8 hand over the whole register */
    note(0xC0000000u | (a & 0x0FFFFFFF), 1, size, v);
    if (vi_di_access(a, 1, size, &v)) return;
    if (a >= 0x0C001000u && a < 0x0C001040u && rt_gx_pe_access(a, 1, size, &v)) return;
    if ((a & ~0xFFu) == 0x0C008000u) { rt_wgpipe_bytes += (unsigned)size; rt_gx_fifo_write(c, val, size); return; }   /* write-gather pipe */
    if (mmio_special(c, a, 1, &v)) return;
    Slot *s = slot_for(a & ~3u);
    if (size == 4) s->val = v;
    else if (size == 2) { unsigned sh = 16 - 8 * (a & 2); s->val = (s->val & ~(0xFFFFu << sh)) | ((v & 0xFFFFu) << sh); }
    else if (size == 1) { unsigned sh = 24 - 8 * (a & 3); s->val = (s->val & ~(0xFFu << sh)) | ((v & 0xFFu) << sh); }
}
void rt_mmio_summary(void) {
    fprintf(stderr, "last MMIO accesses (oldest first):\n");
    for (unsigned i = recent_pos > 16 ? 16 : recent_pos; i >= 1; i--) {
        unsigned k = (recent_pos - i) & 15;
        fprintf(stderr, "  %s 0x%08X %s 0x%X\n", recent[k].write ? "write" : "read ", recent[k].addr,
                recent[k].write ? "<-" : "->", recent[k].val);
    }
    fprintf(stderr, "MMIO: %llu accesses, %u distinct (addr,rw) pairs, %llu GX FIFO bytes\n",
            total, nseen, (unsigned long long)rt_wgpipe_bytes);
    for (unsigned i = 0; i < nseen && i < 40; i++)
        fprintf(stderr, "  %s%d 0x%08X %s 0x%X\n", seen[i].write ? "write" : "read", seen[i].size * 8, seen[i].addr,
                seen[i].write ? "<-" : "->", seen[i].val);
}
