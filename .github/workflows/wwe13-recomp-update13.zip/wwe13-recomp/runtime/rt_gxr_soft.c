/* Software GX rasterizer backend: a reference implementation that draws into a CPU copy of the EFB. Used to check the front end (frames are
 * dumped to PNG with RT_FRAME_DUMP=<dir>) and as the fallback when no GPU backend is available. Slow, but exact enough to see what the
 * game draws. TEV follows the GX register semantics as I remember them (float math, not the hardware's 8-bit fixed point). */
#include "rt_gxr.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

static uint8_t efb[GXR_EFB_W * GXR_EFB_H * 4];
static float zbuf[GXR_EFB_W * GXR_EFB_H];
const uint8_t *gxr_soft_efb(void) { return efb; }

/* ---------------------------------------------------------------- PNG output (stored deflate blocks: no zlib needed) */
static uint32_t crc_table[256]; static int crc_init;
static uint32_t crc32_update(uint32_t crc, const uint8_t *p, size_t n) {
    if (!crc_init) { for (uint32_t i = 0; i < 256; i++) { uint32_t c = i; for (int k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320u ^ (c >> 1) : c >> 1; crc_table[i] = c; } crc_init = 1; }
    crc = ~crc; while (n--) crc = crc_table[(crc ^ *p++) & 255] ^ (crc >> 8); return ~crc;
}
static void be32w(uint8_t *p, uint32_t v) { p[0] = (uint8_t)(v >> 24); p[1] = (uint8_t)(v >> 16); p[2] = (uint8_t)(v >> 8); p[3] = (uint8_t)v; }
static void chunk(FILE *f, const char *type, const uint8_t *d, uint32_t n) {
    uint8_t h[8]; be32w(h, n); memcpy(h + 4, type, 4); fwrite(h, 1, 8, f);
    uint32_t crc = crc32_update(0, (const uint8_t *)type, 4); if (n) { fwrite(d, 1, n, f); crc = ~crc; crc = crc32_update(~crc, d, n); }
    uint8_t t[4]; be32w(t, crc); fwrite(t, 1, 4, f);
}
int gxr_png_write(const char *path, int w, int h, const uint8_t *rgba) {
    FILE *f = fopen(path, "wb"); if (!f) return -1;
    size_t rowb = (size_t)w * 3 + 1, raw = rowb * (size_t)h; uint8_t *r = malloc(raw);
    for (int y = 0; y < h; y++) { r[y * rowb] = 0; for (int x = 0; x < w; x++) memcpy(r + y * rowb + 1 + (size_t)x * 3, rgba + ((size_t)y * w + x) * 4, 3); }
    size_t nblk = (raw + 65534) / 65535, zlen = 2 + raw + nblk * 5 + 4; uint8_t *z = malloc(zlen), *q = z;
    *q++ = 0x78; *q++ = 0x01; uint32_t a = 1, b = 0;
    for (size_t o = 0; o < raw; ) {
        size_t n = raw - o > 65535 ? 65535 : raw - o; *q++ = o + n == raw; *q++ = (uint8_t)n; *q++ = (uint8_t)(n >> 8); *q++ = (uint8_t)~n; *q++ = (uint8_t)(~n >> 8);
        memcpy(q, r + o, n); q += n;
        for (size_t i = 0; i < n; i++) { a = (a + r[o + i]) % 65521; b = (b + a) % 65521; }
        o += n;
    }
    be32w(q, b << 16 | a); q += 4;
    static const uint8_t sig[8] = { 137, 80, 78, 71, 13, 10, 26, 10 }; fwrite(sig, 1, 8, f);
    uint8_t ih[13]; be32w(ih, (uint32_t)w); be32w(ih + 4, (uint32_t)h); ih[8] = 8; ih[9] = 2; ih[10] = ih[11] = ih[12] = 0;
    chunk(f, "IHDR", ih, 13); chunk(f, "IDAT", z, (uint32_t)(q - z)); chunk(f, "IEND", NULL, 0);
    fclose(f); free(r); free(z); return 0;
}

/* ---------------------------------------------------------------- frame sink */
static const char *s_dir; static int s_init, s_every = 1, s_max = 10, s_shown, s_all; static unsigned s_at[64]; static int s_nat;
static void sink_init(void) {
    if (s_init) return;
    s_init = 1; s_dir = getenv("RT_FRAME_DUMP");
    if (getenv("RT_FRAME_EVERY")) s_every = atoi(getenv("RT_FRAME_EVERY"));
    if (getenv("RT_FRAME_MAX")) s_max = atoi(getenv("RT_FRAME_MAX"));
    s_all = getenv("RT_FRAME_ALL") != NULL;                                 /* draw every frame, not only the dumped ones (slow) */
    const char *s = getenv("RT_FRAME_AT");                                  /* RT_FRAME_AT=100,2000: dump exactly these frame numbers */
    while (s && *s && s_nat < 64) { s_at[s_nat++] = (unsigned)strtoul(s, (char **)&s, 10); if (*s == ',') s++; else break; }
    if (s_dir) mkdir(s_dir, 0777);
}
static int frame_hit(unsigned n) {
    if (!s_dir || s_shown >= s_max) return 0;
    int hit = s_nat ? 0 : (n % (unsigned)(s_every > 0 ? s_every : 1) == 0);
    for (int i = 0; i < s_nat; i++) if (s_at[i] == n) hit = 1;
    return hit;
}
/* Is the frame with this number going to be dumped? The software backend only draws those (it is far slower than the game). */
int gxr_frame_dump_wanted(unsigned n) { sink_init(); return frame_hit(n); }
int gxr_frame_wanted(unsigned n) { sink_init(); return s_all || !s_dir || frame_hit(n); }
__attribute__((weak)) void gxr_frame_sink(const uint8_t *rgba, int w, int h) {
    sink_init();
    unsigned n = gxr_frames();                                              /* the frame being presented: not counted yet */
    if (!frame_hit(n)) return;
    char path[512]; snprintf(path, sizeof path, "%s/frame_%05u.png", s_dir, n);
    if (gxr_png_write(path, w, h, rgba) == 0) { s_shown++; fprintf(stderr, "[gxr] frame %u (%dx%d) -> %s\n", n, w, h, path); }
}

/* ---------------------------------------------------------------- rasterizer */
static unsigned long long st_pix_tested, st_pix_shaded, st_draws_done, st_draws_skipped;
typedef struct { float x, y, z, iw; float c[2][4]; float t[8][3]; } SV;          /* screen vertex; attributes already multiplied by 1/w */

static float clampf(float v, float lo, float hi) { return v < lo ? lo : v > hi ? hi : v; }
static int wrapc(int i, int n, int mode) {
    if (mode == 1) { i %= n; return i < 0 ? i + n : i; }
    if (mode == 2) { int p = 2 * n; i %= p; if (i < 0) i += p; return i < n ? i : p - 1 - i; }
    return i < 0 ? 0 : i >= n ? n - 1 : i;
}
static void sample(const GxrFrag *f, int unit, float s, float t, float *o) {
    const GxrTex *tx = f->tex[unit];
    if (!tx) { o[0] = o[1] = o[2] = o[3] = 1.f; return; }
    float u = s * tx->w, v = t * tx->h;
    if (!f->texlin[unit]) {
        int x = wrapc((int)floorf(u), tx->w, f->texwrap[unit][0]), y = wrapc((int)floorf(v), tx->h, f->texwrap[unit][1]);
        const uint8_t *p = tx->rgba + ((size_t)y * tx->w + x) * 4; for (int k = 0; k < 4; k++) o[k] = p[k] / 255.f; return;
    }
    u -= 0.5f; v -= 0.5f; int x0 = (int)floorf(u), y0 = (int)floorf(v); float fx = u - x0, fy = v - y0;
    int xs[2] = { wrapc(x0, tx->w, f->texwrap[unit][0]), wrapc(x0 + 1, tx->w, f->texwrap[unit][0]) }, ys[2] = { wrapc(y0, tx->h, f->texwrap[unit][1]), wrapc(y0 + 1, tx->h, f->texwrap[unit][1]) };
    for (int k = 0; k < 4; k++) {
        float a = tx->rgba[((size_t)ys[0] * tx->w + xs[0]) * 4 + k], b = tx->rgba[((size_t)ys[0] * tx->w + xs[1]) * 4 + k];
        float c = tx->rgba[((size_t)ys[1] * tx->w + xs[0]) * 4 + k], d = tx->rgba[((size_t)ys[1] * tx->w + xs[1]) * 4 + k];
        o[k] = ((a + (b - a) * fx) * (1 - fy) + (c + (d - c) * fx) * fy) / 255.f;
    }
}
static float konst_sel(const GxrFrag *f, int sel, int comp, int is_alpha) {
    static const float k[8] = { 1.f, 7.f / 8, 3.f / 4, 5.f / 8, 1.f / 2, 3.f / 8, 1.f / 4, 1.f / 8 };
    if (sel < 8) return k[sel];
    if (!is_alpha && sel >= 12 && sel <= 15) return f->konst[sel - 12][comp] / 255.f;
    if (sel >= 16 && sel <= 31) return f->konst[(sel - 16) & 3][(sel - 16) >> 2] / 255.f;        /* K0_R..K3_R, K0_G.., K0_B.., K0_A.. */
    return 1.f;
}
static int cmp(int func, float a, float b) {
    switch (func) { case 0: return 0; case 1: return a < b; case 2: return a == b; case 3: return a <= b; case 4: return a > b; case 5: return a != b; case 6: return a >= b; default: return 1; }
}
static float bias_of(int b) { return b == 1 ? 0.5f : b == 2 ? -0.5f : 0.f; }
static float scale_of(int s) { return s == 0 ? 1.f : s == 1 ? 2.f : s == 2 ? 4.f : 0.5f; }

/* Runs the TEV pipeline for one pixel. in: interpolated colours and texture coordinates. out: final rgba (0..1). */
static void shade(const GxrFrag *f, const float col[2][4], const float tc[8][3], float *out) {
    float reg[4][4]; for (int i = 0; i < 4; i++) for (int k = 0; k < 4; k++) reg[i][k] = f->reg[i][k] / 255.f;        /* PREV, C0, C1, C2 */
    for (int i = 0; i < f->nstages; i++) {
        const GxrStage *s = &f->st[i];
        float ras[4] = { 0, 0, 0, 0 }, tex[4] = { 0, 0, 0, 0 };
        if (s->chan == 0 || s->chan == 1) for (int k = 0; k < 4; k++) ras[k] = col[s->chan][f->swap[s->rswap][k]];
        if (s->texen && f->tex[s->texmap]) {
            const float *q = tc[s->texcoord]; float uu = q[0] / (q[2] != 0.f ? q[2] : 1.f) * s->tsx, vv = q[1] / (q[2] != 0.f ? q[2] : 1.f) * s->tsy, tt[4];
            sample(f, s->texmap, uu, vv, tt); for (int k = 0; k < 4; k++) tex[k] = tt[f->swap[s->tswap][k]];
        }
        float in[16][3];                                                    /* colour inputs, rgb */
        for (int k = 0; k < 3; k++) {
            in[0][k] = reg[0][k]; in[1][k] = reg[0][3]; in[2][k] = reg[1][k]; in[3][k] = reg[1][3]; in[4][k] = reg[2][k]; in[5][k] = reg[2][3];
            in[6][k] = reg[3][k]; in[7][k] = reg[3][3]; in[8][k] = tex[k]; in[9][k] = tex[3]; in[10][k] = ras[k]; in[11][k] = ras[3];
            in[12][k] = 1.f; in[13][k] = 0.5f; in[14][k] = konst_sel(f, s->kc, k, 0); in[15][k] = 0.f;
        }
        float res[4];
        for (int k = 0; k < 3; k++) {
            float a = in[s->ca][k], b = in[s->cb][k], c = in[s->cc][k], d = in[s->cd][k];
            float v = a * (1 - c) + b * c; v = (s->csub ? d - v : d + v) + bias_of(s->cbias); v *= scale_of(s->cscale);
            res[k] = s->cclamp ? clampf(v, 0.f, 1.f) : clampf(v, -4.f, 4.f);
        }
        float ain[8] = { reg[0][3], reg[1][3], reg[2][3], reg[3][3], tex[3], ras[3], konst_sel(f, s->ka, 3, 1), 0.f };
        { float a = ain[s->aa], b = ain[s->ab], c = ain[s->ac], d = ain[s->ad];
          float v = a * (1 - c) + b * c; v = (s->asub ? d - v : d + v) + bias_of(s->abias); v *= scale_of(s->ascale);
          res[3] = s->aclamp ? clampf(v, 0.f, 1.f) : clampf(v, -4.f, 4.f); }
        float *dst = reg[s->cdest & 3]; dst[0] = res[0]; dst[1] = res[1]; dst[2] = res[2];
        reg[s->adest & 3][3] = res[3];
    }
    for (int k = 0; k < 4; k++) out[k] = clampf(reg[0][k], 0.f, 1.f);
}
static int alpha_pass(const GxrFrag *f, float a) {
    int v = (int)lrintf(a * 255.f);
    int r0 = cmp(f->acomp0, (float)v, (float)f->aref0), r1 = cmp(f->acomp1, (float)v, (float)f->aref1);
    switch (f->alogic) { case 0: return r0 && r1; case 1: return r0 || r1; case 2: return r0 != r1; default: return r0 == r1; }
}
static float bfactor(int fct, int is_src, const float *sc, const float sa, const float *dc, const float da, int comp) {
    switch (fct) {
    case 0: return 0.f; case 1: return 1.f;
    case 2: return is_src ? dc[comp] : sc[comp]; case 3: return 1.f - (is_src ? dc[comp] : sc[comp]);
    case 4: return sa; case 5: return 1.f - sa; case 6: return da; default: return 1.f - da;
    }
}
static void put_pixel(const GxrFrag *f, int x, int y, float z, const float *c) {
    size_t i = (size_t)y * GXR_EFB_W + x;
    if (f->ztest && !cmp(f->zfunc, z, zbuf[i])) return;
    if (!alpha_pass(f, c[3])) return;
    uint8_t *d = &efb[i * 4]; float dc[4] = { d[0] / 255.f, d[1] / 255.f, d[2] / 255.f, d[3] / 255.f }, da = d[3] / 255.f, o[4] = { c[0], c[1], c[2], c[3] };
    if (f->blend && !f->logic) {
        for (int k = 0; k < 3; k++) {
            float sf = bfactor(f->sfactor, 1, c, c[3], dc, da, k), df = bfactor(f->dfactor, 0, c, c[3], dc, da, k);
            o[k] = f->bsub ? dc[k] * df - c[k] * sf : c[k] * sf + dc[k] * df;
        }
        float sfa = bfactor(f->sfactor, 1, c, c[3], dc, da, 3), dfa = bfactor(f->dfactor, 0, c, c[3], dc, da, 3);
        o[3] = f->bsub ? da * dfa - c[3] * sfa : c[3] * sfa + da * dfa;
    }
    if (f->color_update) for (int k = 0; k < 3; k++) d[k] = (uint8_t)lrintf(clampf(o[k], 0.f, 1.f) * 255.f);
    if (f->alpha_update) d[3] = (uint8_t)lrintf(clampf(o[3], 0.f, 1.f) * 255.f);
    if (f->zupdate && f->ztest) zbuf[i] = z;                              /* with the depth test off the depth buffer is not written either */
}

static inline int top_left(double dx, double dy) { return dy > 0 || (dy == 0 && dx < 0); }   /* edge vector with the interior on its left */
static void raster(const GxrFrag *f, const SV *a, const SV *b, const SV *c) {
    double area = (double)(b->x - a->x) * (c->y - a->y) - (double)(c->x - a->x) * (b->y - a->y);
    if (area == 0.0) return;
    if (f->cull == 3) return;
    if (f->cull == 1 && area < 0) return;                                   /* sign convention is a guess: RT_GX_FLIPCULL swaps it */
    if (f->cull == 2 && area > 0) return;
    float minx = fminf(a->x, fminf(b->x, c->x)), maxx = fmaxf(a->x, fmaxf(b->x, c->x)), miny = fminf(a->y, fminf(b->y, c->y)), maxy = fmaxf(a->y, fmaxf(b->y, c->y));
    int x0 = (int)fmaxf(floorf(minx), (float)f->scissor[0]), x1 = (int)fminf(ceilf(maxx), (float)f->scissor[2]);
    int y0 = (int)fmaxf(floorf(miny), (float)f->scissor[1]), y1 = (int)fminf(ceilf(maxy), (float)f->scissor[3]);
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > GXR_EFB_W) x1 = GXR_EFB_W;
    if (y1 > GXR_EFB_H) y1 = GXR_EFB_H;
    double inv = 1.0 / area, s = area > 0 ? 1.0 : -1.0;
    for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) {
        double px = x + 0.5, py = y + 0.5;
        double w0 = ((double)(b->x - px) * (c->y - py) - (double)(c->x - px) * (b->y - py)) * inv;
        double w1 = ((double)(c->x - px) * (a->y - py) - (double)(a->x - px) * (c->y - py)) * inv;
        double w2 = ((double)(a->x - px) * (b->y - py) - (double)(b->x - px) * (a->y - py)) * inv;
        /* a pixel centre exactly on an edge belongs to one of the two triangles sharing it (top-left rule), not to both: with blending it would be drawn twice */
        if (w0 < 0 || w1 < 0 || w2 < 0) continue;
        if (w0 == 0 && !top_left(s * ((double)c->x - b->x), s * ((double)c->y - b->y))) continue;
        if (w1 == 0 && !top_left(s * ((double)a->x - c->x), s * ((double)a->y - c->y))) continue;
        if (w2 == 0 && !top_left(s * ((double)b->x - a->x), s * ((double)b->y - a->y))) continue;
        st_pix_tested++;
        float z = (float)(w0 * a->z + w1 * b->z + w2 * c->z);
        if (z < 0.f || z > 1.00001f) continue;
        if (z > 0.99999994f) z = 0.99999994f;                               /* the depth buffer is 24 bit: far plane = 0xFFFFFF */
        double iw = w0 * a->iw + w1 * b->iw + w2 * c->iw; if (iw == 0) continue; double rw = 1.0 / iw;
        float col[2][4], tc[8][3];
        for (int ch = 0; ch < 2; ch++) for (int k = 0; k < 4; k++) col[ch][k] = (float)((w0 * a->c[ch][k] + w1 * b->c[ch][k] + w2 * c->c[ch][k]) * rw);
        for (int i = 0; i < 8; i++) for (int k = 0; k < 3; k++) tc[i][k] = (float)((w0 * a->t[i][k] + w1 * b->t[i][k] + w2 * c->t[i][k]) * rw);
        st_pix_shaded++; float out[4]; shade(f, col, tc, out);
        put_pixel(f, x, y, z, out);
    }
}

/* clip a triangle against the GX near/far planes (-w <= z <= 0), project, and rasterize */
static void lerp_vert(GxrVert *o, const GxrVert *a, const GxrVert *b, float t) {
    float *po = (float *)o; const float *pa = (const float *)a, *pb = (const float *)b;
    for (size_t i = 0; i < sizeof(GxrVert) / sizeof(float); i++) po[i] = pa[i] + (pb[i] - pa[i]) * t;
}
static void project(const GxrFrag *f, const GxrVert *v, SV *s) {
    float iw = 1.f / v->w, nx = v->x * iw, ny = v->y * iw, nz = v->z * iw;
    s->x = nx * f->vp[0] + f->vp[3]; s->y = ny * f->vp[1] + f->vp[4]; s->z = (nz * f->vp[2] + f->vp[5]) / 16777216.f; s->iw = iw;
    for (int ch = 0; ch < 2; ch++) for (int k = 0; k < 4; k++) s->c[ch][k] = v->c[ch][k] * iw;
    for (int i = 0; i < 8; i++) for (int k = 0; k < 3; k++) s->t[i][k] = v->t[i][k] * iw;
}
static void tri(const GxrFrag *f, const GxrVert *a, const GxrVert *b, const GxrVert *c) {
    GxrVert in[3] = { *a, *b, *c }, poly[8], tmp[8]; int n = 3;
    memcpy(poly, in, sizeof in);
    for (int plane = 0; plane < 2; plane++) {                                      /* 0: near z + w >= 0, 1: far -z >= 0 */
        int m = 0;
        for (int i = 0; i < n; i++) {
            const GxrVert *p = &poly[i], *q = &poly[(i + 1) % n];
            float dp = plane == 0 ? p->z + p->w : -p->z, dq = plane == 0 ? q->z + q->w : -q->z;
            if (dp >= 0) tmp[m++] = *p;
            if ((dp >= 0) != (dq >= 0)) { float t = dp / (dp - dq); lerp_vert(&tmp[m++], p, q, t); }
            if (m > 6) break;
        }
        n = m; memcpy(poly, tmp, sizeof(GxrVert) * (size_t)n);
        if (n < 3) return;
    }
    SV sv[8]; for (int i = 0; i < n; i++) { if (poly[i].w <= 1e-9f) return; project(f, &poly[i], &sv[i]); }
    for (int i = 1; i + 1 < n; i++) raster(f, &sv[0], &sv[i], &sv[i + 1]);
}

static void be_draw(const GxrFrag *f, const GxrVert *v, int nv) {
    if (!gxr_frame_wanted(gxr_frames())) { st_draws_skipped++; return; }
    st_draws_done++;
    for (int i = 0; i + 2 < nv; i += 3) tri(f, &v[i], &v[i + 1], &v[i + 2]);
}
void gxr_soft_stats(void) { fprintf(stderr, "GXR soft: %llu draws rasterized, %llu skipped (frame not dumped), %llu pixels covered, %llu shaded\n", st_draws_done, st_draws_skipped, st_pix_tested, st_pix_shaded); }
static void be_clear(int x, int y, int w, int h, int color, int alpha, int z, const uint8_t rgba[4], float zval) {
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > GXR_EFB_W) w = GXR_EFB_W - x;
    if (y + h > GXR_EFB_H) h = GXR_EFB_H - y;
    for (int j = y; j < y + h; j++) for (int i = x; i < x + w; i++) {
        size_t k = (size_t)j * GXR_EFB_W + i;
        if (color) { efb[k * 4] = rgba[0]; efb[k * 4 + 1] = rgba[1]; efb[k * 4 + 2] = rgba[2]; }
        if (alpha) efb[k * 4 + 3] = rgba[3];
        if (z) zbuf[k] = zval;
    }
}
static void be_read(int x, int y, int w, int h, uint8_t *out) { for (int j = 0; j < h; j++) memcpy(out + (size_t)j * w * 4, &efb[((size_t)(y + j) * GXR_EFB_W + x) * 4], (size_t)w * 4); }
static void be_present(int x, int y, int w, int h, int outw, int outh) {
    uint8_t *o = malloc((size_t)outw * outh * 4);
    for (int j = 0; j < outh; j++) { int sy = y + (int)((long)j * h / outh); for (int i = 0; i < outw; i++) memcpy(o + ((size_t)j * outw + i) * 4, &efb[((size_t)sy * GXR_EFB_W + x + (int)((long)i * w / outw)) * 4], 4); }
    for (size_t i = 0; i < (size_t)outw * outh; i++) o[i * 4 + 3] = 255;     /* the XFB has no alpha */
    gxr_frame_sink(o, outw, outh); free(o);
}
static void be_flush(void) {}
const GxrBackend gxr_soft_backend = { "software", be_draw, be_clear, be_read, be_present, be_flush, gxr_soft_stats };
