/* Runtime for lifted Gekko code (milestone 1: integer + branch).
 * Assumes a little-endian host (Android ARM64 / x86-64); guest memory is big-endian. */
#ifndef RT_H
#define RT_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <math.h>
#include <fenv.h>
#include <setjmp.h>

typedef struct Ctx {
    uint32_t r[32];
    uint8_t  cr[8];                 /* 4-bit fields: LT=8 GT=4 EQ=2 SO=1; cr[0] is CR0 */
    uint32_t lr, ctr;
    uint32_t xer_so, xer_ov, xer_ca;
    uint32_t spr[1024];             /* everything else (GQRs, HID, ...) */
    uint64_t tb;
    double   ps[32][2];             /* FPRs; [0]=ps0 (the double), [1]=ps1 (paired single) */
    uint32_t fpscr;
    uint8_t *mem1;                  /* 24 MB: 0x80000000 / 0xC0000000 */
    uint8_t *mem2;                  /* 64 MB: 0x90000000 / 0xD0000000 */
    uint32_t msr;                   /* machine state; EE bit (0x8000) is what OSDisableInterrupts toggles */
    uint32_t sr[16];                /* segment registers */
    /* threads and interrupts (milestone 3b) */
    struct RtFiber *fiber;          /* host thread this register file belongs to */
    jmp_buf irq_jb[4];              /* where an interrupt handler's final rfi returns to */
    int irq_depth;
    uint8_t *lc;                    /* 16 KB locked cache at 0xE0000000 */
} Ctx;

typedef void (*rt_func)(Ctx *);
typedef struct { uint32_t addr; rt_func fn; } rt_func_entry;
extern const rt_func_entry rt_func_table[];   /* generated: sorted by addr */
extern const uint32_t rt_func_count;

void rt_unimpl(Ctx *c, uint32_t insn, uint32_t pc) __attribute__((noreturn));
void rt_bad_access(uint32_t addr) __attribute__((noreturn));
void rt_fell_off(Ctx *c, uint32_t pc) __attribute__((noreturn));
void rt_call_indirect(Ctx *c, uint32_t addr);
void rt_jump_indirect(Ctx *c, uint32_t addr);
#define RT_UNIMPL(c, insn, pc) rt_unimpl((c), (insn), (pc))

/* Interrupts are delivered at poll points: function entry and loop back-edges. */
extern volatile int rt_irq_pending;
void rt_poll_slow(Ctx *c);
#define RT_POLL(c) do { if (__builtin_expect(rt_irq_pending, 0) && ((c)->msr & 0x8000u)) rt_poll_slow(c); } while (0)
#define RT_IRQ_PC 0xFFFFF000u            /* SRR0 sentinel: "return to the interrupted C code" */

/* function-entry trace ring (bring-up aid): set rt_trace_on=1, dump with rt_trace_dump() */
extern int rt_trace_on;
void rt_trace_hit(uint32_t addr);
void rt_trace_dump(int last_n);
extern uint32_t rt_break_addr, rt_log_addr, rt_chk_addr;
void rt_chk_hook(uint32_t fn);
#define RT_TRACE(c, a) do { if (rt_trace_on) rt_trace_hit(a); RT_POLL(c); } while (0)

extern uint32_t rt_watch_addr, rt_watch_mask;      /* mask: which address bits must match (default ~7) */
void rt_watch_hit(struct Ctx *c, uint32_t addr, uint64_t val, int size);
/* ---- memory ---- */
static inline uint8_t *rt_ptr(Ctx *c, uint32_t addr) {
    if ((addr >> 14) == 0x38000u) return c->lc + (addr & 0x3FFFu);          /* locked cache */
    uint32_t a = addr & 0x1FFFFFFFu;
    if (a < 0x01800000u) return c->mem1 + a;
    if (a >= 0x10000000u && a < 0x14000000u) return c->mem2 + (a - 0x10000000u);
    rt_bad_access(addr);            /* MMIO (0xCC...) lands here: milestone 3/4 */
}
/* Hardware registers (0xCC000000 / 0xCD000000 windows) are routed to rt_mmio.c. */
static inline int rt_is_mmio(uint32_t a) { uint32_t m = a & 0x1FFFFFFFu; return m >= 0x0C000000u && m < 0x0E000000u; }
uint64_t rt_mmio_read(Ctx *c, uint32_t addr, int size);
void rt_mmio_write(Ctx *c, uint32_t addr, uint64_t v, int size);
static inline uint32_t rt_r8(Ctx *c, uint32_t a)  { if (rt_is_mmio(a)) return (uint32_t)rt_mmio_read(c, a, 1); return *rt_ptr(c, a); }
static inline uint32_t rt_r16(Ctx *c, uint32_t a) { if (rt_is_mmio(a)) return (uint32_t)rt_mmio_read(c, a, 2); uint16_t v; memcpy(&v, rt_ptr(c, a), 2); return __builtin_bswap16(v); }
static inline uint32_t rt_r16s(Ctx *c, uint32_t a){ return (uint32_t)(int32_t)(int16_t)rt_r16(c, a); }
static inline uint32_t rt_r32(Ctx *c, uint32_t a) { if (rt_is_mmio(a)) return (uint32_t)rt_mmio_read(c, a, 4); uint32_t v; memcpy(&v, rt_ptr(c, a), 4); return __builtin_bswap32(v); }
static inline uint64_t rt_r64(Ctx *c, uint32_t a) { if (rt_is_mmio(a)) return rt_mmio_read(c, a, 8); uint64_t v; memcpy(&v, rt_ptr(c, a), 8); return __builtin_bswap64(v); }
static inline void rt_w64(Ctx *c, uint32_t a, uint64_t v) { if (__builtin_expect(rt_watch_addr != 0, 0) && ((a ^ rt_watch_addr) & rt_watch_mask & 0x1FFFFFFFu) == 0) rt_watch_hit(c, a, v, 8); if (rt_is_mmio(a)) { rt_mmio_write(c, a, v, 8); return; } uint64_t t = __builtin_bswap64(v); memcpy(rt_ptr(c, a), &t, 8); }
static inline void rt_w8(Ctx *c, uint32_t a, uint32_t v)  { if (__builtin_expect(rt_watch_addr != 0, 0) && ((a ^ rt_watch_addr) & rt_watch_mask & 0x1FFFFFFFu) == 0) rt_watch_hit(c, a, v, 1); if (rt_is_mmio(a)) { rt_mmio_write(c, a, v, 1); return; } *rt_ptr(c, a) = (uint8_t)v; }
static inline void rt_w16(Ctx *c, uint32_t a, uint32_t v) { if (__builtin_expect(rt_watch_addr != 0, 0) && ((a ^ rt_watch_addr) & rt_watch_mask & 0x1FFFFFFFu) == 0) rt_watch_hit(c, a, v, 2); if (rt_is_mmio(a)) { rt_mmio_write(c, a, v, 2); return; } uint16_t t = __builtin_bswap16((uint16_t)v); memcpy(rt_ptr(c, a), &t, 2); }
static inline void rt_w32(Ctx *c, uint32_t a, uint32_t v) { if (__builtin_expect(rt_watch_addr != 0, 0) && ((a ^ rt_watch_addr) & rt_watch_mask & 0x1FFFFFFFu) == 0) rt_watch_hit(c, a, v, 4); if (rt_is_mmio(a)) { rt_mmio_write(c, a, v, 4); return; } uint32_t t = __builtin_bswap32(v); memcpy(rt_ptr(c, a), &t, 4); }
static inline void rt_dcbz(Ctx *c, uint32_t a)    { if (__builtin_expect(rt_watch_addr != 0, 0) && (((a & ~31u) ^ (rt_watch_addr & ~31u)) & rt_watch_mask & 0x1FFFFFFFu) == 0) rt_watch_hit(c, a & ~31u, 0, 32); memset(rt_ptr(c, a & ~31u), 0, 32); }

/* ---- condition register ---- */
static inline void rt_cr0(Ctx *c, uint32_t v) {
    int32_t s = (int32_t)v; c->cr[0] = (uint8_t)((s < 0 ? 8 : s > 0 ? 4 : 2) | c->xer_so);
}
static inline void rt_cmp_s(Ctx *c, int f, int32_t a, int32_t b) {
    c->cr[f] = (uint8_t)((a < b ? 8 : a > b ? 4 : 2) | c->xer_so);
}
static inline void rt_cmp_u(Ctx *c, int f, uint32_t a, uint32_t b) {
    c->cr[f] = (uint8_t)((a < b ? 8 : a > b ? 4 : 2) | c->xer_so);
}
static inline uint32_t rt_crget(Ctx *c, int bi) { return (c->cr[bi >> 2] >> (3 - (bi & 3))) & 1u; }
static inline void rt_crset(Ctx *c, int bi, uint32_t v) {
    int sh = 3 - (bi & 3); c->cr[bi >> 2] = (uint8_t)((c->cr[bi >> 2] & ~(1u << sh)) | ((v & 1u) << sh));
}
static inline uint32_t rt_mfcr(Ctx *c) {
    uint32_t v = 0; for (int i = 0; i < 8; i++) v |= (uint32_t)(c->cr[i] & 15) << (28 - 4 * i); return v;
}
static inline void rt_mtcrf(Ctx *c, uint32_t crm, uint32_t v) {
    for (int i = 0; i < 8; i++) if (crm & (0x80u >> i)) c->cr[i] = (v >> (28 - 4 * i)) & 15;
}

/* ---- special registers ---- */
static inline uint32_t rt_get_xer(Ctx *c) {
    return (c->xer_so << 31) | (c->xer_ov << 30) | (c->xer_ca << 29) | (c->spr[1] & 0x7F);
}
static inline void rt_set_xer(Ctx *c, uint32_t v) {
    c->xer_so = v >> 31; c->xer_ov = (v >> 30) & 1; c->xer_ca = (v >> 29) & 1; c->spr[1] = v & 0x7F;
}
uint32_t rt_mftb(Ctx *c, int upper);           /* real-time clock at 60.75 MHz */
void rt_set_dec(Ctx *c, uint32_t v);
uint32_t rt_get_dec(Ctx *c);

/* ---- ALU helpers ---- */
static inline uint32_t rt_rotl(uint32_t v, unsigned n) { n &= 31; return n ? (v << n) | (v >> (32 - n)) : v; }
/* Division by zero / overflow results are architecturally undefined; this follows
 * the convention Dolphin uses. Verify against Dolphin before trusting it. */
static inline uint32_t rt_divw(uint32_t a, uint32_t b) {
    int32_t x = (int32_t)a, y = (int32_t)b;
    if (y == 0 || (x == INT32_MIN && y == -1)) return x < 0 ? 0xFFFFFFFFu : 0u;
    return (uint32_t)(x / y);
}
static inline uint32_t rt_divwu(uint32_t a, uint32_t b) { return b ? a / b : 0u; }
/* ---- floating point & paired singles (milestone 2) ----
 * Build with -ffp-contract=off -frounding-math and link -lm.
 * Single-precision ops compute in float (fmadds uses fmaf: Dolphin issue #13865
 * found a 32-bit FMA matches hardware, 64-bit FMA + rounding does not). */
static inline uint64_t rt_d2u(double d) { uint64_t u; memcpy(&u, &d, 8); return u; }
static inline double   rt_u2d(uint64_t u) { double d; memcpy(&d, &u, 8); return d; }
static inline uint32_t rt_f2u(float f) { uint32_t u; memcpy(&u, &f, 4); return u; }
static inline float    rt_u2f(uint32_t u) { float f; memcpy(&f, &u, 4); return f; }

static inline void rt_lfs(Ctx *c, int fd, uint32_t ea) {   /* fills ps0 and ps1 */
    double v = (double)rt_u2f(rt_r32(c, ea)); c->ps[fd][0] = v; c->ps[fd][1] = v;
}
static inline void rt_lfd(Ctx *c, int fd, uint32_t ea) { c->ps[fd][0] = rt_u2d(rt_r64(c, ea)); }
static inline void rt_stfs(Ctx *c, int fs, uint32_t ea) { rt_w32(c, ea, rt_f2u((float)c->ps[fs][0])); }
static inline void rt_stfd(Ctx *c, int fs, uint32_t ea) { rt_w64(c, ea, rt_d2u(c->ps[fs][0])); }
static inline void rt_stfiwx(Ctx *c, int fs, uint32_t ea) { rt_w32(c, ea, (uint32_t)rt_d2u(c->ps[fs][0])); }

/* hardware rounds the multiplier operand frC to 25 significant bits */
static inline double rt_force25(double d) {
    uint64_t u = rt_d2u(d); return rt_u2d((u & 0xFFFFFFFFF8000000ull) + (u & 0x8000000ull));
}
static inline double rt_single(double d) { return (double)(float)d; }
/* The single-precision instructions take the full double held in the register and round only the result. That matters: the integer to float idiom
 * (fsubs of a 0x43300000_xxxxxxxx double and the 2^52 constant) subtracts two doubles that are NOT single precision values, so converting the
 * operands to float first gives 0. (Found when the game's GXInit viewport came out 0 x 0.) For operands that are single values the result is the
 * same as computing in float (double rounding of + - * / is innocuous for a 24 bit result). */
static inline int rt_is_single(double d) { return (double)(float)d == d; }
static inline double rt_add_s(double a, double b) { return (double)(float)(a + b); }
static inline double rt_sub_s(double a, double b) { return (double)(float)(a - b); }
static inline double rt_div_s(double a, double b) { return (double)(float)(a / b); }
static inline double rt_mul_s(double a, double c) { return (double)(float)(a * rt_force25(c)); }
static inline double rt_madd_s(double a, double c, double b) {
    c = rt_force25(c);
    if (rt_is_single(a) && rt_is_single(c) && rt_is_single(b)) return (double)fmaf((float)a, (float)c, (float)b);
    return (double)(float)fma(a, c, b);
}
static inline double rt_msub_s(double a, double c, double b) {
    c = rt_force25(c);
    if (rt_is_single(a) && rt_is_single(c) && rt_is_single(b)) return (double)fmaf((float)a, (float)c, -(float)b);
    return (double)(float)fma(a, c, -b);
}
static inline double rt_nmadd_s(double a, double c, double b) { return -rt_madd_s(a, c, b); }
static inline double rt_nmsub_s(double a, double c, double b) { return -rt_msub_s(a, c, b); }
static inline double rt_fma(double a, double c, double b) { return fma(a, c, b); }
/* Estimate instructions: hardware uses lookup tables; these are exact values, so
 * results differ in the low bits from a real console. TODO: port the real tables. */
static inline double rt_res_s(double b)    { return (double)(1.0f / (float)b); }
static inline double rt_rsqrte_s(double b) { return (double)(1.0f / sqrtf((float)b)); }
static inline double rt_rsqrte_d(double b) { return 1.0 / sqrt(b); }

static inline void rt_fcmp(Ctx *c, int f, double a, double b) {
    uint32_t cc = (a < b) ? 8 : (a > b) ? 4 : (a == b) ? 2 : 1;
    c->cr[f] = (uint8_t)cc;
    c->fpscr = (c->fpscr & ~0xF000u) | (cc << 12);       /* FPCC */
}
static inline double rt_fctiw(double x, int truncate) {
    int32_t i;
    if (x != x) i = INT32_MIN;
    else {
        double r = truncate ? trunc(x) : rint(x);        /* rint follows the current rounding mode */
        i = r >= 2147483648.0 ? INT32_MAX : r < -2147483648.0 ? INT32_MIN : (int32_t)r;
    }
    return rt_u2d(0xFFF8000000000000ull | (uint32_t)i);
}
static inline void rt_apply_rn(Ctx *c) {
    static const int m[4] = { FE_TONEAREST, FE_TOWARDZERO, FE_UPWARD, FE_DOWNWARD };
    fesetround(m[c->fpscr & 3]);
}
static inline void rt_mtfsf(Ctx *c, uint32_t fm, uint32_t v) {
    uint32_t mask = 0;
    for (int i = 0; i < 8; i++) if (fm & (0x80u >> i)) mask |= 0xFu << (28 - 4 * i);
    c->fpscr = (c->fpscr & ~mask) | (v & mask); rt_apply_rn(c);
}
static inline void rt_mtfsb(Ctx *c, int bit, int v) {
    uint32_t m = 1u << (31 - bit); c->fpscr = v ? (c->fpscr | m) : (c->fpscr & ~m); rt_apply_rn(c);
}
static inline void rt_mtfsfi(Ctx *c, int crf, uint32_t imm) {
    uint32_t sh = 28 - 4 * crf; c->fpscr = (c->fpscr & ~(0xFu << sh)) | ((imm & 0xF) << sh); rt_apply_rn(c);
}
static inline void rt_fpscr_to_cr1(Ctx *c) { c->cr[1] = (uint8_t)(c->fpscr >> 28); }  /* Rc=1 forms */

/* ---- quantized paired-single load/store (GQR0-7 = spr 912-919) ---- */
static inline int rt_sext6(uint32_t v) { return (int)(v & 63) - ((v & 32) ? 64 : 0); }
static inline double rt_psq_ld1(Ctx *c, uint32_t ea, unsigned type, int scale, unsigned *sz) {
    switch (type) {
    case 4: *sz = 1; return ldexp((double)(uint8_t)rt_r8(c, ea), -scale);
    case 5: *sz = 2; return ldexp((double)(uint16_t)rt_r16(c, ea), -scale);
    case 6: *sz = 1; return ldexp((double)(int8_t)rt_r8(c, ea), -scale);
    case 7: *sz = 2; return ldexp((double)(int16_t)rt_r16(c, ea), -scale);
    default: *sz = 4; return (double)rt_u2f(rt_r32(c, ea));   /* float: scale ignored */
    }
}
static inline void rt_psq_l(Ctx *c, int fd, uint32_t ea, int w, int gq) {
    uint32_t g = c->spr[912 + gq];
    unsigned type = (g >> 16) & 7, sz = 4; int scale = rt_sext6(g >> 24);
    double v0 = rt_psq_ld1(c, ea, type, scale, &sz);
    double v1 = w ? 1.0 : rt_psq_ld1(c, ea + sz, type, scale, &sz);
    c->ps[fd][0] = v0; c->ps[fd][1] = v1;
}
/* NaN -> 0 is an unverified choice; saturate then truncate toward zero */
static inline int32_t rt_q(double x, double lo, double hi) {
    if (x != x) return 0;
    if (x < lo) return (int32_t)lo;
    if (x > hi) return (int32_t)hi;
    return (int32_t)x;
}
static inline void rt_psq_st1(Ctx *c, uint32_t ea, double v, unsigned type, int scale, unsigned *sz) {
    double s = ldexp(v, scale);
    switch (type) {
    case 4: *sz = 1; rt_w8(c, ea, (uint32_t)rt_q(s, 0, 255)); break;
    case 5: *sz = 2; rt_w16(c, ea, (uint32_t)rt_q(s, 0, 65535)); break;
    case 6: *sz = 1; rt_w8(c, ea, (uint32_t)rt_q(s, -128, 127)); break;
    case 7: *sz = 2; rt_w16(c, ea, (uint32_t)rt_q(s, -32768, 32767)); break;
    default: *sz = 4; rt_w32(c, ea, rt_f2u((float)v)); break;
    }
}
static inline void rt_psq_st(Ctx *c, int fs, uint32_t ea, int w, int gq) {
    uint32_t g = c->spr[912 + gq];
    unsigned type = g & 7, sz = 4; int scale = rt_sext6(g >> 8);
    double v0 = c->ps[fs][0], v1 = c->ps[fs][1];
    rt_psq_st1(c, ea, v0, type, scale, &sz);
    if (!w) rt_psq_st1(c, ea + sz, v1, type, scale, &sz);
}

/* ---- interrupts, threads, IOS (rt_irq.c, rt_thread.c, rt_ios.c) ---- */
void rt_irq_init(Ctx *c);                      /* starts the timer thread */
void rt_irq_recompute(void);
int  rt_hw_ext_pending(void);                  /* PI interrupt cause & mask */
void rt_hw_vi_retrace(void);
void rt_deliver_exception(Ctx *c, int exception);
void rt_exc_return(Ctx *c, uint32_t os_context);   /* does not return */
void rt_thread_init_signals(void);
void rt_fiber_main_init(Ctx *c);
void rt_fiber_note_context(Ctx *c, uint32_t os_context);
void rt_os_save_context(Ctx *c);               /* behaves like the SDK's OSSaveContext (r3 = context) */
void rt_os_load_context(Ctx *c);               /* ... OSLoadContext, including thread switches */
int  rt_ios_request(Ctx *c, uint32_t request_phys);   /* 0 = reply now, 1 = pending (rt_ipc_post_reply later) */
void rt_ipc_post_reply(Ctx *c, uint32_t request_phys);
void rt_guest_format(Ctx *c, uint32_t fmt, int first_gpr, char *out, size_t cap);
void rt_hle_os_report(Ctx *c);                 /* printf-style: format in r3, args from r4 */
extern int rt_sc_widescreen;                   /* console aspect-ratio setting the SDK's SC library would read from SYSCONF: 1 = 16:9 (default), 0 = 4:3 */
void rt_hle_sc_get_aspect_ratio(Ctx *c);       /* behaves like SCGetAspectRatio(): r3 = 1 for 16:9, 0 for 4:3 */

/* ---- trap instructions (tw/twi): TO bits 0x10 <, 0x08 >, 0x04 ==, 0x02 <u, 0x01 >u ---- */
static inline int rt_trap_cond(unsigned to, uint32_t a, uint32_t b) {
    return ((to & 0x10) && (int32_t)a < (int32_t)b) || ((to & 0x08) && (int32_t)a > (int32_t)b) ||
           ((to & 0x04) && a == b) || ((to & 0x02) && a < b) || ((to & 0x01) && a > b);
}
void rt_trap(Ctx *c, uint32_t pc) __attribute__((noreturn));
#endif
