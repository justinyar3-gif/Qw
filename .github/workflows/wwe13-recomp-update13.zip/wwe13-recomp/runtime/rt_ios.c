/* IOS (the Wii's I/O processor) request handling. The SDK talks to IOS through IPC requests in
 * memory; this answers them. Every request is logged so the needed devices can be learned from a
 * real run. Unknown devices succeed with zeroed output (bring-up behavior). */
#include "rt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BT_PATH "/dev/usb/oh1/57e/305"
/* Virtual disc (rt_di.c). Without it linked in, /dev/di keeps the bring-up behavior: success with zeroed output. */
int rt_di_ioctl(Ctx *c, uint32_t req);
__attribute__((weak)) int rt_di_ioctl(Ctx *c, uint32_t req) { (void)c; (void)req; return 0; }
static int nlog;
static char fd_path[64][48];
#define LOG(...) do { if (nlog < 400) { nlog++; fprintf(stderr, __VA_ARGS__); } } while (0)
static uint32_t ea(uint32_t phys) { return 0x80000000u | phys; }
static void zero(Ctx *c, uint32_t phys, uint32_t len) {
    if (phys < 0x3200u && len) fprintf(stderr, "[ios] WARNING: zero-filling low memory phys %08X len %u\n", phys, len);
    if (phys && len) memset(rt_ptr(c, ea(phys)), 0, len);
}


/* ---- Bluetooth controller (the Wii's USB dongle, 057e:0305): just enough HCI for the SDK to initialize.
 * Commands arrive as control messages (ioctlv 0), events are read with interrupt messages (ioctlv 2); a read
 * stays pending until an event exists. Wii Remotes are not emulated: the inquiry finds nothing. ---- */
static uint32_t bt_pending;                                /* request waiting for an HCI event (0 = none) */
static uint8_t evq[32][270]; static int evn[32]; static unsigned eq_head, eq_tail;
static void finish(Ctx *c, uint32_t req, uint32_t cmd, int32_t result) {
    uint32_t a = ea(req);
    rt_w32(c, a + 8, cmd); rt_w32(c, a, 8); rt_w32(c, a + 4, (uint32_t)result);
}
static void bt_try_reply(Ctx *c) {
    if (!bt_pending || eq_head == eq_tail) return;
    uint32_t a = ea(bt_pending), nin = rt_r32(c, a + 0x10), vec = ea(rt_r32(c, a + 0x18));
    uint32_t out = ea(rt_r32(c, vec + 8 * nin)), cap = rt_r32(c, vec + 8 * nin + 4);
    unsigned i = eq_head++ % 32; int n = evn[i] < (int)cap ? evn[i] : (int)cap;
    for (int k = 0; k < n; k++) rt_w8(c, out + (uint32_t)k, evq[i][k]);
    uint32_t req = bt_pending; bt_pending = 0;
    finish(c, req, 7, n);
    rt_ipc_post_reply(c, req);
}
static void bt_event(Ctx *c, const uint8_t *e, int n) { unsigned i = eq_tail++ % 32; memcpy(evq[i], e, (size_t)n); evn[i] = n; bt_try_reply(c); }
static void hci_complete(Ctx *c, uint16_t op, const uint8_t *ret, int n) {
    uint8_t e[270] = { 0x0E, (uint8_t)(3 + n), 1, (uint8_t)op, (uint8_t)(op >> 8) };
    memcpy(e + 5, ret, (size_t)n); bt_event(c, e, 5 + n);
}
static void bt_hci_command(Ctx *c, uint16_t op, const uint8_t *p, int plen) {
    static uint16_t seen[64]; static int nseen; int known = 0;
    for (int i = 0; i < nseen; i++) known |= seen[i] == op;
    if (!known && nseen < 64) { seen[nseen++] = op; LOG("[bt] HCI command 0x%04X (%d param bytes)\n", op, plen); }
    (void)p;
    uint8_t r[64] = {0};
    switch (op) {
    case 0x0401: {                                         /* Inquiry: command status, then complete with no devices */
        uint8_t st[6] = { 0x0F, 4, 0, 1, (uint8_t)op, (uint8_t)(op >> 8) }; bt_event(c, st, 6);
        uint8_t done[3] = { 0x01, 1, 0 }; bt_event(c, done, 3); return;
    }
    case 0x1001: r[1] = 3; r[4] = 3; r[5] = 0x0F; hci_complete(c, op, r, 9); return;                    /* local version */
    case 0x1003: { static const uint8_t f[8] = {0xFF,0xFF,0x8D,0xFE,0x9B,0xF9,0x00,0x80}; memcpy(r + 1, f, 8); hci_complete(c, op, r, 9); return; }
    case 0x1005: r[1] = 0x53; r[2] = 0x01; r[3] = 64; r[4] = 10; hci_complete(c, op, r, 8); return;    /* buffer size */
    case 0x1009: { static const uint8_t a[6] = {0x11,0x02,0x19,0x79,0x00,0xFF}; memcpy(r + 1, a, 6); hci_complete(c, op, r, 7); return; }
    case 0x0C23: hci_complete(c, op, r, 4); return;                                                     /* class of device */
    case 0x0C14: hci_complete(c, op, r, 249); return;                                                   /* local name */
    default: hci_complete(c, op, r, 1); return;                                                         /* success */
    }
}
static int bt_ioctlv(Ctx *c, uint32_t req) {
    uint32_t a = ea(req), vec = ea(rt_r32(c, a + 0x18)), ioc = rt_r32(c, a + 0xC);
    if (getenv("RT_BT_DEBUG") && ioc == 0) {
        uint32_t nin = rt_r32(c, a + 0x10), nout = rt_r32(c, a + 0x14);
        fprintf(stderr, "[bt] ctrl ioctlv in=%u out=%u\n", nin, nout);
        for (uint32_t i = 0; i < nin + nout && i < 8; i++) {
            uint32_t va = rt_r32(c, vec + 8 * i), vl = rt_r32(c, vec + 8 * i + 4);
            fprintf(stderr, "[bt]   vec[%u] addr %08X len %u:", i, va, vl);
            for (uint32_t k = 0; k < vl && k < 12; k++) fprintf(stderr, " %02X", rt_r8(c, ea(va) + k));
            fputc('\n', stderr);
        }
    }
    if (ioc == 0) {                                        /* control message: setup fields in the inputs, HCI command in the first output vector */
        uint32_t len = rt_r16(c, ea(rt_r32(c, vec + 8 * 4)));
        uint32_t pl = ea(rt_r32(c, vec + 8 * rt_r32(c, a + 0x10)));    /* the command bytes ride in the first output vector */
        uint16_t op = (uint16_t)(rt_r8(c, pl) | rt_r8(c, pl + 1) << 8);
        uint8_t params[256]; int n = (int)rt_r8(c, pl + 2);
        for (int i = 0; i < n; i++) params[i] = (uint8_t)rt_r8(c, pl + 3 + (uint32_t)i);
        bt_hci_command(c, op, params, n);
        finish(c, req, 7, (int32_t)len); return 0;
    }
    if (ioc == 2) { bt_pending = req; bt_try_reply(c); return 1; }   /* event read: pending until an event exists */
    return 1;                                              /* bulk (ACL data) read: nothing to deliver */
}

int rt_ios_request(Ctx *c, uint32_t req) {
    uint32_t a = ea(req), cmd = rt_r32(c, a);
    int32_t fd = (int32_t)rt_r32(c, a + 8), result = 0;
    const char *dev = (fd >= 0 && fd < 64 && fd_path[fd][0]) ? fd_path[fd] : "?";
    switch (cmd) {
    case 1: {                                              /* open */
        char path[48] = {0}; uint32_t p = rt_r32(c, a + 0xC);
        for (int i = 0; i < 47; i++) { path[i] = (char)rt_r8(c, ea(p) + (uint32_t)i); if (!path[i]) break; }
        if (!strncmp(path, "/dev/usb/", 9) && strcmp(path, BT_PATH)) {   /* other USB devices: not present */
            result = -6;
        } else {
            for (int i = 1; i < 64; i++) if (!fd_path[i][0]) { strcpy(fd_path[i], path); result = i; break; }
        }
        LOG("[ios] open \"%s\" mode %u -> %d%s\n", path, rt_r32(c, a + 0x10), result, result < 0 ? " (not present)" : "");
        break;
    }
    case 2: LOG("[ios] close fd %d (%s)\n", fd, dev); if (fd >= 0 && fd < 64) fd_path[fd][0] = 0; break;
    case 3: LOG("[ios] read  fd %d (%s) len %u\n", fd, dev, rt_r32(c, a + 0x10)); zero(c, rt_r32(c, a + 0xC), rt_r32(c, a + 0x10)); result = (int32_t)rt_r32(c, a + 0x10); break;
    case 4: LOG("[ios] write fd %d (%s) len %u\n", fd, dev, rt_r32(c, a + 0x10)); result = (int32_t)rt_r32(c, a + 0x10); break;
    case 5: LOG("[ios] seek  fd %d (%s)\n", fd, dev); break;
    case 6:                                                /* ioctl */
        LOG("[ios] ioctl fd %d (%s) req 0x%X in %u out %u\n", fd, dev, rt_r32(c, a + 0xC), rt_r32(c, a + 0x14), rt_r32(c, a + 0x1C));
        zero(c, rt_r32(c, a + 0x18), rt_r32(c, a + 0x1C));
        if (!strcmp(dev, "/dev/di")) {                    /* disc drive: 1 = success; 0x12 = inquiry; 0x70/0x71 = disc ID / read (rt_di.c) */
            result = 1;
            if (rt_di_ioctl(c, a)) {
            } else if (rt_r32(c, a + 0xC) == 0x12 && rt_r32(c, a + 0x1C) >= 0x20) {
                uint32_t out = ea(rt_r32(c, a + 0x18));
                rt_w32(c, out + 0, 0x00000002); rt_w32(c, out + 4, 0x20060526); rt_w32(c, out + 8, 0x41000000);
            }
        }
        break;
    case 7: {                                              /* ioctlv */
        if (!strcmp(dev, BT_PATH)) return bt_ioctlv(c, req);
        uint32_t nin = rt_r32(c, a + 0x10), nout = rt_r32(c, a + 0x14), vec = rt_r32(c, a + 0x18);
        LOG("[ios] ioctlv fd %d (%s) req 0x%X in %u out %u\n", fd, dev, rt_r32(c, a + 0xC), nin, nout);
        for (uint32_t i = 0; i < nout; i++) zero(c, rt_r32(c, ea(vec) + 8 * (nin + i)), rt_r32(c, ea(vec) + 8 * (nin + i) + 4));
        break;
    }
    default: LOG("[ios] unknown command %u\n", cmd); result = -4; break;
    }
    rt_w32(c, a + 8, cmd);                                 /* reply layout as IOS does: cmd=8, result, original cmd */
    rt_w32(c, a, 8);
    rt_w32(c, a + 4, (uint32_t)result);
    return 0;
}
