package org.wwe13recomp;

import java.util.List;

/** Plain-JVM test of the on-screen controller logic: java org.wwe13recomp.TouchPadLogicTest */
public final class TouchPadLogicTest {
    static int fails;
    static void check(boolean ok, String what) { if (!ok) { fails++; System.out.println("FAIL  " + what); } }
    static TouchPadLogic.Control find(TouchPadLogic t, String label, int kind) {
        for (TouchPadLogic.Control c : t.controls()) if (c.kind == kind && c.label.equals(label)) return c;
        throw new IllegalStateException(label);
    }
    static float[] centre(TouchPadLogic.Control c) { return c.kind == TouchPadLogic.BUTTON_RECT ? new float[] { (c.x0 + c.x1) / 2, (c.y0 + c.y1) / 2 } : new float[] { c.cx, c.cy }; }

    public static void main(String[] a) {
        for (int[] size : new int[][] { { 1920, 1080 }, { 2400, 1080 }, { 1280, 800 }, { 2048, 1536 } }) {
            TouchPadLogic t = new TouchPadLogic(); t.setSize(size[0], size[1]);
            String tag = size[0] + "x" + size[1] + ": ";
            // every button reports its own bit when tapped in the middle, and nothing else
            for (TouchPadLogic.Control c : t.controls()) {
                if (c.bit == 0) continue;
                float[] p = centre(c);
                t.pointer(1, p[0], p[1]);
                check(t.buttons() == c.bit, tag + "tap " + c.label + " -> " + Integer.toHexString(t.buttons()) + " expected " + Integer.toHexString(c.bit));
                t.release(1);
                check(t.buttons() == 0, tag + "release " + c.label);
            }
            // d-pad: four directions and a diagonal
            TouchPadLogic.Control dp = find(t, "", TouchPadLogic.DPAD);
            float r = dp.r * 0.8f;
            t.pointer(1, dp.cx, dp.cy - r); check(t.buttons() == TouchPadLogic.UP, tag + "dpad up");
            t.pointer(1, dp.cx, dp.cy + r); check(t.buttons() == TouchPadLogic.DOWN, tag + "dpad down (slide)");
            t.pointer(1, dp.cx - r, dp.cy); check(t.buttons() == TouchPadLogic.LEFT, tag + "dpad left");
            t.pointer(1, dp.cx + r, dp.cy); check(t.buttons() == TouchPadLogic.RIGHT, tag + "dpad right");
            t.pointer(1, dp.cx + r * 0.6f, dp.cy - r * 0.6f); check(t.buttons() == (TouchPadLogic.UP | TouchPadLogic.RIGHT), tag + "dpad up-right");
            t.pointer(1, dp.cx, dp.cy); check(t.buttons() == 0, tag + "dpad dead centre");
            t.release(1);
            // sliding from A to B (one finger) changes the button; between A and B (diamond corner) presses both
            TouchPadLogic.Control ba = find(t, "A", TouchPadLogic.BUTTON_ROUND), bb = find(t, "B", TouchPadLogic.BUTTON_ROUND);
            t.pointer(2, ba.cx, ba.cy); check(t.buttons() == TouchPadLogic.A, tag + "A");
            t.pointer(2, bb.cx, bb.cy); check(t.buttons() == TouchPadLogic.B, tag + "slide A->B");
            t.pointer(2, (ba.cx + bb.cx) / 2, (ba.cy + bb.cy) / 2); check(t.buttons() == (TouchPadLogic.A | TouchPadLogic.B), tag + "between A and B presses both");
            t.release(2);
            // left stick: half deflection to the right, full deflection up-left (clamped to length 1), then released
            TouchPadLogic.Control ls = find(t, "L", TouchPadLogic.STICK), rs = find(t, "R", TouchPadLogic.STICK);
            t.pointer(3, ls.cx, ls.cy); check(t.leftX() == 0 && t.leftY() == 0 && t.buttons() == 0, tag + "stick touched at centre");
            t.pointer(3, ls.cx + ls.r * 0.5f, ls.cy); check(Math.abs(t.leftX() - 0.5f) < 1e-4 && t.leftY() == 0, tag + "left stick half right");
            t.pointer(3, ls.cx - ls.r * 3, ls.cy - ls.r * 3);
            check(Math.abs(Math.hypot(t.leftX(), t.leftY()) - 1) < 1e-4 && t.leftX() < 0 && t.leftY() > 0, tag + "left stick clamped, up-left (y up is positive)");
            check(t.rightX() == 0 && t.rightY() == 0 && t.buttons() == 0, tag + "right stick untouched");
            // multi-touch: left stick held while A and the right stick are used
            t.pointer(4, ba.cx, ba.cy); t.pointer(5, rs.cx, rs.cy + rs.r * 0.5f);
            check(t.buttons() == TouchPadLogic.A, tag + "stick finger + A together");
            check(Math.abs(t.rightY() + 0.5f) < 1e-4, tag + "right stick pulled down (" + t.rightY() + ")");
            check(Math.abs(Math.hypot(t.leftX(), t.leftY()) - 1) < 1e-4, tag + "left stick still held");
            t.release(3); check(t.leftX() == 0 && t.leftY() == 0, tag + "left stick released");
            t.releaseAll(); check(t.buttons() == 0 && t.rightY() == 0, tag + "releaseAll");
            // a finger that starts on empty space and slides onto a button presses it
            t.pointer(6, size[0] / 2f, size[1] * 0.6f); check(t.buttons() == 0, tag + "empty space");
            t.pointer(6, ba.cx, ba.cy); check(t.buttons() == TouchPadLogic.A, tag + "slide in from empty space");
            t.releaseAll();
            // controls stay on screen
            for (TouchPadLogic.Control c : t.controls()) {
                float x0 = c.kind == TouchPadLogic.BUTTON_RECT ? c.x0 : c.cx - c.r, x1 = c.kind == TouchPadLogic.BUTTON_RECT ? c.x1 : c.cx + c.r;
                float y0 = c.kind == TouchPadLogic.BUTTON_RECT ? c.y0 : c.cy - c.r, y1 = c.kind == TouchPadLogic.BUTTON_RECT ? c.y1 : c.cy + c.r;
                check(x0 >= 0 && x1 <= size[0] && y0 >= 0 && y1 <= size[1], tag + "on screen: " + c.label + " " + c.kind);
            }
        }
        System.out.println((fails == 0 ? "PASS" : "FAIL") + "  on-screen Classic Controller logic (4 screen sizes)");
        System.exit(fails == 0 ? 0 : 1);
    }
}
