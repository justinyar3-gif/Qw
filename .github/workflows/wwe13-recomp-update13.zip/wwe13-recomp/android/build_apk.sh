#!/bin/bash
# Builds a debug APK from YOUR main.dol. Run it on a PC with: python3, a JDK 17+, and the Android SDK + NDK (ANDROID_HOME set; the
# NDK and CMake are installed from the SDK manager: "NDK (Side by side)" and "CMake"). Nothing from the disc is copied into the repo
# except the C generated from your own main.dol, which stays on your machine and ends up inside your APK: do not share the APK.
#
#   android/build_apk.sh /path/to/main.dol                       (uses ANDROID_HOME)
#   android/build_apk.sh /path/to/main.dol --install-sdk          (Linux / macOS / WSL: downloads Google's command-line tools into android/sdk and installs
#                                                                  platform 34, build-tools 34, NDK 26.1 and CMake 3.22.1 there; you accept Google's licences)
# Not run here: the machine this was written on could not reach dl.google.com / maven.google.com, so the download step and the Gradle build are untested.
set -e
DOL=${1:?usage: android/build_apk.sh /path/to/main.dol [--install-sdk]}
REPO=$(cd "$(dirname "$0")/.." && pwd)
SDK=${ANDROID_HOME:-$ANDROID_SDK_ROOT}
if [ "$2" = "--install-sdk" ]; then
  SDK="$REPO/android/sdk"; mkdir -p "$SDK/cmdline-tools"
  if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
    case "$(uname -s)" in Darwin) OS=mac;; *) OS=linux;; esac
    echo "downloading Google's Android command-line tools ($OS)..."
    curl -fL -o "$SDK/clt.zip" "https://dl.google.com/android/repository/commandlinetools-$OS-11076708_latest.zip"
    unzip -q -o "$SDK/clt.zip" -d "$SDK/cmdline-tools" && mv "$SDK/cmdline-tools/cmdline-tools" "$SDK/cmdline-tools/latest" && rm "$SDK/clt.zip"
  fi
  echo "Installing platform 34, build-tools 34.0.0, NDK 26.1.10909125 and CMake 3.22.1. Google's SDK licences will be shown: answer y to accept."
  "$SDK/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK" --licenses
  "$SDK/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK" "platforms;android-34" "build-tools;34.0.0" "ndk;26.1.10909125" "cmake;3.22.1"
fi
[ -n "$SDK" ] && [ -d "$SDK" ] || { echo "Set ANDROID_HOME to your Android SDK folder, or add --install-sdk."; exit 1; }
[ -f "$DOL" ] || { echo "Not found: $DOL"; exit 1; }
cd "$REPO"
echo "1/3 lifting $DOL to C (about 33 files of 2.7 MB; a few minutes)..."
python3 lifter.py gen "$DOL" out/functions.json gen/
echo "2/3 building the APK (compiles about 90 MB of C for arm64: expect 10 to 40 minutes the first time)..."
cd android
printf 'sdk.dir=%s\n' "$SDK" > local.properties
./gradlew --no-daemon assembleDebug -PWWE13_GEN="$REPO/gen"
cp app/build/outputs/apk/debug/app-debug.apk "$REPO/wwe13-debug.apk"
echo "3/3 done: $REPO/wwe13-debug.apk"
echo "Install:  adb install -r wwe13-debug.apk"
echo "Then copy the extracted disc folder (sys/ and files/) to /sdcard/WWE13/disc  (or Android/data/org.wwe13recomp/files/disc) and open the app."
