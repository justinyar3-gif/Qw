/* JNI entry points for the Android app: boots the recompiled game on a background thread and receives the touch controller state.
 * Everything the runtime prints to stderr goes to logcat (tag "wwe13"). Not built or run on a device yet. */
#include <android/log.h>
#include <android/native_window_jni.h>
#include <jni.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "rt.h"
#include "rt_input.h"
#include "rt_gxr.h"

Ctx *rt_ctx_new(void);
uint32_t rt_load_dol(Ctx *c, const char *path);
void rt_init_lowmem(Ctx *c);
int rt_run(Ctx *c, uint32_t entry, int timeout_s, int trace_n);
int rt_di_open(const char *root, int use_fst);
void rt_di_boot(Ctx *c);

#define TAG "wwe13"

static void *log_pump(void *arg) {                         /* stderr -> logcat, one line at a time */
    int fd = (int)(intptr_t)arg; char line[1024]; size_t n = 0; char ch;
    while (read(fd, &ch, 1) == 1) {
        if (ch == '\n' || n == sizeof line - 1) { line[n] = 0; if (n) __android_log_write(ANDROID_LOG_INFO, TAG, line); n = 0; }
        else line[n++] = ch;
    }
    return NULL;
}
static void redirect_stderr(void) {
    int p[2]; if (pipe(p)) return;
    dup2(p[1], 2); close(p[1]);
    pthread_t t; if (pthread_create(&t, NULL, log_pump, (void *)(intptr_t)p[0]) == 0) pthread_detach(t);
}

static char g_disc[768];
static void *boot_thread(void *arg) {
    (void)arg;
    char dol[800]; snprintf(dol, sizeof dol, "%s/sys/main.dol", g_disc);
    __android_log_print(ANDROID_LOG_INFO, TAG, "disc folder %s, DOL %s", g_disc, dol);
    Ctx *c = rt_ctx_new();
    uint32_t entry = rt_load_dol(c, dol);                  /* exits the process if the DOL cannot be read; the Java side checks first */
    rt_init_lowmem(c);
    if (rt_di_open(g_disc, 0)) { __android_log_print(ANDROID_LOG_ERROR, TAG, "cannot open the disc folder"); return NULL; }
    rt_di_boot(c);
    gxr_set_backend(&gxr_gles_backend);                    /* OpenGL ES 3: the context is created on its own thread at the first draw; it shows the picture on the window from setSurface */
    int rc = rt_run(c, entry, 0, 100);                     /* no watchdog */
    __android_log_print(ANDROID_LOG_INFO, TAG, "rt_run returned %d", rc);
    return NULL;
}

/* boolean Native.start(String discFolder): false if already running or the thread could not be created */
JNIEXPORT jboolean JNICALL Java_org_wwe13recomp_Native_start(JNIEnv *env, jclass cls, jstring disc) {
    (void)cls;
    static int started;
    if (started) return JNI_FALSE;
    const char *d = (*env)->GetStringUTFChars(env, disc, NULL);
    if (!d) return JNI_FALSE;
    snprintf(g_disc, sizeof g_disc, "%s", d);
    (*env)->ReleaseStringUTFChars(env, disc, d);
    redirect_stderr();
    pthread_t t;
    if (pthread_create(&t, NULL, boot_thread, NULL)) return JNI_FALSE;
    pthread_detach(t);
    started = 1;
    return JNI_TRUE;
}

/* void Native.setPad(int buttons, float lx, float ly, float rx, float ry): controller 1 (Classic Controller) */
JNIEXPORT void JNICALL Java_org_wwe13recomp_Native_setPad(JNIEnv *env, jclass cls, jint buttons, jfloat lx, jfloat ly, jfloat rx, jfloat ry) {
    (void)env; (void)cls;
    rt_pad_state s = { .buttons = (uint16_t)buttons, .lx = lx, .ly = ly, .rx = rx, .ry = ry };
    rt_pad_set(0, &s);
}

/* void Native.setSurface(Surface s): where the game is shown; null when the surface goes away. */
JNIEXPORT void JNICALL Java_org_wwe13recomp_Native_setSurface(JNIEnv *env, jclass cls, jobject surface) {
    (void)cls;
    static ANativeWindow *cur;
    ANativeWindow *w = surface ? ANativeWindow_fromSurface(env, surface) : NULL;
    gxr_gles_set_window(w);                                /* the EGL surface the render thread makes takes its own reference to the window */
    if (cur) ANativeWindow_release(cur);
    cur = w;
}
