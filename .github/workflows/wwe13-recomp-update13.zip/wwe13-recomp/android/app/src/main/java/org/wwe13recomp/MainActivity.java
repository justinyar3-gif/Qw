package org.wwe13recomp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.widget.FrameLayout;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import java.io.File;

/** Full-screen activity: starts the recompiled game from the extracted disc folder and shows the on-screen Classic Controller. */
public final class MainActivity extends Activity {
    private PadView pad;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        SurfaceView game = new SurfaceView(this);                               // the game's picture (OpenGL ES, drawn by the native render thread)
        game.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override public void surfaceCreated(SurfaceHolder h) { Native.setSurface(h.getSurface()); }
            @Override public void surfaceChanged(SurfaceHolder h, int format, int w, int hh) { }
            @Override public void surfaceDestroyed(SurfaceHolder h) { Native.setSurface(null); }
        });
        pad = new PadView(this);                                                // the touch controller, on top
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(android.graphics.Color.BLACK);
        ViewGroup.LayoutParams fill = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        root.addView(game, fill); root.addView(pad, fill);
        setContentView(root);
        hideBars();
        File disc = findDisc();
        if (disc == null) {
            if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) askAllFilesAccess();
            pad.setStatus("No disc folder found. Put the extracted disc (folders sys and files) in\n"
                    + "/sdcard/WWE13/disc  or  " + new File(getExternalFilesDir(null), "disc") + "\nthen open the app again.");
            return;
        }
        pad.setStatus("Starting from " + disc + "\nNo sound yet. The first seconds are black while the game loads.");
        if (!Native.start(disc.getAbsolutePath())) pad.setStatus("Could not start the game thread.");
        else pad.postDelayed(new Runnable() { @Override public void run() { pad.setStatus(""); } }, 10000);
    }

    /** First folder that holds sys/main.dol. */
    private File findDisc() {
        File[] candidates = { new File(Environment.getExternalStorageDirectory(), "WWE13/disc"), new File(getExternalFilesDir(null), "disc") };
        for (File d : candidates) if (new File(d, "sys/main.dol").canRead() && new File(d, "files").isDirectory()) return d;
        return null;
    }

    private void askAllFilesAccess() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
        } catch (Exception e) { /* settings screen not available: the app's own folder still works */ }
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override public void onWindowFocusChanged(boolean focus) { super.onWindowFocusChanged(focus); if (focus) hideBars(); }

    /** The game thread cannot be stopped from outside, so leaving the app ends the process. */
    @Override protected void onDestroy() { super.onDestroy(); if (isFinishing()) System.exit(0); }
}
