package org.wwe13recomp;

/** JNI bridge to libwwe13.so (android/app/src/main/cpp/rt_android.c). */
final class Native {
    static { System.loadLibrary("wwe13"); }
    private Native() {}

    /** Starts the recompiled game on a background thread; discFolder holds sys/ and files/. False if already started. */
    static native boolean start(String discFolder);

    /** Where the game's picture is shown (the SurfaceView's surface); null when it is destroyed. */
    static native void setSurface(android.view.Surface surface);

    /** Controller 1 as a Classic Controller: button bits (TouchPadLogic.*) and stick positions (-1..1, y up). */
    static native void setPad(int buttons, float lx, float ly, float rx, float ry);
}
