package org.wwe13recomp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Draws the on-screen Classic Controller (layout and touch logic: TouchPadLogic) over the game picture and sends its state to the game. */
final class PadView extends View {
    private final TouchPadLogic logic = new TouchPadLogic();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), stroke = new Paint(Paint.ANTI_ALIAS_FLAG), text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private String status = "";
    private int lastButtons = -1;
    private float lastLx, lastLy, lastRx, lastRy;

    PadView(Context ctx) {
        super(ctx);
        stroke.setStyle(Paint.Style.STROKE); stroke.setColor(Color.argb(200, 255, 255, 255)); stroke.setStrokeWidth(3f);
        text.setColor(Color.WHITE); text.setTextAlign(Paint.Align.CENTER);
    }

    void setStatus(String s) { status = s; invalidate(); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) { logic.setSize(w, h); }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        if (action == MotionEvent.ACTION_CANCEL) logic.releaseAll();
        else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) {
            logic.release(e.getPointerId(e.getActionIndex()));
            if (action == MotionEvent.ACTION_UP) logic.releaseAll();
        } else {                                               // DOWN, POINTER_DOWN, MOVE: update every finger on the screen
            for (int i = 0; i < e.getPointerCount(); i++) logic.pointer(e.getPointerId(i), e.getX(i), e.getY(i));
        }
        send();
        invalidate();
        return true;
    }

    private void send() {
        int b = logic.buttons(); float lx = logic.leftX(), ly = logic.leftY(), rx = logic.rightX(), ry = logic.rightY();
        if (b == lastButtons && lx == lastLx && ly == lastLy && rx == lastRx && ry == lastRy) return;
        lastButtons = b; lastLx = lx; lastLy = ly; lastRx = rx; lastRy = ry;
        Native.setPad(b, lx, ly, rx, ry);
    }

    @Override protected void onDraw(Canvas c) {
        float u = Math.min(getHeight(), getWidth() / 1.7f);
        text.setTextSize(0.05f * u);
        for (TouchPadLogic.Control k : logic.controls()) {
            boolean down = logic.pressed(k);
            fill.setColor(down ? Color.argb(150, 255, 255, 255) : Color.argb(50, 255, 255, 255));
            switch (k.kind) {
                case TouchPadLogic.BUTTON_ROUND:
                    c.drawCircle(k.cx, k.cy, k.r, fill); c.drawCircle(k.cx, k.cy, k.r, stroke);
                    c.drawText(k.label, k.cx, k.cy + text.getTextSize() / 3f, text);
                    break;
                case TouchPadLogic.BUTTON_RECT:
                    rect.set(k.x0, k.y0, k.x1, k.y1);
                    c.drawRoundRect(rect, 0.03f * u, 0.03f * u, fill); c.drawRoundRect(rect, 0.03f * u, 0.03f * u, stroke);
                    c.drawText(k.label, (k.x0 + k.x1) / 2f, (k.y0 + k.y1) / 2f + text.getTextSize() / 3f, text);
                    break;
                case TouchPadLogic.DPAD: {
                    int b = logic.buttons();
                    float arm = k.r * 0.38f, len = k.r;
                    drawArm(c, k, 0, -1, (b & TouchPadLogic.UP) != 0, arm, len);
                    drawArm(c, k, 0, 1, (b & TouchPadLogic.DOWN) != 0, arm, len);
                    drawArm(c, k, -1, 0, (b & TouchPadLogic.LEFT) != 0, arm, len);
                    drawArm(c, k, 1, 0, (b & TouchPadLogic.RIGHT) != 0, arm, len);
                    break;
                }
                case TouchPadLogic.STICK: {
                    c.drawCircle(k.cx, k.cy, k.r, fill); c.drawCircle(k.cx, k.cy, k.r, stroke);
                    boolean left = k.label.equals("L");
                    float sx = (left ? logic.leftX() : logic.rightX()) * k.r, sy = -(left ? logic.leftY() : logic.rightY()) * k.r;
                    fill.setColor(Color.argb(140, 255, 255, 255));
                    c.drawCircle(k.cx + sx, k.cy + sy, k.r * 0.45f, fill);
                    break;
                }
                default: break;
            }
        }
        if (!status.isEmpty()) {
            text.setTextSize(0.04f * u);
            c.drawText(status, getWidth() / 2f, 0.45f * getHeight(), text);
        }
    }

    private void drawArm(Canvas c, TouchPadLogic.Control k, int dx, int dy, boolean on, float arm, float len) {
        fill.setColor(on ? Color.argb(150, 255, 255, 255) : Color.argb(50, 255, 255, 255));
        float cx = k.cx + dx * len * 0.55f, cy = k.cy + dy * len * 0.55f;
        float hw = dx != 0 ? len * 0.45f : arm, hh = dy != 0 ? len * 0.45f : arm;
        rect.set(cx - hw, cy - hh, cx + hw, cy + hh);
        c.drawRoundRect(rect, 12f, 12f, fill); c.drawRoundRect(rect, 12f, 12f, stroke);
    }
}
