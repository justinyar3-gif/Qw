package org.wwe13recomp;

import java.util.ArrayList;
import java.util.List;

/**
 * On-screen Classic Controller: layout and touch handling, with no Android dependencies (so it can be unit-tested on a plain JVM).
 *
 * Feed it pointers (pointer id + position in pixels); it keeps the button bits and stick positions that result from all fingers on
 * the screen. Fingers may slide between buttons, and several buttons / both sticks can be used at the same time.
 * The bit values are the SDK's WPAD_BUTTON_CL_* values and must match runtime/rt_input.h.
 */
public final class TouchPadLogic {
    public static final int UP = 0x0001, LEFT = 0x0002, ZR = 0x0004, X = 0x0008, A = 0x0010, Y = 0x0020, B = 0x0040, ZL = 0x0080,
            R = 0x0200, PLUS = 0x0400, HOME = 0x0800, MINUS = 0x1000, L = 0x2000, DOWN = 0x4000, RIGHT = 0x8000;

    public static final int BUTTON_ROUND = 0, BUTTON_RECT = 1, DPAD = 2, STICK = 3;

    /** One drawn / touchable element. Coordinates are pixels. */
    public static final class Control {
        public final int kind, bit;
        public final String label;
        public final float cx, cy, r;            // circle (round buttons, d-pad, sticks); r = drawn radius
        public final float x0, y0, x1, y1;       // rectangle (shoulder buttons)
        Control(int kind, int bit, String label, float cx, float cy, float r, float x0, float y0, float x1, float y1) {
            this.kind = kind; this.bit = bit; this.label = label; this.cx = cx; this.cy = cy; this.r = r; this.x0 = x0; this.y0 = y0; this.x1 = x1; this.y1 = y1;
        }
        boolean hit(float x, float y) {
            if (kind == BUTTON_RECT) return x >= x0 && x <= x1 && y >= y0 && y <= y1;
            float dx = x - cx, dy = y - cy, rr = kind == BUTTON_ROUND ? r * 1.3f : r;     // round buttons get a generous hit radius
            return dx * dx + dy * dy <= rr * rr;
        }
    }

    private static final class Pointer { int id; float x, y; int stick = -1; }     // stick: 0 = left, 1 = right, -1 = none

    private final List<Control> controls = new ArrayList<>();
    private final List<Pointer> pointers = new ArrayList<>();
    private Control leftStick, rightStick;
    private int buttons;
    private float lx, ly, rx, ry;
    private int width, height;

    public TouchPadLogic() { setSize(1920, 1080); }

    /** Lays the controls out for a landscape screen. Sizes follow the screen height, but on squarer screens (4:3 tablets) they shrink so the
     *  left and right groups and the centre buttons do not overlap; the sticks and the - / HOME / + buttons then stay at the bottom edge. */
    public void setSize(int w, int h) {
        width = w; height = h;
        controls.clear();
        final float u = Math.min(h, w / 1.7f), m = 0.05f * u, down = h - u;      // down: extra offset of the bottom controls
        // left half: d-pad above, left stick below
        float lcx = m + 0.28f * u, rcx = w - lcx;
        controls.add(new Control(DPAD, 0, "", lcx, 0.36f * u, 0.22f * u, 0, 0, 0, 0));
        leftStick = new Control(STICK, 0, "L", lcx, 0.80f * u + down, 0.18f * u, 0, 0, 0, 0);
        controls.add(leftStick);
        // right half: A B X Y diamond above (X top, B bottom, Y left, A right), right stick below
        float d = 0.15f * u, br = 0.085f * u, by = 0.36f * u;
        controls.add(new Control(BUTTON_ROUND, X, "X", rcx, by - d, br, 0, 0, 0, 0));
        controls.add(new Control(BUTTON_ROUND, B, "B", rcx, by + d, br, 0, 0, 0, 0));
        controls.add(new Control(BUTTON_ROUND, Y, "Y", rcx - d, by, br, 0, 0, 0, 0));
        controls.add(new Control(BUTTON_ROUND, A, "A", rcx + d, by, br, 0, 0, 0, 0));
        rightStick = new Control(STICK, 0, "R", rcx, 0.80f * u + down, 0.18f * u, 0, 0, 0, 0);
        controls.add(rightStick);
        // shoulders along the top edge: L and ZL on the left, R and ZR on the right
        float sh = 0.12f * u, sw = 0.30f * u, top = 0.02f * u;
        controls.add(new Control(BUTTON_RECT, L, "L", 0, 0, 0, m, top, m + sw, top + sh));
        controls.add(new Control(BUTTON_RECT, ZL, "ZL", 0, 0, 0, m + sw + 0.02f * u, top, m + 2 * sw + 0.02f * u, top + sh));
        controls.add(new Control(BUTTON_RECT, R, "R", 0, 0, 0, w - m - sw, top, w - m, top + sh));
        controls.add(new Control(BUTTON_RECT, ZR, "ZR", 0, 0, 0, w - m - 2 * sw - 0.02f * u, top, w - m - sw - 0.02f * u, top + sh));
        // centre bottom: - HOME +
        float cy = 0.93f * u + down, cr = 0.055f * u, gap = 0.17f * u;
        controls.add(new Control(BUTTON_ROUND, MINUS, "-", w / 2f - gap, cy, cr, 0, 0, 0, 0));
        controls.add(new Control(BUTTON_ROUND, HOME, "H", w / 2f, cy, cr, 0, 0, 0, 0));
        controls.add(new Control(BUTTON_ROUND, PLUS, "+", w / 2f + gap, cy, cr, 0, 0, 0, 0));
        pointers.clear();
        recompute();
    }

    public int width() { return width; }
    public int height() { return height; }
    public List<Control> controls() { return controls; }

    /** A finger went down or moved. */
    public void pointer(int id, float x, float y) {
        Pointer p = null;
        for (Pointer q : pointers) if (q.id == id) p = q;
        if (p == null) {                                           // new finger: it may capture a stick that is free
            p = new Pointer(); p.id = id; pointers.add(p);
            p.x = x; p.y = y;
            for (int s = 0; s < 2; s++) {
                Control c = s == 0 ? leftStick : rightStick;
                boolean taken = false;
                for (Pointer q : pointers) if (q != p && q.stick == s) taken = true;
                float dx = x - c.cx, dy = y - c.cy;
                if (!taken && dx * dx + dy * dy <= (c.r * 1.4f) * (c.r * 1.4f)) { p.stick = s; break; }
            }
        }
        p.x = x; p.y = y;
        recompute();
    }

    /** A finger lifted. */
    public void release(int id) {
        for (int i = pointers.size() - 1; i >= 0; i--) if (pointers.get(i).id == id) pointers.remove(i);
        recompute();
    }

    public void releaseAll() { pointers.clear(); recompute(); }

    private void recompute() {
        int b = 0; float slx = 0, sly = 0, srx = 0, sry = 0;
        for (Pointer p : pointers) {
            if (p.stick >= 0) {                                    // this finger drives a stick; it presses no buttons
                Control c = p.stick == 0 ? leftStick : rightStick;
                float dx = (p.x - c.cx) / c.r, dy = (p.y - c.cy) / c.r, len = (float) Math.sqrt(dx * dx + dy * dy);
                if (len > 1f) { dx /= len; dy /= len; }
                if (p.stick == 0) { slx = dx; sly = -dy; } else { srx = dx; sry = -dy; }
                continue;
            }
            for (Control c : controls) {
                if (c.kind == STICK || !c.hit(p.x, p.y)) continue;
                if (c.kind == DPAD) b |= dpadBits(c, p.x, p.y); else b |= c.bit;
            }
        }
        buttons = b; lx = slx; ly = sly; rx = srx; ry = sry;
    }

    private static int dpadBits(Control c, float x, float y) {
        float dx = x - c.cx, dy = y - c.cy, dist = (float) Math.sqrt(dx * dx + dy * dy);
        if (dist < 0.25f * c.r) return 0;                          // dead centre
        int b = 0;
        if (Math.abs(dy) >= 0.38f * dist) b |= dy < 0 ? UP : DOWN;
        if (Math.abs(dx) >= 0.38f * dist) b |= dx < 0 ? LEFT : RIGHT;
        return b;
    }

    public int buttons() { return buttons; }
    public float leftX() { return lx; }
    public float leftY() { return ly; }
    public float rightX() { return rx; }
    public float rightY() { return ry; }
    public boolean pressed(Control c) { return c.bit != 0 && (buttons & c.bit) != 0; }
}
