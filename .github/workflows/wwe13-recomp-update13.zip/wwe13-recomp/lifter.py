#!/usr/bin/env python3
"""Milestone 1: PowerPC (Gekko) integer + branch lifter -> C.

Design: all guest state lives in a Ctx struct, so splitting code into C functions
at any point is always semantically safe (fallthrough becomes a call). Branches
inside a function become goto; branches out become tail calls.

Usage:
  python lifter.py coverage main.dol out/functions.json
  python lifter.py gen      main.dol out/functions.json gen/ [--limit N] [--per-file 1000]

Not handled yet (emitted as RT_UNIMPL): floating point, paired singles, atomics,
system instructions. bctr jump tables need recovery (milestone 3).
"""
import os
import sys
import json
from bisect import bisect_right
from collections import Counter

import dol_tool

M32 = 0xFFFFFFFF


def sx(v, bits):
    v &= (1 << bits) - 1
    return v - (1 << bits) if v >> (bits - 1) else v


def u32(v):
    return "0x%Xu" % (v & M32)


def R(n):
    return "c->r[%d]" % n


def ppc_mask(mb, me):
    a = M32 >> mb
    b = (M32 << (31 - me)) & M32
    return (a & b) if mb <= me else (a | b)


class Image:
    """Executable words of the program, as (base_addr, words) segments."""

    def __init__(self, segs, data=(), ptrdata=()):
        self.segs = sorted((a, tuple(ws)) for a, ws in segs)
        self.data = sorted(data)          # (base_addr, bytes): everything readable, for jump tables
        self.ptrdata = sorted(ptrdata)    # data sections only, scanned for code pointers

    @classmethod
    def from_dol(cls, d, secs):
        return cls([(s["addr"], dol_tool.words(d, s)) for s in secs if s["kind"] == "text"],
                   [(s["addr"], d[s["offset"]:s["offset"] + s["size"]]) for s in secs],
                   [(s["addr"], d[s["offset"]:s["offset"] + s["size"]]) for s in secs if s["kind"] == "data"])

    def read32(self, a):
        for base, b in self.data:
            if base <= a and a + 4 <= base + len(b):
                return int.from_bytes(b[a - base:a - base + 4], "big")
        return None

    def _seg(self, a):
        for base, ws in self.segs:
            if base <= a < base + 4 * len(ws):
                return base, ws
        return None

    def in_text(self, a):
        return a % 4 == 0 and self._seg(a) is not None

    def word(self, a):
        base, ws = self._seg(a)
        return ws[(a - base) >> 2]

    def seg_end(self, a):
        base, ws = self._seg(a)
        return base + 4 * len(ws)


def branch_target(pc, w):
    op = w >> 26
    if op == 18:
        li = sx(w & 0x03FFFFFC, 26)
    elif op == 16:
        li = sx(w & 0xFFFC, 16)
    else:
        return None
    return (li if (w & 2) else pc + li) & M32


def plan_functions(img, seeds, extra_edges=()):
    """Seeds plus every out-of-function branch target, iterated to a fixpoint."""
    starts = {a for a in seeds if img.in_text(a)}
    starts |= {base for base, _ in img.segs}
    br = []
    for base, ws in img.segs:
        for i, w in enumerate(ws):
            if (w >> 26) in (16, 18) and not (w & 1):
                pc = base + 4 * i
                t = branch_target(pc, w)
                if img.in_text(t):
                    br.append((pc, t))
    br.extend((pc, t) for pc, t in extra_edges if img.in_text(t))
    while True:
        sl = sorted(starts)
        new = {t for pc, t in br
               if t not in starts and bisect_right(sl, pc) != bisect_right(sl, t)}
        if not new:
            return sl
        starts |= new


def extra_seeds(img):
    """Function starts that no `bl` or prologue reveals. Yields (addr, strong): code pointers in data and
    addresses built with lis+addi/ori are strong; the word after an unconditional blr is weak (it may be
    mid-function after an early return). Extra starts are always safe (see README)."""
    found = Counter()
    for base, b in img.ptrdata:                       # (1) pointers stored in data sections
        for i in range(0, len(b) - 3, 4):
            t = int.from_bytes(b[i:i + 4], "big")
            if img.in_text(t):
                found["data pointer"] += 1
                yield t, True
    for base, ws in img.segs:
        n = len(ws)
        for i, w in enumerate(ws):
            if w == 0x4E800020 and i + 1 < n and ws[i + 1] != 0:      # (3) code right after a blr
                found["after blr"] += 1
                yield base + 4 * (i + 1), False
            if w >> 26 == 15 and ((w >> 16) & 31) == 0:               # (2) lis rD, hi ; addi/ori rX, rD, lo
                rd, hi = (w >> 21) & 31, (w & 0xFFFF) << 16
                for j in range(i + 1, min(n, i + 5)):
                    x = ws[j]
                    if (x >> 16) & 31 != rd:
                        continue
                    if x >> 26 == 14:
                        t = (hi + sx(x, 16)) & M32
                    elif x >> 26 == 24:
                        t = hi | (x & 0xFFFF)
                    else:
                        continue
                    if img.in_text(t):
                        found["lis+lo"] += 1
                        yield t, True
                    break
    extra_seeds.stats = found


# ---------------------------------------------------------------- jump table recovery
BCTR = 0x4E800420
MTCTR_MASK, MTCTR = 0xFC1FFFFF, 0x7C0903A6


def _const_sim(words_):
    """Forward constant propagation over lis/addis/addi/ori/oris. Returns {reg: value}."""
    k = {}
    for w in words_:
        op, rd, ra = w >> 26, (w >> 21) & 31, (w >> 16) & 31
        simm, uimm = sx(w, 16), w & 0xFFFF
        if op in (14, 15):
            imm = simm if op == 14 else simm << 16
            if ra == 0:
                k[rd] = imm & M32
            elif ra in k:
                k[rd] = (k[ra] + imm) & M32
            else:
                k.pop(rd, None)
        elif op in (24, 25):                       # ori/oris: rA <- rS | imm
            if rd in k:
                k[ra] = (k[rd] | (uimm << 16 if op == 25 else uimm)) & M32
            else:
                k.pop(ra, None)
        elif op in (10, 11, 16, 18, 19) or (op == 31 and ((w >> 1) & 0x3FF) in (0, 32)):
            pass                                   # compares and branches write no GPR
        else:                                      # conservative: forget whatever it may write
            k.pop(rd, None)
            k.pop(ra, None)
    return k


def analyze_bctr(img, base, ws, i, fidx=0):
    """Try to resolve the jump table feeding the bctr at index i. Returns (targets, how) or (None, reason)."""
    pc = base + 4 * i
    lo = max(0, i - 40)
    win = ws[lo:i]
    cut = max((j + 1 for j, w in enumerate(win) if w in (0x4E800020, BCTR)), default=0)
    win = win[cut:]                         # never look back past the previous function's return
    # 1. mtctr rJ
    m = next((j for j in range(len(win) - 1, max(-1, len(win) - 8), -1) if (win[j] & MTCTR_MASK) == MTCTR), None)
    if m is None:
        return None, "no mtctr"
    rj = (win[m] >> 21) & 31
    # 2. lwzx rJ, rA, rB defining it
    lj = next((j for j in range(m - 1, max(-1, m - 8), -1)
               if win[j] >> 26 == 31 and ((win[j] >> 1) & 0x3FF) == 23 and ((win[j] >> 21) & 31) == rj), None)
    if lj is None:
        return None, "no lwzx"
    ra, rb = (win[lj] >> 16) & 31, (win[lj] >> 11) & 31
    # constants known at the lwzx; look back to the function start so that a base register
    # loaded once in the prologue (e.g. `lis r20, hi`) is still known here
    end = lo + cut + lj
    consts = _const_sim(ws[max(fidx, end - 4000):end])
    tbl = consts.get(ra) if ra in consts else consts.get(rb)
    if tbl is None or img.read32(tbl) is None:
        return None, "table base unknown"
    # 3. bound from cmplwi + the conditional branch (bc or bclr) that tests it
    n = None
    for j in range(lj - 1, -1, -1):
        w = win[j]
        if w >> 26 != 10:
            continue
        crf, bound = (w >> 23) & 7, w & 0xFFFF
        for k in range(j + 1, min(len(win), j + 10)):
            bw = win[k]
            if bw >> 26 == 16 or (bw >> 26 == 19 and ((bw >> 1) & 0x3FF) == 16):
                bi = (bw >> 16) & 31
                if bi >> 2 == crf:
                    n = bound + 1 if (bi & 3) == 1 else bound if (bi & 3) == 0 else None
                    break
        if n is not None:
            break
    targets, how = [], "bounded"
    limit = n if n is not None else 1024
    for k in range(limit):
        t = img.read32(tbl + 4 * k)
        ok = t is not None and img.in_text(t) and abs(t - pc) < 0x40000
        if not ok:
            if n is not None:
                return None, "entry %d invalid" % k
            break
        targets.append(t)
    if n is None:
        how = "scanned"
        if len(targets) < 3:
            return None, "unbounded, too few entries"
    return sorted(set(targets)), how


def find_jump_tables(img, seeds=()):
    """Resolve switch tables behind unconditional bctr. Returns ({bctr_pc: targets}, Counter(reasons))."""
    from bisect import bisect_right as br
    seeds = sorted(seeds)
    tables, why = {}, Counter()
    for base, ws in img.segs:
        for i, w in enumerate(ws):
            if w != BCTR:
                continue
            pc = base + 4 * i
            k = br(seeds, pc) - 1
            fidx = max(0, (seeds[k] - base) >> 2) if k >= 0 and seeds[k] >= base else 0
            tg, how = analyze_bctr(img, base, ws, i, fidx)
            if tg:
                tables[pc] = tg
                why["resolved (" + how + ")"] += 1
            else:
                why["unresolved: " + how] += 1
    return tables, why


# ---------------------------------------------------------------- instruction lifting
class FuncCtx:
    def __init__(self, start, end, fnset, stats, jt=None):
        self.start, self.end, self.fnset, self.stats = start, end, fnset, stats
        self.jt = jt or {}
        self.labels = set()


def jump_stmt(L, t, pc=None):
    if L.start <= t < L.end:
        L.labels.add(t)
        if pc is not None and t <= pc:      # loop back-edge: a poll point for interrupts
            return "{ RT_POLL(c); goto L_%08X; }" % t
        return "goto L_%08X;" % t
    if t in L.fnset:
        return "{ func_%08X(c); return; }" % t
    return "{ rt_call_indirect(c, %s); return; }" % u32(t)


def call_stmt(L, t, pc):
    pre = "c->lr = %s; " % u32(pc + 4)
    if t in L.fnset:
        return pre + "func_%08X(c);" % t
    return pre + "rt_call_indirect(c, %s);" % u32(t)


def cond_parts(bo, bi):
    """Return (pre_statements, condition_expr) for a BO/BI pair."""
    pre, terms = "", []
    if not (bo & 4):
        pre = "c->ctr--; "
        terms.append("c->ctr == 0" if bo & 2 else "c->ctr != 0")
    if not (bo & 0x10):
        terms.append("rt_crget(c, %d) == %d" % (bi, 1 if bo & 8 else 0))
    return pre, " && ".join(terms) if terms else "1"


LOADS = {32: ("rt_r32", 0), 33: ("rt_r32", 1), 34: ("rt_r8", 0), 35: ("rt_r8", 1),
         40: ("rt_r16", 0), 41: ("rt_r16", 1), 42: ("rt_r16s", 0), 43: ("rt_r16s", 1)}
STORES = {36: ("rt_w32", 0), 37: ("rt_w32", 1), 38: ("rt_w8", 0), 39: ("rt_w8", 1),
          44: ("rt_w16", 0), 45: ("rt_w16", 1)}
LOADX = {23: ("rt_r32", 0), 55: ("rt_r32", 1), 87: ("rt_r8", 0), 119: ("rt_r8", 1),
         279: ("rt_r16", 0), 311: ("rt_r16", 1), 343: ("rt_r16s", 0), 375: ("rt_r16s", 1)}
STOREX = {151: ("rt_w32", 0), 183: ("rt_w32", 1), 215: ("rt_w8", 0), 247: ("rt_w8", 1),
          407: ("rt_w16", 0), 439: ("rt_w16", 1)}
NOPS31 = {54, 86, 246, 278, 470, 982, 598, 854}  # dcbst dcbf dcbtst dcbt dcbi icbi sync eieio
LOGIC = {28: "{S} & {B}", 60: "{S} & ~{B}", 124: "~({S} | {B})", 444: "{S} | {B}",
         412: "{S} | ~{B}", 316: "{S} ^ {B}", 476: "~({S} & {B})", 284: "~({S} ^ {B})"}
ARITH = {266, 10, 138, 202, 40, 8, 136, 200, 104, 235, 75, 11, 491, 459}
CROPS = {33: "!({a} | {b})", 129: "{a} & !{b}", 193: "{a} ^ {b}", 225: "!({a} & {b})",
         257: "{a} & {b}", 289: "!({a} ^ {b})", 417: "{a} | !{b}", 449: "{a} | {b}"}


def arith(xo9, A, B, D):
    carry = "{ uint64_t t = %s; %s = (uint32_t)t; c->xer_ca = (uint32_t)(t >> 32); }"
    nA = "(uint64_t)(uint32_t)~%s" % A
    table = {
        266: "%s = %s + %s;" % (D, A, B),
        10: carry % ("(uint64_t)%s + (uint64_t)%s" % (A, B), D),
        138: carry % ("(uint64_t)%s + (uint64_t)%s + (uint64_t)c->xer_ca" % (A, B), D),
        202: carry % ("(uint64_t)%s + (uint64_t)c->xer_ca" % A, D),
        40: "%s = %s - %s;" % (D, B, A),
        8: carry % ("%s + (uint64_t)%s + 1u" % (nA, B), D),
        136: carry % ("%s + (uint64_t)%s + (uint64_t)c->xer_ca" % (nA, B), D),
        200: carry % ("%s + (uint64_t)c->xer_ca" % nA, D),
        104: "%s = 0u - %s;" % (D, A),
        235: "%s = %s * %s;" % (D, A, B),
        75: "%s = (uint32_t)(((int64_t)(int32_t)%s * (int64_t)(int32_t)%s) >> 32);" % (D, A, B),
        11: "%s = (uint32_t)(((uint64_t)%s * (uint64_t)%s) >> 32);" % (D, A, B),
        491: "%s = rt_divw(%s, %s);" % (D, A, B),
        459: "%s = rt_divwu(%s, %s);" % (D, A, B),
    }
    return table[xo9]


def lift_insn(L, pc, w):
    """Return (C code, terminates) or None if this instruction isn't supported yet."""
    op = w >> 26
    rd, ra, rb = (w >> 21) & 31, (w >> 16) & 31, (w >> 11) & 31
    rc = w & 1
    simm, uimm = sx(w, 16), w & 0xFFFF
    A, B, D = R(ra), R(rb), R(rd)

    def rc0(reg):
        return (" rt_cr0(c, %s);" % R(reg)) if rc else ""

    ea_d = u32(simm) if ra == 0 else "(%s + %s)" % (A, u32(simm))
    ea_x = B if ra == 0 else "(%s + %s)" % (A, B)

    if op in FP_OPS or (op == 31 and ((w >> 1) & 0x3FF) in FP31):
        return lift_fp(w)
    if op == 3:      # twi TO, rA, SIMM
        return "if (rt_trap_cond(%d, %s, %s)) rt_trap(c, %s);" % (rd, A, u32(simm), u32(pc)), False
    if op == 31 and ((w >> 1) & 0x3FF) == 4:      # tw TO, rA, rB
        return "if (rt_trap_cond(%d, %s, %s)) rt_trap(c, %s);" % (rd, A, B, u32(pc)), False
    if w == 0x44000002:
        return "", False    # sc: in this game it only ends the cache flush/invalidate routines (a sync)

    # ---- D-form arithmetic / logic
    if op == 14:
        return ("%s = %s;" % (D, u32(simm)) if ra == 0 else "%s = %s + %s;" % (D, A, u32(simm))), False
    if op == 15:
        v = (simm << 16) & M32
        return ("%s = %s;" % (D, u32(v)) if ra == 0 else "%s = %s + %s;" % (D, A, u32(v))), False
    if op in (12, 13):
        t = "{ uint64_t t = (uint64_t)%s + (uint64_t)%s; %s = (uint32_t)t; c->xer_ca = (uint32_t)(t >> 32); }" % (A, u32(simm), D)
        return t + (" rt_cr0(c, %s);" % D if op == 13 else ""), False
    if op == 8:
        return ("{ uint64_t t = (uint64_t)(uint32_t)~%s + (uint64_t)%s + 1u; %s = (uint32_t)t; "
                "c->xer_ca = (uint32_t)(t >> 32); }" % (A, u32(simm), D)), False
    if op == 7:
        return "%s = %s * %s;" % (D, A, u32(simm)), False
    if op in (24, 25, 26, 27, 28, 29):
        imm = uimm << 16 if op in (25, 27, 29) else uimm
        sym = {24: "|", 25: "|", 26: "^", 27: "^", 28: "&", 29: "&"}[op]
        if op == 24 and rd == ra and uimm == 0:
            return "", False  # nop
        code = "%s = %s %s %s;" % (A, D, sym, u32(imm))
        return code + (" rt_cr0(c, %s);" % A if op in (28, 29) else ""), False
    if op in (11, 10):
        crf = (w >> 23) & 7
        if op == 11:
            return "rt_cmp_s(c, %d, (int32_t)%s, (int32_t)%d);" % (crf, A, simm), False
        return "rt_cmp_u(c, %d, %s, %s);" % (crf, A, u32(uimm)), False

    # ---- loads / stores
    if op in LOADS:
        fn, upd = LOADS[op]
        if upd:
            return "{ uint32_t ea = %s + %s; %s = %s(c, ea); %s = ea; }" % (A, u32(simm), D, fn, A), False
        return "%s = %s(c, %s);" % (D, fn, ea_d), False
    if op in STORES:
        fn, upd = STORES[op]
        if upd:
            return "{ uint32_t ea = %s + %s; %s(c, ea, %s); %s = ea; }" % (A, u32(simm), fn, D, A), False
        return "%s(c, %s, %s);" % (fn, ea_d, D), False
    if op == 46:
        return ("{ uint32_t ea = %s; for (int i = %d; i < 32; i++) c->r[i] = rt_r32(c, ea + 4u * (uint32_t)(i - %d)); }"
                % (ea_d, rd, rd)), False
    if op == 47:
        return ("{ uint32_t ea = %s; for (int i = %d; i < 32; i++) rt_w32(c, ea + 4u * (uint32_t)(i - %d), c->r[i]); }"
                % (ea_d, rd, rd)), False

    # ---- rotates
    if op in (20, 21, 23):
        mb, me = (w >> 6) & 31, (w >> 1) & 31
        mask = ppc_mask(mb, me)
        rot = ("rt_rotl(%s, %d)" % (D, rb)) if op != 23 else ("rt_rotl(%s, %s)" % (D, B))
        if op == 20:
            code = "%s = (%s & %s) | (%s & %s);" % (A, rot, u32(mask), A, u32(~mask))
        elif op == 21 and rb == 0:
            code = "%s = %s & %s;" % (A, D, u32(mask))
        else:
            code = "%s = %s & %s;" % (A, rot, u32(mask))
        return code + rc0(ra), False

    # ---- branches
    if op == 18:
        t = branch_target(pc, w)
        if w & 1:
            return call_stmt(L, t, pc), False
        return jump_stmt(L, t, pc), True
    if op == 16:
        bo, bi = rd, ra
        t = branch_target(pc, w)
        pre, cond = cond_parts(bo, bi)
        if w & 1:
            if bo == 20 and t == pc + 4:
                return "c->lr = %s;" % u32(pc + 4), False   # bcl 20,31,$+4 (get PC)
            callee = ("func_%08X(c);" % t) if t in L.fnset else ("rt_call_indirect(c, %s);" % u32(t))
            return "c->lr = %s; { %sif (%s) { %s } }" % (u32(pc + 4), pre, cond, callee), False
        if cond == "1":
            return pre + jump_stmt(L, t, pc), True
        return "{ %sif (%s) %s }" % (pre, cond, jump_stmt(L, t, pc)), False
    if op == 19:
        xo = (w >> 1) & 0x3FF
        bo, bi = rd, ra
        if xo == 16:  # bclr
            pre, cond = cond_parts(bo, bi)
            if w & 1:
                return "{ %suint32_t t = c->lr; c->lr = %s; if (%s) rt_call_indirect(c, t); }" % (pre, u32(pc + 4), cond), False
            if cond == "1":
                return pre + "return;", True
            return "{ %sif (%s) return; }" % (pre, cond), False
        if xo == 528:  # bcctr
            pre, cond = cond_parts(bo | 4, bi)  # CTR is never decremented here
            L.stats["jump_indirect"] += 0 if w & 1 else 1
            if w & 1:
                return "{ if (%s) { uint32_t t = c->ctr; c->lr = %s; rt_call_indirect(c, t); } }" % (cond, u32(pc + 4)), False
            if cond == "1":
                tg = L.jt.get(pc)
                if tg:
                    L.stats["jump_tables"] += 1
                    cases = "\n".join("    case %s: %s" % (u32(t), jump_stmt(L, t, pc)) for t in tg)
                    return ("switch (c->ctr) {\n%s\n    default: rt_jump_indirect(c, c->ctr); return;\n  }" % cases), True
                return "rt_jump_indirect(c, c->ctr); return;", True
            return "{ if (%s) { rt_jump_indirect(c, c->ctr); return; } }" % cond, False
        if xo == 150:
            return "", False  # isync
        if xo == 50:  # rfi: msr <- SRR1, jump to SRR0. The SDK uses it for RealMode(fn): fn's blr returns to our caller.
            return ("c->msr = c->spr[27]; if (c->spr[26] == c->lr) return; "
                    "rt_jump_indirect(c, c->spr[26]); return;"), True   # rfi to LR = a return
        if xo == 0:
            return "c->cr[%d] = c->cr[%d];" % ((w >> 23) & 7, (w >> 18) & 7), False
        if xo in CROPS:
            expr = CROPS[xo].format(a="rt_crget(c, %d)" % ra, b="rt_crget(c, %d)" % rb)
            return "rt_crset(c, %d, %s);" % (rd, expr), False
        return None

    # ---- opcode 31
    if op == 31:
        xo = (w >> 1) & 0x3FF
        xo9 = xo & 0x1FF
        if xo9 in ARITH and xo in (xo9, xo9 | 0x200):
            if xo != xo9:
                return None  # OE=1 (overflow tracking) not implemented
            return arith(xo9, A, B, D) + rc0(rd), False
        if xo in LOGIC:
            return "%s = %s;" % (A, LOGIC[xo].format(S=D, B=B)) + rc0(ra), False
        if xo in (0, 32):
            crf = (w >> 23) & 7
            if xo == 0:
                return "rt_cmp_s(c, %d, (int32_t)%s, (int32_t)%s);" % (crf, A, B), False
            return "rt_cmp_u(c, %d, %s, %s);" % (crf, A, B), False
        if xo in LOADX:
            fn, upd = LOADX[xo]
            if upd:
                return "{ uint32_t ea = %s + %s; %s = %s(c, ea); %s = ea; }" % (A, B, D, fn, A), False
            return "%s = %s(c, %s);" % (D, fn, ea_x), False
        if xo in STOREX:
            fn, upd = STOREX[xo]
            if upd:
                return "{ uint32_t ea = %s + %s; %s(c, ea, %s); %s = ea; }" % (A, B, fn, D, A), False
            return "%s(c, %s, %s);" % (fn, ea_x, D), False
        if xo == 534:
            return "%s = __builtin_bswap32(rt_r32(c, %s));" % (D, ea_x), False
        if xo == 790:
            return "%s = __builtin_bswap16((uint16_t)rt_r16(c, %s));" % (D, ea_x), False
        if xo == 662:
            return "rt_w32(c, %s, __builtin_bswap32(%s));" % (ea_x, D), False
        if xo == 918:
            return "rt_w16(c, %s, __builtin_bswap16((uint16_t)%s));" % (ea_x, D), False
        if xo == 24:
            return "{ uint32_t n = %s & 63u; %s = n > 31 ? 0u : %s << n; }" % (B, A, D) + rc0(ra), False
        if xo == 536:
            return "{ uint32_t n = %s & 63u; %s = n > 31 ? 0u : %s >> n; }" % (B, A, D) + rc0(ra), False
        if xo == 792:
            return ("{ uint32_t n = %s & 63u; uint32_t v = %s; int32_t s = (int32_t)v; uint32_t r, ca; "
                    "if (n > 31) { r = (uint32_t)(s >> 31); ca = s < 0; } "
                    "else { r = (uint32_t)(s >> n); ca = (s < 0) && ((v & ((1u << n) - 1u)) != 0); } "
                    "%s = r; c->xer_ca = ca; }" % (B, D, A)) + rc0(ra), False
        if xo == 824:
            mask = (1 << rb) - 1
            return ("{ uint32_t v = %s; int32_t s = (int32_t)v; uint32_t ca = (s < 0) && ((v & %s) != 0); "
                    "%s = (uint32_t)(s >> %d); c->xer_ca = ca; }" % (D, u32(mask), A, rb)) + rc0(ra), False
        if xo == 26:
            return "%s = %s ? (uint32_t)__builtin_clz(%s) : 32u;" % (A, D, D) + rc0(ra), False
        if xo == 954:
            return "%s = (uint32_t)(int32_t)(int8_t)%s;" % (A, D) + rc0(ra), False
        if xo == 922:
            return "%s = (uint32_t)(int32_t)(int16_t)%s;" % (A, D) + rc0(ra), False
        if xo == 339:
            spr = ((w >> 16) & 31) | (((w >> 11) & 31) << 5)
            src = {1: "rt_get_xer(c)", 8: "c->lr", 9: "c->ctr", 22: "rt_get_dec(c)",
                   268: "rt_mftb(c, 0)", 269: "rt_mftb(c, 1)"}.get(spr, "c->spr[%d]" % spr)
            return "%s = %s;" % (D, src), False
        if xo == 467:
            spr = ((w >> 16) & 31) | (((w >> 11) & 31) << 5)
            if spr == 1:
                return "rt_set_xer(c, %s);" % D, False
            if spr == 22:
                return "rt_set_dec(c, %s);" % D, False
            dst = {8: "c->lr", 9: "c->ctr"}.get(spr, "c->spr[%d]" % spr)
            return "%s = %s;" % (dst, D), False
        if xo == 371:  # mftb
            tbr = ((w >> 16) & 31) | (((w >> 11) & 31) << 5)
            return "%s = rt_mftb(c, %d);" % (D, 1 if tbr == 269 else 0), False
        if xo == 20:   # lwarx (single-threaded model: no reservation tracking)
            return "%s = rt_r32(c, %s);" % (D, ea_x), False
        if xo == 150 and rc:  # stwcx. always succeeds in this model (no preemption between the pair)
            return "rt_w32(c, %s, %s); c->cr[0] = (uint8_t)(2 | c->xer_so);" % (ea_x, D), False
        if xo == 19:
            return "%s = rt_mfcr(c);" % D, False
        if xo == 144:
            return "rt_mtcrf(c, %d, %s);" % ((w >> 12) & 0xFF, D), False
        if xo == 83:   # mfmsr / mtmsr / segment registers (processor state lives in Ctx)
            return "%s = c->msr;" % D, False
        if xo == 146:
            return "c->msr = %s;" % D, False
        if xo == 595:
            return "%s = c->sr[%d];" % (D, (w >> 16) & 15), False
        if xo == 210:
            return "c->sr[%d] = %s;" % ((w >> 16) & 15, D), False
        if xo == 659:
            return "%s = c->sr[%s >> 28];" % (D, B), False
        if xo == 242:
            return "c->sr[%s >> 28] = %s;" % (B, D), False
        if xo == 1014:
            return "rt_dcbz(c, %s);" % ea_x, False
        if xo in NOPS31:
            return "", False
        return None
    return None


# ---------------------------------------------------------------- floating point (M2)
FP_OPS = {4, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 59, 60, 61, 63}
FP31 = {535, 567, 599, 631, 663, 695, 727, 759, 983}
FPLS31 = {535: "lfs", 567: "lfs", 599: "lfd", 631: "lfd", 663: "stfs", 695: "stfs",
          727: "stfd", 759: "stfd", 983: "stfiwx"}
SINGLE_ARITH = {21: "rt_add_s({a}, {b})", 20: "rt_sub_s({a}, {b})", 25: "rt_mul_s({a}, {c})",
                18: "rt_div_s({a}, {b})", 29: "rt_madd_s({a}, {c}, {b})", 28: "rt_msub_s({a}, {c}, {b})",
                31: "rt_nmadd_s({a}, {c}, {b})", 30: "rt_nmsub_s({a}, {c}, {b})",
                24: "rt_res_s({b})", 26: "rt_rsqrte_s({b})", 23: "({a} >= 0.0 ? {c} : {b})"}
DOUBLE_ARITH = {21: "{a} + {b}", 20: "{a} - {b}", 25: "{a} * {c}", 18: "{a} / {b}",
                29: "rt_fma({a}, {c}, {b})", 28: "rt_fma({a}, {c}, -{b})",
                31: "-rt_fma({a}, {c}, {b})", 30: "-rt_fma({a}, {c}, -{b})",
                23: "({a} >= 0.0 ? {c} : {b})", 26: "rt_rsqrte_d({b})"}


def lift_fp(w):
    """Floating point and paired single instructions. Returns (code, False) or None."""
    op = w >> 26
    fd, fa, fb, fc = (w >> 21) & 31, (w >> 16) & 31, (w >> 11) & 31, (w >> 6) & 31
    rc = w & 1
    xo10, xo5 = (w >> 1) & 0x3FF, (w >> 1) & 0x1F
    cr1 = " rt_fpscr_to_cr1(c);" if rc else ""
    P = lambda n, lane: "c->ps[%d][%d]" % (n, lane)
    ra, simm = fa, sx(w, 16)
    A = R(ra)

    # ---- scalar loads / stores
    if op in (48, 49, 50, 51, 52, 53, 54, 55):
        fn = "rt_" + {48: "lfs", 49: "lfs", 50: "lfd", 51: "lfd",
                      52: "stfs", 53: "stfs", 54: "stfd", 55: "stfd"}[op]
        if op in (49, 51, 53, 55):
            return "{ uint32_t ea = %s + %s; %s(c, %d, ea); %s = ea; }" % (A, u32(simm), fn, fd, A), False
        ea = u32(simm) if ra == 0 else "(%s + %s)" % (A, u32(simm))
        return "%s(c, %d, %s);" % (fn, fd, ea), False
    if op == 31 and xo10 in FPLS31:
        rb = fb
        fn = "rt_" + FPLS31[xo10]
        if xo10 in (567, 631, 695, 759):
            return "{ uint32_t ea = %s + %s; %s(c, %d, ea); %s = ea; }" % (A, R(rb), fn, fd, A), False
        ea = R(rb) if ra == 0 else "(%s + %s)" % (A, R(rb))
        return "%s(c, %d, %s);" % (fn, fd, ea), False

    # ---- quantized paired-single loads / stores
    if op in (56, 57, 60, 61):
        fn = "rt_psq_l" if op in (56, 57) else "rt_psq_st"
        wbit, gq, disp = (w >> 15) & 1, (w >> 12) & 7, sx(w, 12)
        if op in (57, 61):
            return "{ uint32_t ea = %s + %s; %s(c, %d, ea, %d, %d); %s = ea; }" % (A, u32(disp), fn, fd, wbit, gq, A), False
        ea = u32(disp) if ra == 0 else "(%s + %s)" % (A, u32(disp))
        return "%s(c, %d, %s, %d, %d);" % (fn, fd, ea, wbit, gq), False
    if op == 4 and xo10 in (6, 7, 38, 39):
        fn = "rt_psq_l" if xo10 in (6, 38) else "rt_psq_st"
        wbit, gq, rb = (w >> 10) & 1, (w >> 7) & 7, fb
        if xo10 in (38, 39):
            return "{ uint32_t ea = %s + %s; %s(c, %d, ea, %d, %d); %s = ea; }" % (A, R(rb), fn, fd, wbit, gq, A), False
        ea = R(rb) if ra == 0 else "(%s + %s)" % (A, R(rb))
        return "%s(c, %d, %s, %d, %d);" % (fn, fd, ea, wbit, gq), False

    if op == 4 and xo10 == 1014:      # dcbz_l: zero a 32-byte block of the locked cache
        rb = fb
        return "rt_dcbz(c, %s);" % (R(rb) if ra == 0 else "(%s + %s)" % (A, R(rb))), False

    # ---- paired-single arithmetic
    if op == 4:
        a0, a1, b0, b1, c0, c1 = P(fa, 0), P(fa, 1), P(fb, 0), P(fb, 1), P(fc, 0), P(fc, 1)

        def pair(e0, e1):
            return "{ double r0 = %s; double r1 = %s; %s = r0; %s = r1; }" % (e0, e1, P(fd, 0), P(fd, 1)) + cr1
        crf = (w >> 23) & 7
        if xo10 in (0, 32, 64, 96):
            lane = 1 if xo10 >= 64 else 0
            return "rt_fcmp(c, %d, %s, %s);" % (crf, P(fa, lane), P(fb, lane)), False
        xform = {72: ("%s" % b0, "%s" % b1), 40: ("-%s" % b0, "-%s" % b1),
                 264: ("fabs(%s)" % b0, "fabs(%s)" % b1), 136: ("-fabs(%s)" % b0, "-fabs(%s)" % b1),
                 528: (a0, b0), 560: (a0, b1), 592: (a1, b0), 624: (a1, b1)}
        if xo10 in xform:
            return pair(*xform[xo10]), False
        f = lambda t, **kw: t.format(**kw)
        if xo5 in SINGLE_ARITH:
            t = SINGLE_ARITH[xo5]
            return pair(f(t, a=a0, b=b0, c=c0), f(t, a=a1, b=b1, c=c1)), False
        special = {
            10: ("rt_add_s(%s, %s)" % (a0, b1), "rt_single(%s)" % c1),     # ps_sum0
            11: ("rt_single(%s)" % c0, "rt_add_s(%s, %s)" % (a0, b1)),     # ps_sum1
            12: ("rt_mul_s(%s, %s)" % (a0, c0), "rt_mul_s(%s, %s)" % (a1, c0)),   # ps_muls0
            13: ("rt_mul_s(%s, %s)" % (a0, c1), "rt_mul_s(%s, %s)" % (a1, c1)),   # ps_muls1
            14: ("rt_madd_s(%s, %s, %s)" % (a0, c0, b0), "rt_madd_s(%s, %s, %s)" % (a1, c0, b1)),  # ps_madds0
            15: ("rt_madd_s(%s, %s, %s)" % (a0, c1, b0), "rt_madd_s(%s, %s, %s)" % (a1, c1, b1)),  # ps_madds1
        }
        if xo5 in special:
            return pair(*special[xo5]), False
        return None

    # ---- single-precision scalar (writes ps0 and duplicates into ps1)
    if op == 59 and xo5 in SINGLE_ARITH and xo5 not in (26, 23):
        e = SINGLE_ARITH[xo5].format(a=P(fa, 0), b=P(fb, 0), c=P(fc, 0))
        return "{ double r = %s; %s = r; %s = r; }" % (e, P(fd, 0), P(fd, 1)) + cr1, False

    # ---- double-precision scalar
    if op == 63:
        if xo10 in (0, 32):
            return "rt_fcmp(c, %d, %s, %s);" % ((w >> 23) & 7, P(fa, 0), P(fb, 0)), False
        simple = {72: P(fb, 0), 40: "-" + P(fb, 0), 264: "fabs(%s)" % P(fb, 0),
                  136: "-fabs(%s)" % P(fb, 0), 12: "rt_single(%s)" % P(fb, 0),
                  14: "rt_fctiw(%s, 0)" % P(fb, 0), 15: "rt_fctiw(%s, 1)" % P(fb, 0),
                  583: "rt_u2d(0xFFF8000000000000ull | c->fpscr)"}
        if xo10 in simple:
            return "%s = %s;" % (P(fd, 0), simple[xo10]) + cr1, False
        if xo10 == 711:
            return "rt_mtfsf(c, %d, (uint32_t)rt_d2u(%s));" % ((w >> 17) & 0xFF, P(fb, 0)) + cr1, False
        if xo10 in (38, 70):
            return "rt_mtfsb(c, %d, %d);" % (fd, 1 if xo10 == 38 else 0) + cr1, False
        if xo10 == 134:
            return "rt_mtfsfi(c, %d, %d);" % ((w >> 23) & 7, (w >> 12) & 15) + cr1, False
        if xo5 in DOUBLE_ARITH:
            e = DOUBLE_ARITH[xo5].format(a=P(fa, 0), b=P(fb, 0), c=P(fc, 0))
            return "%s = %s;" % (P(fd, 0), e) + cr1, False
    return None


def insn_key(w):
    op = w >> 26
    name = dol_tool.OPNAMES.get(op, "op%d" % op)
    if op in (4, 19, 31, 59, 63):
        return "%s xo=%d" % (name, (w >> 1) & 0x3FF)
    return name


def lift_function(img, start, end, fnset, unimpl, stats, jt=None):
    L = FuncCtx(start, end, fnset, stats, jt)
    rows, term = [], False
    for pc in range(start, end, 4):
        w = img.word(pc)
        r = lift_insn(L, pc, w)
        if r is None and w == 0:
            stats["padding"] += 1
            r = ("RT_UNIMPL(c, 0x00000000u, 0x%08Xu);" % pc, False)
        elif r is None:
            unimpl[insn_key(w)] += 1
            r = ("RT_UNIMPL(c, 0x%08Xu, 0x%08Xu);" % (w, pc), False)
        rows.append((pc, r[0]))
        term = r[1]
        if w != 0:
            stats["insns"] += 1
    # weak: game-specific HLE code can override any function by defining it strongly
    out = ["__attribute__((weak)) void func_%08X(Ctx *c) {" % start, "  RT_TRACE(c, 0x%08Xu);" % start]
    for pc, code in rows:
        if pc in L.labels:
            out.append("L_%08X:;" % pc)
        if code:
            out.append("  " + code + ("  /* %08X */" % pc if os.environ.get("RT_ANNOTATE") else ""))
    if not term:
        out.append("  " + ("func_%08X(c);" % end if end in fnset else "rt_fell_off(c, %s);" % u32(end)))
    out.append("}")
    return "\n".join(out)


def function_ranges(img, starts):
    for i, s in enumerate(starts):
        nxt = starts[i + 1] if i + 1 < len(starts) else 1 << 32
        yield s, min(nxt, img.seg_end(s))


def emit_funcs_h(starts):
    return '#include "rt.h"\n' + "".join("void func_%08X(Ctx *c);\n" % s for s in starts)


def emit_dispatch(starts):
    rows = "".join("  {0x%08Xu, func_%08X},\n" % (s, s) for s in starts)
    return ('#include "rt.h"\n#include "funcs.h"\n'
            "const rt_func_entry rt_func_table[] = {\n%s};\n"
            "const uint32_t rt_func_count = %d;\n" % (rows, len(starts)))


# ---------------------------------------------------------------- CLI
def load_plan(dol, fjson):
    d, secs, meta = dol_tool.load(dol)
    img = Image.from_dol(d, secs)
    seeds = [int(a, 16) for a in json.load(open(fjson))["functions"]]
    seeds0 = set(seeds)
    extra = {a for a, _ in extra_seeds(img)}
    jt, why = find_jump_tables(img, sorted(seeds0))   # lookback bounded by scan-derived starts only
    jt_targets = {t for ts in jt.values() for t in ts}   # switch case labels are not function starts
    seeds = sorted(seeds0 | (extra - jt_targets))
    print("function seeds: %d from scan + %d from code pointers %s" %
          (len(seeds0), len(seeds) - len(seeds0), dict(extra_seeds.stats)), file=sys.stderr)
    edges = [(pc, t) for pc, ts in jt.items() for t in ts]
    starts = plan_functions(img, seeds, edges)
    return img, starts, jt, why


def cmd_coverage(img, starts, jt, why):
    unimpl, stats = Counter(), Counter()
    fnset = set(starts)
    for s, e in function_ranges(img, starts):
        lift_function(img, s, e, fnset, unimpl, stats, jt)
    total, bad = stats["insns"], sum(unimpl.values())
    print("%d functions, %d instructions (+%d zero-padding words)" % (len(starts), total, stats["padding"]))
    print("lifted: %d (%.1f%%), unimplemented: %d (%.1f%%)" %
          (total - bad, 100.0 * (total - bad) / total, bad, 100.0 * bad / total))
    print("\nbctr sites: %d" % sum(why.values()))
    for k, n in why.most_common():
        print("  %5d  %s" % (n, k))
    print("  (no lwzx / base unknown = indirect tail calls through pointers; dispatched at runtime)")
    print("\nTop unimplemented:")
    for k, n in unimpl.most_common(15):
        print("  %-34s %7d" % (k, n))


def cmd_gen(img, starts, jt, outdir, limit, per_file=0):
    os.makedirs(outdir, exist_ok=True)
    fnset = set(starts)
    open(os.path.join(outdir, "funcs.h"), "w").write(emit_funcs_h(starts))
    open(os.path.join(outdir, "dispatch.c"), "w").write(emit_dispatch(starts))
    ranges = list(function_ranges(img, starts))
    if limit:
        ranges = ranges[:limit]
    unimpl, stats = Counter(), Counter()
    groups = {}
    for s_, e_ in ranges:                              # 256 KB of guest code per file: stable names
        groups.setdefault((s_ - 0x80000000) >> 18, []).append((s_, e_))
    for old in os.listdir(outdir):
        if old.startswith("part_"):
            os.remove(os.path.join(outdir, old))
    for g, rs in sorted(groups.items()):
        chunk = [lift_function(img, s_, e_, fnset, unimpl, stats, jt) for s_, e_ in rs]
        with open(os.path.join(outdir, "part_%05X.c" % g), "w") as f:
            f.write('#include "rt.h"\n#include "funcs.h"\n\n' + "\n\n".join(chunk) + "\n")
    print("Wrote %d functions in %d files to %s (%d jump tables, %d unimplemented insns)" %
          (len(ranges), len(groups), outdir, stats["jump_tables"], sum(unimpl.values())))


def main():
    a = sys.argv[1:]
    if len(a) < 3 or a[0] not in ("coverage", "gen"):
        sys.exit(__doc__)
    img, starts, jt, why = load_plan(a[1], a[2])
    if a[0] == "coverage":
        return cmd_coverage(img, starts, jt, why)
    if len(a) < 4:
        sys.exit(__doc__)
    limit = int(a[a.index("--limit") + 1]) if "--limit" in a else 0
    per = int(a[a.index("--per-file") + 1]) if "--per-file" in a else 1000
    cmd_gen(img, starts, jt, a[3], limit, per)


if __name__ == "__main__":
    main()
