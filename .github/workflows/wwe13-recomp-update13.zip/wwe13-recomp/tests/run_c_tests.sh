#!/bin/bash
# Builds and runs the runtime tests (virtual controller, virtual disc, threads, interrupts, decrementer).
cd "$(dirname "$0")/.." || exit 1
R=runtime
gcc -O1 -Wall -ffp-contract=off -frounding-math -I$R tests/test_threads.c $R/rt.c $R/rt_mmio.c $R/rt_irq.c \
    $R/rt_thread.c $R/rt_ios.c $R/rt_hle.c $R/rt_gx.c $R/rt_gxr.c $R/rt_gxr_soft.c $R/rt_gxr_tex.c -o /tmp/test_threads -lm -lpthread || exit 1
rc=0
gcc -O1 -Wall -ffp-contract=off -frounding-math -I$R tests/test_gxr.c $R/rt.c $R/rt_mmio.c $R/rt_irq.c \
    $R/rt_thread.c $R/rt_ios.c $R/rt_hle.c $R/rt_gx.c $R/rt_gxr.c $R/rt_gxr_soft.c $R/rt_gxr_tex.c -o /tmp/test_gxr -lm -lpthread || exit 1
gcc -O1 -Wall -ffp-contract=off -frounding-math -I$R tests/test_gxr_gles.c $R/rt.c $R/rt_mmio.c $R/rt_irq.c \
    $R/rt_thread.c $R/rt_ios.c $R/rt_hle.c $R/rt_gx.c $R/rt_gxr.c $R/rt_gxr_soft.c $R/rt_gxr_tex.c $R/rt_gxr_gles.c -o /tmp/test_gxr_gles -lm -lpthread -ldl || exit 1
timeout 20 /tmp/test_gxr || { echo "FAIL  test_gxr (exit $?)"; rc=1; }
RT_GL_HEADLESS=${RT_GL_HEADLESS-1} timeout 120 /tmp/test_gxr_gles || { echo "FAIL  test_gxr_gles (exit $?)"; rc=1; }     # SKIPs (passes) without EGL / OpenGL ES 3
gcc -O1 -Wall -ffp-contract=off -frounding-math -I$R tests/test_di.c $R/rt.c $R/rt_mmio.c $R/rt_irq.c \
    $R/rt_thread.c $R/rt_ios.c $R/rt_hle.c $R/rt_gx.c $R/rt_gxr.c $R/rt_gxr_soft.c $R/rt_gxr_tex.c $R/rt_di.c $R/rt_boot.c $R/rt_input.c -o /tmp/test_di -lm -lpthread || exit 1
gcc -O1 -Wall -ffp-contract=off -frounding-math -I$R tests/test_input.c $R/rt_input.c $R/rt.c $R/rt_mmio.c $R/rt_irq.c \
    $R/rt_thread.c $R/rt_ios.c $R/rt_hle.c $R/rt_gx.c $R/rt_gxr.c $R/rt_gxr_soft.c $R/rt_gxr_tex.c -o /tmp/test_input -lm -lpthread || exit 1
timeout 10 /tmp/test_input || { echo "FAIL  test_input (exit $?)"; rc=1; }
for m in fst folder; do timeout 10 /tmp/test_di $m || { echo "FAIL  test_di $m (exit $?)"; rc=1; }; done
for t in sc_aspect ping_pong interrupt decrementer irq_switch; do
  timeout 10 /tmp/test_threads $t || { echo "FAIL  $t (exit $?)"; rc=1; }
done
exit $rc
