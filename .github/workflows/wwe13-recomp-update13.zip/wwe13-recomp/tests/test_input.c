/* Tests the virtual Classic Controller: the KPADStatus bytes written for the game, edges, scripts, disabled channels. */
#include "rt_input.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
const rt_func_entry rt_func_table[] = { {0x80100000u, 0} };
const uint32_t rt_func_count = 0;
static int fails;
#define CHECK(cond, ...) do { if (!(cond)) { fails++; printf("FAIL  "); printf(__VA_ARGS__); printf("\n"); } } while (0)
static float f32(Ctx *c, uint32_t a) { uint32_t u = rt_r32(c, a); float f; memcpy(&f, &u, 4); return f; }
static uint32_t BUF = 0x80200000u, ERR = 0x80210000u;
static uint32_t read_pad(Ctx *c, int chan) { c->r[3] = (uint32_t)chan; c->r[4] = BUF; c->r[5] = 16; c->r[6] = ERR; rt_hle_kpad_read_ex(c); return c->r[3]; }
int main(void) {
    Ctx *c = calloc(1, sizeof *c); c->mem1 = calloc(1, 0x1800000); c->mem2 = calloc(1, 0x4000000);
    /* nothing pressed: one sample, Classic Controller, no error */
    rt_w32(c, ERR, 0x1234);
    CHECK(read_pad(c, 0) == 1, "channel 0 returns one sample");
    CHECK(rt_r8(c, BUF + 0x5C) == 2 && rt_r8(c, BUF + 0x5D) == 0 && rt_r8(c, BUF + 0x5E) == 0, "dev_type 2 / wpad_err 0 / no pointer");
    CHECK(rt_r32(c, ERR) == 0, "error word is 0");
    CHECK(rt_r32(c, BUF + 0x60) == 0 && rt_r32(c, BUF) == 0, "no buttons");
    /* A + right pressed: hold and trig, then hold only, then release */
    rt_pad_state s = { .buttons = RT_CL_A | RT_CL_RIGHT, .lx = 1.f, .ly = -0.5f, .rt = 0.5f }; rt_pad_set(0, &s);
    read_pad(c, 0);
    CHECK(rt_r32(c, BUF + 0x60) == 0x8010 && rt_r32(c, BUF + 0x64) == 0x8010 && rt_r32(c, BUF + 0x68) == 0, "hold/trig on first press (got %X %X %X)", rt_r32(c, BUF + 0x60), rt_r32(c, BUF + 0x64), rt_r32(c, BUF + 0x68));
    CHECK(f32(c, BUF + 0x6C) == 1.f && fabsf(f32(c, BUF + 0x70) + 0.5f) < 0.01f && fabsf(f32(c, BUF + 0x80) - 0.5f) < 0.02f, "sticks/trigger (%f %f %f)", f32(c, BUF + 0x6C), f32(c, BUF + 0x70), f32(c, BUF + 0x80));
    read_pad(c, 0);
    CHECK(rt_r32(c, BUF + 0x60) == 0x8010 && rt_r32(c, BUF + 0x64) == 0, "held: no new trig");
    s.buttons = RT_CL_RIGHT; s.lx = 0; s.ly = 0; s.rt = 0; rt_pad_set(0, &s);
    read_pad(c, 0);
    CHECK(rt_r32(c, BUF + 0x60) == 0x8000 && rt_r32(c, BUF + 0x68) == 0x0010, "release of A (got hold %X release %X)", rt_r32(c, BUF + 0x60), rt_r32(c, BUF + 0x68));
    /* L button reads as full trigger */
    s.buttons = RT_CL_L; rt_pad_set(0, &s); read_pad(c, 0);
    CHECK(f32(c, BUF + 0x7C) == 1.f, "L click -> ltrigger 1.0");
    /* channels 1..3: no controller */
    rt_w32(c, BUF, 0xAAAAAAAA);
    CHECK(read_pad(c, 1) == 0 && (int32_t)rt_r32(c, ERR) == -2 && rt_r32(c, BUF) == 0xAAAAAAAA, "channel 1: no samples, error -2, buffer untouched");
    rt_pad_enable(1, 1); CHECK(read_pad(c, 1) == 1, "channel 1 after enabling");
    rt_pad_enable(0, 0); CHECK(read_pad(c, 0) == 0 && (int32_t)rt_r32(c, ERR) == -2, "channel 0 disabled"); rt_pad_enable(0, 1);
    /* no error pointer / zero-length request */
    c->r[3] = 0; c->r[4] = BUF; c->r[5] = 0; c->r[6] = 0; rt_hle_kpad_read_ex(c); CHECK(c->r[3] == 0, "count 0 -> no samples");
    /* scripts */
    CHECK(rt_pad_parse_script("A:2:3,PLUS+B:10:1") == 2, "script parses");
    CHECK(rt_pad_parse_script("Q:1:1") == -1 && rt_pad_parse_script("A:1") == -1 && rt_pad_parse_script("A:1:0") == -1, "bad scripts are rejected");
    rt_pad_parse_script("A:2:3,PLUS+B:10:1");
    s.buttons = 0; rt_pad_set(0, &s);
    /* the script clock starts when the script is set; find the window by reading until A shows */
    int first = -1, last = -1;
    for (int i = 0; i < 40; i++) { read_pad(c, 0); uint32_t h = rt_r32(c, BUF + 0x60); if (h & RT_CL_A) { if (first < 0) first = i; last = i; } }
    CHECK(last - first == 2, "script A lasts 3 reads (first %d last %d)", first, last);
    printf("%s  virtual Classic Controller: KPADStatus bytes, edges, triggers, channels, scripts\n", fails ? "FAIL" : "PASS");
    return fails != 0;
}
