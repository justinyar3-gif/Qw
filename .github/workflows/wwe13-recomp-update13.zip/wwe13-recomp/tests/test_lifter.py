#!/usr/bin/env python3
"""Lift hand-assembled PowerPC snippets to C, compile with gcc, run, and compare registers."""
import os, struct, subprocess, sys, tempfile
from fractions import Fraction
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
import lifter

# ---- tiny assembler helpers
def d(op, a, b, imm): return (op << 26) | (a << 21) | (b << 16) | (imm & 0xFFFF)
def x(rt, ra, rb, xo, rc=0): return (31 << 26) | (rt << 21) | (ra << 16) | (rb << 11) | (xo << 1) | rc
def m(rs, ra, sh, mb, me, op=21, rc=0): return (op << 26) | (rs << 21) | (ra << 16) | (sh << 11) | (mb << 6) | (me << 1) | rc
def bc(bo, bi, off, lk=0): return (16 << 26) | (bo << 21) | (bi << 16) | (off & 0xFFFC) | lk
def b(off, lk=0): return (18 << 26) | (off & 0x03FFFFFC) | lk
def mtspr(spr, rs): return (31 << 26) | (rs << 21) | ((spr & 31) << 16) | (((spr >> 5) & 31) << 11) | (467 << 1)
def mfspr(rd, spr): return (31 << 26) | (rd << 21) | ((spr & 31) << 16) | (((spr >> 5) & 31) << 11) | (339 << 1)
def xl(bt, ba, bb, xo, lk=0): return (19 << 26) | (bt << 21) | (ba << 16) | (bb << 11) | (xo << 1) | lk
BLR, NOP, BCTRL = 0x4E800020, 0x60000000, 0x4E800421
LI = lambda r, v: d(14, r, 0, v)
BASE = 0x80100000

# ---- floating point helpers (independent of the C runtime)
def d2b(x): return struct.unpack('>Q', struct.pack('>d', x))[0]
def fb2db(fb): return d2b(struct.unpack('>f', struct.pack('>I', fb))[0])     # float bits -> double bits
def fa(op, frd, fra, frb, frc, xo, rc=0): return (op << 26) | (frd << 21) | (fra << 16) | (frb << 11) | (frc << 6) | (xo << 1) | rc
def fx(op, frd, fra, frb, xo, rc=0): return (op << 26) | (frd << 21) | (fra << 16) | (frb << 11) | (xo << 1) | rc
def psq(op, frd, ra, w, i, disp): return (op << 26) | (frd << 21) | (ra << 16) | (w << 15) | (i << 12) | (disp & 0xFFF)

def round_f32(v):
    """Exact Fraction -> float32 bits, round-to-nearest-even (normal range only)."""
    if v == 0: return 0
    sign, v = int(v < 0), abs(v)
    e = v.numerator.bit_length() - v.denominator.bit_length()
    while Fraction(2) ** e > v: e -= 1
    while Fraction(2) ** (e + 1) <= v: e += 1
    n = round(v / Fraction(2) ** (e - 23))
    if n == 1 << 24: e, n = e + 1, 1 << 23
    return (sign << 31) | ((e + 127) << 23) | (n - (1 << 23))
def f32frac(bits): return Fraction(struct.unpack('>f', struct.pack('>I', bits))[0])

TESTS = []
def test(name, words, init, expect, funcs=(0,), mem=None, at=0, **kw):
    TESTS.append((name, words, at, init, expect, funcs, mem, kw))

test("loop with bdnz", [LI(3,0), LI(4,10), mtspr(9,4), x(3,3,4,266), d(14,4,4,-1), bc(16,0,-8), BLR],
     {}, {3: 55, 4: 0})
test("rotate/mask/rlwimi/Rc", [
        m(3,5,8,24,31), m(3,6,0,16,31), m(3,8,16,0,15,op=20), m(3,9,0,0,0,rc=1),
        x(10,0,0,19), m(3,11,0,28,3), BLR],
     {3: 0x12345678, 8: 0xFFFF},
     {5: 0x12, 6: 0x5678, 8: 0x5678FFFF, 9: 0, 10: 0x20000000, 11: 0x10000008})
test("carry chain", [LI(3,-1), d(12,4,3,1), mfspr(8,1), x(5,6,0,202), mfspr(9,1), BLR],
     {6: 7}, {4: 0, 8: 0x20000000, 5: 8, 9: 0})
test("signed vs unsigned compare", [
        d(11,0,3,5), bc(12,0,12), LI(4,2), b(8), LI(4,1),
        d(10,0,5,5), bc(12,0,12), LI(6,2), b(8), LI(6,1), BLR],
     {3: 0xFFFFFFFD, 5: 0xFFFFFFFD}, {4: 1, 6: 2})
test("stack frame + big-endian memory", [
        d(37,1,1,-16), d(36,3,1,12), d(32,4,1,12), d(34,5,1,12), d(40,6,1,14),
        d(42,7,1,14), d(32,8,1,0), d(14,1,1,16), BLR],
     {1: 0x80200000, 3: 0xAABBCCDD},
     {4: 0xAABBCCDD, 5: 0xAA, 6: 0xCCDD, 7: 0xFFFFCCDD, 8: 0x80200000, 1: 0x80200000},
     mem=(0x801FFFFC, [0xAA, 0xBB, 0xCC, 0xDD]))
test("div/shift/count", [
        x(5,3,4,491), x(6,3,4,459), x(3,7,1,824), mfspr(8,1), x(3,9,10,24),
        x(3,11,4,536), x(13,12,0,26), x(15,14,0,954), BLR],
     {3: 0xFFFFFFF9, 4: 2, 10: 40, 13: 0x10000, 15: 0x80},
     {5: 0xFFFFFFFD, 6: 0x7FFFFFFC, 7: 0xFFFFFFFC, 8: 0x20000000, 9: 0,
      11: 0x3FFFFFFE, 12: 15, 14: 0xFFFFFF80})
test("stmw/lmw/indexed/dcbz", [
        d(47,30,5,0), LI(30,0), LI(31,0), d(46,30,5,0), LI(6,8), x(30,5,6,151),
        x(9,5,6,23), x(0,0,5,1014), d(32,10,5,0), BLR],
     {5: 0x80300000, 30: 1, 31: 2}, {30: 1, 31: 2, 9: 1, 10: 0})
test("CR logic + mfcr", [d(11,0,3,5), xl(6,6,6,289), x(10,0,0,19), BLR],
     {3: 5}, {10: 0x22000000})
# two functions: bl, LR value, bctrl through the dispatch table
prog_a = [b(0x100, lk=1), d(14,3,3,1), mtspr(9,5), BCTRL, BLR]
prog_b = [mfspr(4,8), d(14,3,3,41), BLR]
test("calls: bl / bctrl / mflr", prog_a + [NOP] * (0x100 // 4 - len(prog_a)) + prog_b,
     {5: BASE + 0x100}, {3: 83, 4: BASE + 0x10}, funcs=(0, 0x100))


M = 0x80200000
test("lfs/fadds/stfs (single dup into ps1)", [d(48,1,3,0), d(48,2,3,4), fa(59,3,1,2,0,21), d(52,3,3,8), BLR],
     {3: M}, {}, mem=(M + 8, [0x40, 0x70, 0, 0]),
     meminit=[(M, struct.pack('>ff', 1.5, 2.25))],
     fpe={(3, 0): d2b(3.75), (3, 1): d2b(3.75), (1, 1): d2b(1.5)})
# The compiler's int -> float idiom: fsubs of 0x43300000_xxxxxxxx and 2^52. The operands are doubles, not single values; only the result is rounded
# to single. (Rounding the operands first gave 0 here, which made the game's viewport 0 x 0.)
test("fsubs on non-single operands (int to float idiom)", [d(50,1,3,0), d(50,2,3,8), fa(59,3,2,1,0,20), fa(59,4,2,1,0,21), BLR],
     {3: M}, {}, meminit=[(M, struct.pack('>QQ', 0x4330000000000000, 0x4330000000000280))],
     fpe={(3, 0): d2b(640.0), (4, 0): d2b(2.0**53)})          # fadds of the same pair: 2^53 + 640 rounds to 2^53 in single precision
test("double arithmetic, fma family, fneg/fabs/fmr", [
        d(50,1,3,0), d(50,2,3,8), fa(63,3,1,2,0,20), fa(63,4,1,0,2,25), fa(63,5,1,2,0,18),
        fa(63,6,1,1,2,29), fx(63,7,0,1,40), fx(63,8,0,7,264), fx(63,9,0,2,72),
        d(54,4,3,16), fa(63,10,1,2,2,30), BLR],
     {3: M}, {}, mem=(M + 16, list(struct.pack('>d', 40.0))),
     meminit=[(M, struct.pack('>dd', 10.0, 4.0))],
     fpe={(3,0): d2b(6.0), (4,0): d2b(40.0), (5,0): d2b(2.5), (6,0): d2b(50.0), (7,0): d2b(-10.0),
          (8,0): d2b(10.0), (9,0): d2b(4.0), (10,0): d2b(-36.0)})
test("fcmpu + fsel + CR fields", [
        fx(63,0,1,2,0), x(10,0,0,19), fa(63,15,11,13,12,23), fa(63,16,14,13,12,23),
        fx(63,4,2,1,0), x(11,0,0,19), BLR],
     {}, {10: 0x40000000, 11: 0x48000000},
     fpi={1: (d2b(10.0), 0), 2: (d2b(4.0), 0), 11: (d2b(-1.0), 0), 12: (d2b(7.0), 0),
          13: (d2b(9.0), 0), 14: (d2b(0.0), 0)},
     fpe={(15,0): d2b(9.0), (16,0): d2b(7.0)})
test("fctiw/fctiwz, rounding mode via FPSCR, mffs, stfiwx", [
        fx(63,2,0,1,15), fx(63,3,0,1,14), (63<<26)|(31<<21)|(38<<1), fx(63,4,0,1,14),
        x(4,0,3,983), d(32,5,3,0), fx(63,5,0,0,583), fx(63,7,0,6,15), (63<<26)|(31<<21)|(70<<1), BLR],
     {3: M}, {5: 2},
     fpi={1: (d2b(2.7), 0), 6: (d2b(3e9), 0)},
     fpe={(2,0): 0xFFF8000000000002, (3,0): 0xFFF8000000000003, (4,0): 0xFFF8000000000002,
          (5,0): 0xFFF8000000000001, (7,0): 0xFFF800007FFFFFFF})
test("psq_l/psq_st quantization + paired ops", [
        psq(56,1,3,0,1,0), fa(4,2,1,1,0,21), psq(60,2,3,0,1,16), psq(56,3,3,1,1,0), psq(56,4,3,0,0,32),
        fx(4,5,4,4,592), fa(4,7,4,4,4,29), fa(4,8,4,4,1,10), fx(4,9,0,4,40), BLR],
     {3: M}, {}, mem=(M + 16, [0x02, 0x00, 0xFE, 0x00]),
     spr={913: 0x08070807},
     meminit=[(M, struct.pack('>hh', 256, -256)), (M + 32, struct.pack('>ff', 3.0, 5.0))],
     fpe={(1,0): d2b(1.0), (1,1): d2b(-1.0), (2,0): d2b(2.0), (2,1): d2b(-2.0),
          (3,0): d2b(1.0), (3,1): d2b(1.0), (4,0): d2b(3.0), (4,1): d2b(5.0),
          (5,0): d2b(5.0), (5,1): d2b(3.0), (7,0): d2b(12.0), (7,1): d2b(30.0),
          (8,0): d2b(8.0), (8,1): d2b(-1.0), (9,0): d2b(-3.0), (9,1): d2b(-5.0)})
# fmadds hardware mismatch from Dolphin issue #13865: hardware = 0xBF55BF17, 64-bit FMA + round gives 0xBF55BF18
_fa, _fc, _fb = 0x42480000, 0xBC88CC38, 0x1B1C72A0
_ref = round_f32(f32frac(_fa) * f32frac(_fc) + f32frac(_fb))
assert _ref == 0xBF55BF17, "reference model disagrees with reported hardware result: %08X" % _ref
test("fmadds matches hardware (Dolphin #13865)", [fa(59,4,1,3,2,29), BLR], {}, {},
     fpi={1: (fb2db(_fa), 0), 2: (fb2db(_fc), 0), 3: (fb2db(_fb), 0)},
     fpe={(4,0): fb2db(_ref), (4,1): fb2db(_ref)})


# switch via jump table; table address 0x80308010 forces lis/addi sign handling; two cases share a target
TBL = (0x80308010, [BASE + 0x20, BASE + 0x28, BASE + 0x30, BASE + 0x20])
SW = [d(10,0,3,3), bc(12,1,0x34), d(15,4,0,0x8031), d(14,4,4,-0x7FF0), m(3,0,2,0,29), x(0,4,0,23),
      mtspr(9,0), 0x4E800420,
      LI(5,10), BLR, LI(5,20), BLR, LI(5,30), BLR, LI(5,-1), BLR]
for idx, want in ((0, 10), (1, 20), (2, 30), (3, 10), (9, 0xFFFFFFFF)):
    test("jump table switch, index %d" % idx, SW, {3: idx}, {5: want}, tbl=TBL)

def run(t):
    name, words, at, init, expect, funcs, mem, kw = t
    tbl = kw.get("tbl")
    data = [(tbl[0], b"".join(struct.pack(">I", v) for v in tbl[1]))] if tbl else []
    img = lifter.Image([(BASE, words)], data)
    jt, _ = lifter.find_jump_tables(img)
    if tbl and not jt:
        return "jump table was not recognised"
    edges = [(pc, t) for pc, ts in jt.items() for t in ts]
    starts = lifter.plan_functions(img, [BASE + f for f in funcs], edges)
    fnset, un, st = set(starts), lifter.Counter(), lifter.Counter()
    bodies = [lifter.lift_function(img, s, e, fnset, un, st, jt) for s, e in lifter.function_ranges(img, starts)]
    if tbl and not st["jump_tables"]:
        return "jump table was recognised but not emitted"
    if un:
        return "unimplemented: %s" % dict(un)
    init_c = "".join("  c->r[%d] = 0x%Xu;\n" % (r, v) for r, v in init.items())
    for r, (p0, p1) in kw.get("fpi", {}).items():
        init_c += "  c->ps[%d][0] = rt_u2d(0x%Xull); c->ps[%d][1] = rt_u2d(0x%Xull);\n" % (r, p0, r, p1)
    for n, v in kw.get("spr", {}).items():
        init_c += "  c->spr[%d] = 0x%Xu;\n" % (n, v)
    meminit = list(kw.get("meminit", []))
    if tbl:
        meminit.append((tbl[0], b"".join(struct.pack(">I", v) for v in tbl[1])))
    for a, bs in meminit:
        for i, byte in enumerate(bs):
            init_c += "  c->mem1[0x%X] = %d;\n" % ((a & 0x1FFFFFFF) + i, byte)
    memc = ""
    if mem:
        a, bs = mem
        memc = "".join('  printf("m %d %%u\\n", c->mem1[0x%X]);\n' % (i, (a & 0x1FFFFFFF) + i) for i in range(len(bs)))
    for (fr, lane) in kw.get("fpe", {}):
        memc += '  printf("f %d %d %%llx\\n", (unsigned long long)rt_d2u(c->ps[%d][%d]));\n' % (fr, lane, fr, lane)
    src = (lifter.emit_funcs_h(starts).replace('#include "rt.h"\n', '#include "rt.h"\n#include <stdio.h>\n#include <stdlib.h>\n')
           + "\n\n".join(bodies) + "\n" + lifter.emit_dispatch(starts).split('#include "funcs.h"\n')[1]
           + "int main(void) {\n  Ctx *c = calloc(1, sizeof *c);\n  c->mem1 = calloc(1, 0x1800000);\n  c->mem2 = calloc(1, 0x4000000);\n"
           + init_c + "  func_%08X(c);\n" % (BASE + at)
           + '  for (int i = 0; i < 32; i++) printf("r %d %u\\n", i, c->r[i]);\n' + memc + "  return 0;\n}\n")
    with tempfile.TemporaryDirectory() as td:
        cf, exe = os.path.join(td, "t.c"), os.path.join(td, "t")
        open(cf, "w").write(src)
        cp = subprocess.run(["gcc", "-O1", "-Wall", "-Werror", "-ffp-contract=off", "-frounding-math", "-I", os.path.join(ROOT, "runtime"), cf,
                             *[os.path.join(ROOT, "runtime", f) for f in ("rt.c", "rt_mmio.c", "rt_irq.c", "rt_thread.c", "rt_ios.c", "rt_hle.c", "rt_gx.c", "rt_gxr.c", "rt_gxr_soft.c", "rt_gxr_tex.c")], "-o", exe, "-lm", "-lpthread"], capture_output=True, text=True)
        if cp.returncode:
            return "compile error:\n" + cp.stderr[:1500]
        out = subprocess.run([exe], capture_output=True, text=True)
        if out.returncode:
            return "runtime error: " + out.stderr.strip()
    regs, mm, fp = {}, {}, {}
    for line in out.stdout.split("\n"):
        p = line.split()
        if p and p[0] == "r": regs[int(p[1])] = int(p[2])
        if p and p[0] == "m": mm[int(p[1])] = int(p[2])
        if p and p[0] == "f": fp[(int(p[1]), int(p[2]))] = int(p[3], 16)
    for r, v in expect.items():
        if regs.get(r) != v:
            return "r%d = 0x%X, expected 0x%X" % (r, regs.get(r, -1), v)
    for k, v in kw.get("fpe", {}).items():
        if fp.get(k) != v:
            return "f%d.ps%d = 0x%016X, expected 0x%016X" % (k[0], k[1], fp.get(k, -1), v)
    if mem and [mm.get(i) for i in range(len(mem[1]))] != mem[1]:
        return "guest memory bytes %s, expected %s" % ([mm.get(i) for i in range(len(mem[1]))], mem[1])
    return None


if __name__ == "__main__":
    fails = 0
    for t in TESTS:
        err = run(t)
        print(("PASS  " if err is None else "FAIL  ") + t[0] + ("" if err is None else "\n      " + err))
        fails += err is not None
    sys.exit(1 if fails else 0)
