/* Renderer test: feeds a hand-made GX command stream through the command processor into the software backend and checks pixels.
 * (1) a Gouraud triangle with TEV = rasterized colour; (2) a textured quad from an RGBA8 texture in guest memory; (3) EFB copy to the display;
 * (4) texture decoders against hand-made tiles; (5) an EFB copy to a texture round trip. The expected values are computed here from the
 * register layouts I remember, so this checks the implementation against that understanding, not against hardware. */
#include "rt_gxr.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const rt_func_entry rt_func_table[] = { {0x80100000u, 0} };
const uint32_t rt_func_count = 0;
void rt_gx_fifo_write(Ctx *c, uint64_t v, int size);

static Ctx *C; static int fails;
#define CHECK(cond, ...) do { if (!(cond)) { fails++; printf("FAIL  "); printf(__VA_ARGS__); printf("\n"); } } while (0)
static uint8_t *frame; static int fw, fh, nframes;
void gxr_frame_sink(const uint8_t *rgba, int w, int h) { free(frame); frame = malloc((size_t)w * h * 4); memcpy(frame, rgba, (size_t)w * h * 4); fw = w; fh = h; nframes++; }

static void b8(int v) { rt_gx_fifo_write(C, (uint64_t)(v & 255), 1); }
static void w32(uint32_t v) { b8((int)(v >> 24)); b8((int)(v >> 16)); b8((int)(v >> 8)); b8((int)v); }
static void f32(float f) { uint32_t u; memcpy(&u, &f, 4); w32(u); }
static void cp(int reg, uint32_t v) { b8(0x08); b8(reg); w32(v); }
static void bp(int reg, uint32_t v) { b8(0x61); w32((uint32_t)reg << 24 | (v & 0xFFFFFF)); }
static void xf(uint32_t addr, int n, const float *f) { b8(0x10); w32((uint32_t)(n - 1) << 16 | addr); for (int i = 0; i < n; i++) f32(f[i]); }
static void xfu(uint32_t addr, uint32_t v) { b8(0x10); w32(addr); w32(v); }
static const uint8_t *px(int x, int y) { return gxr_soft_efb() + ((size_t)y * GXR_EFB_W + x) * 4; }

static void common_state(void) {
    float ident[12] = { 1,0,0,0, 0,1,0,0, 0,0,1,0 };
    xf(0, 12, ident); xf(60 * 4, 12, ident);                                       /* position matrix 0 and the identity texture matrix 60 */
    float proj[6] = { 2.f / 640, -1.f, -2.f / 480, 1.f, 0.f, -0.5f };            /* orthographic: pixel coordinates -> ndc, z = -0.5 */
    xf(0x1020, 6, proj); xfu(0x1026, 1);
    float vp[6] = { 320, -240, 16777216.f, 320 + 342, 240 + 342, 16777216.f };
    xf(0x101A, 6, vp);
    xfu(0x1009, 1); xfu(0x100E, 1); xfu(0x1010, 1);                                /* one colour channel, material from the vertex */
    bp(0x40, 0); bp(0x41, 0x18); bp(0xF3, 0x3F0000);                              /* no z test, colour+alpha update, alpha test always */
    bp(0x20, 342 << 12 | 342); bp(0x21, (342 + 639) << 12 | (342 + 527)); bp(0x59, 171 | 171 << 10);
    cp(0x30, 60 << 6);                                                            /* tex0 matrix index = 60 (identity) */
    for (int i = 0; i < 8; i++) { bp(0xE0 + 2 * i, 0); }
    static const uint32_t swp[8] = { 4, 14, 0, 12, 5, 13, 10, 14 };                 /* the SDK's default swap tables: RGBA, RRRA, GGGA, BBBA */
    for (int i = 0; i < 8; i++) bp(0xF6 + i, swp[i]);
}

int main(void) {
    C = calloc(1, sizeof *C); C->mem1 = calloc(1, 0x1800000); C->mem2 = calloc(1, 0x4000000); C->lc = calloc(1, 0x4000);
    gxr_set_backend(&gxr_soft_backend);
    common_state();

    /* (1) colour triangle: TEV stage 0 = RASC / RASA */
    cp(0x50, 1 << 9 | 1 << 13); cp(0x60, 0);
    cp(0x70, 1 | 4 << 1 | 1 << 13 | 5 << 14);                                      /* xyz float, colour0 rgba8888 */
    bp(0x00, 1 << 4);                                                             /* 0 texgens, 1 colour channel, 1 stage, no culling */
    bp(0x28, 7 << 7);                                                             /* stage 0: no texture, colour channel 0... */
    bp(0x28, 0);
    bp(0xC0, 10 | 15 << 4 | 15 << 8 | 15 << 12 | 1 << 19);                        /* d = RASC, others zero, clamp */
    bp(0xC1, 5 << 4 | 7 << 7 | 7 << 10 | 7 << 13 | 1 << 19);                      /* alpha d = RASA */
    bp(0x4F, 0); bp(0x50, 0); bp(0x51, 0xFFFFFF);
    b8(0x90); b8(0); b8(3);
    float v[3][2] = { { 100, 100 }, { 300, 100 }, { 100, 300 } }; uint8_t col[3][4] = { { 255, 0, 0, 255 }, { 0, 255, 0, 255 }, { 0, 0, 255, 255 } };
    for (int i = 0; i < 3; i++) { f32(v[i][0]); f32(v[i][1]); f32(0); for (int k = 0; k < 4; k++) b8(col[i][k]); }
    {
        int sx = 150, sy = 150; double lb = (sx + 0.5 - 100) / 200, lc = (sy + 0.5 - 100) / 200, la = 1 - lb - lc;
        const uint8_t *p = px(sx, sy);
        CHECK(abs(p[0] - (int)lrint(la * 255)) <= 2 && abs(p[1] - (int)lrint(lb * 255)) <= 2 && abs(p[2] - (int)lrint(lc * 255)) <= 2 && p[3] == 255,
              "triangle colour at (150,150): got %d %d %d %d, expected %.0f %.0f %.0f 255", p[0], p[1], p[2], p[3], la * 255, lb * 255, lc * 255);
        const uint8_t *o = px(310, 310); CHECK(o[0] == 0 && o[1] == 0 && o[2] == 0 && o[3] == 0, "outside the triangle stays clear (%d %d %d %d)", o[0], o[1], o[2], o[3]);
        const uint8_t *q = px(250, 250); CHECK(q[0] == 0 && q[1] == 0 && q[2] == 0, "beyond the hypotenuse stays clear");
    }

    /* (2) textured quad: 4x4 RGBA8 texture at physical 0x200000, texel (x,y) = (x*60, y*60, 128, 255) */
    uint8_t *tex = rt_ptr(C, 0x80200000u);
    for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) { int i = (y * 4 + x) * 2; tex[i] = 255; tex[i + 1] = (uint8_t)(x * 60); tex[32 + i] = (uint8_t)(y * 60); tex[32 + i + 1] = 128; }
    bp(0x88, 3 | 3 << 10 | 6 << 20); bp(0x94, 0x200000 >> 5); bp(0x80, 0);        /* 4x4 RGBA8, clamp, nearest */
    bp(0x30, 3); bp(0x31, 3);                                                     /* coordinate scale = texture size */
    xfu(0x103F, 1); xfu(0x1040, 0 | 0 << 1 | 0 << 4 | 5 << 7);                    /* one texgen: regular, source = tex0, 2x4 */
    xfu(0x1009, 0);                                                               /* no colour channels needed */
    bp(0x00, 1);                                                                  /* 1 texgen, 0 colour channels, 1 stage */
    bp(0x28, 0 | 0 << 3 | 1 << 6 | 7 << 7);                                       /* stage 0: texmap 0, coord 0, texture on, no colour channel */
    bp(0xC0, 8 | 15 << 4 | 15 << 8 | 15 << 12 | 1 << 19);                         /* d = TEXC */
    bp(0xC1, 4 << 4 | 7 << 7 | 7 << 10 | 7 << 13 | 1 << 19);                      /* alpha d = TEXA */
    cp(0x50, 1 << 9); cp(0x60, 1); cp(0x70, 1 | 4 << 1 | 1 << 21 | 4 << 22);       /* position direct; tex0 direct, st float */
    b8(0x80); b8(0); b8(4);                                                       /* quad */
    float qd[4][4] = { { 200, 200, 0, 0 }, { 264, 200, 1, 0 }, { 264, 264, 1, 1 }, { 200, 264, 0, 1 } };
    for (int i = 0; i < 4; i++) { f32(qd[i][0]); f32(qd[i][1]); f32(0); f32(qd[i][2]); f32(qd[i][3]); }
    {
        const uint8_t *p = px(224, 240);                                          /* texel (1, 2) */
        CHECK(p[0] == 60 && p[1] == 120 && p[2] == 128 && p[3] == 255, "textured quad, texel (1,2): got %d %d %d %d, expected 60 120 128 255", p[0], p[1], p[2], p[3]);
        p = px(201, 201); CHECK(p[0] == 0 && p[1] == 0 && p[2] == 128, "textured quad, texel (0,0): got %d %d %d", p[0], p[1], p[2]);
        p = px(263, 263); CHECK(p[0] == 180 && p[1] == 180, "textured quad, texel (3,3): got %d %d", p[0], p[1]);
    }

    /* (3) EFB copy to the display */
    bp(0x49, 0); bp(0x4A, 639 | 479 << 10); bp(0x4E, 256); bp(0x52, 1 << 14);
    CHECK(nframes == 1 && fw == 640 && fh == 480, "display copy produced a frame (n=%d %dx%d)", nframes, fw, fh);
    CHECK(frame && frame[(240 * 640 + 224) * 4] == 60, "frame holds the quad");

    /* (5) EFB -> texture round trips (copy region 200..263 x 200..263 as RGBA8 / RGB565) then decode */
    for (int fmt = 6; fmt >= 4; fmt--) {
        bp(0x49, 200 | 200 << 10); bp(0x4A, 63 | 63 << 10); bp(0x4B, 0x300000 >> 5); bp(0x4D, 64 / (fmt == 6 ? 4 : 4) * (fmt == 6 ? 64 : 32) / 32);
        bp(0x52, (uint32_t)((fmt & 7) << 4 | (fmt >> 3) << 3));
        uint8_t *dec = malloc(64 * 64 * 4); gxr_tex_decode(C, 0x300000, fmt, 64, 64, 0, 0, dec);
        const uint8_t *src = px(224, 240), *d = dec + (40 * 64 + 24) * 4; int tol = fmt == 6 ? 0 : fmt == 5 ? 9 : 4;
        CHECK(abs(d[0] - src[0]) <= tol && abs(d[1] - src[1]) <= tol && abs(d[2] - src[2]) <= tol, "EFB->texture round trip, format %d: got %d %d %d, expected %d %d %d", fmt, d[0], d[1], d[2], src[0], src[1], src[2]);
        free(dec);
    }

    /* (4) decoders: RGB5A3 (both forms), IA8, I4, C8 through a palette, CMPR */
    uint8_t *m = rt_ptr(C, 0x80400000u);
    memset(m, 0, 64); m[0] = 0x80 | 0x7C; m[1] = 0x00;                            /* RGB5A3 opaque: r=31 */
    m[2] = 0x70 | 0x0F; m[3] = 0x00;                                              /* alpha 7 (opaque), r=15 g=0 b=0 */
    { uint8_t t[16 * 4]; gxr_tex_decode(C, 0x400000, 5, 4, 4, 0, 0, t); CHECK(t[0] == 255 && t[1] == 0 && t[3] == 255 && t[4] == 255 && t[7] == 255, "RGB5A3 decode (%d %d %d %d | %d %d %d %d)", t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7]); }
    memset(m, 0, 64); m[0] = 0x80; m[1] = 0x40;                                   /* IA8: alpha 0x80 intensity 0x40 */
    { uint8_t t[16 * 4]; gxr_tex_decode(C, 0x400000, 3, 4, 4, 0, 0, t); CHECK(t[0] == 0x40 && t[3] == 0x80, "IA8 decode"); }
    memset(m, 0, 64); m[0] = 0xF1;                                                /* I4: first pixel 15, second 1 */
    { uint8_t t[64 * 4]; gxr_tex_decode(C, 0x400000, 0, 8, 8, 0, 0, t); CHECK(t[0] == 255 && t[4] == 17, "I4 decode"); }
    { uint8_t pal[4] = { 0xF8, 0x00, 0x07, 0xE0 };                               /* palette entries: RGB565 red, green */
      memcpy(rt_ptr(C, 0x80500000u), pal, 4); gxr_tlut_load(C, 0x500000, 0, 2);
      memset(m, 0, 64); m[0] = 0; m[1] = 1; uint8_t t[32 * 4]; gxr_tex_decode(C, 0x400000, 9, 8, 4, 0, 1, t);
      CHECK(t[0] == 255 && t[1] == 0 && t[4] == 0 && t[5] == 255, "C8 through a RGB565 palette (%d %d | %d %d)", t[0], t[1], t[4], t[5]); }
    memset(m, 0, 64); m[0] = 0xF8; m[1] = 0x00; m[2] = 0x07; m[3] = 0xE0; m[4] = 0x1B;  /* CMPR sub-block 0: c0 red, c1 green, row 0 indices 0,1,2,3 */
    { uint8_t t[64 * 4]; gxr_tex_decode(C, 0x400000, 14, 8, 8, 0, 0, t);
      CHECK(t[0] == 255 && t[1] == 0 && t[4] == 0 && t[5] == 255 && t[8] == 170 && t[9] == 85 && t[12] == 85 && t[13] == 170, "CMPR decode (%d,%d %d,%d %d,%d %d,%d)", t[0], t[1], t[4], t[5], t[8], t[9], t[12], t[13]); }

    printf("%s  GX renderer: triangle, textured quad, display copy, texture round trips, decoders\n", fails ? "FAIL" : "PASS");
    return fails != 0;
}
