/* Renderer cross-check: feeds the same hand-made GX command streams to the software rasterizer and to the OpenGL ES backend and compares the two EFBs.
 * Needs EGL + OpenGL ES 3 (on a PC: Mesa; RT_GL_HEADLESS=1 selects its surfaceless platform). Without them the test says SKIP and passes.
 * Scenes: depth test, alpha blending + alpha test, perspective-correct texturing with repeat/mirror wrap and bilinear filtering, face culling, scissor +
 * clear rectangles, and a TEV with constant colours and a register. The software backend is the reference; the two may differ by rounding (1-2 levels)
 * and by a few edge pixels (rasterization rules), nothing more. */
#include "rt_gxr.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const rt_func_entry rt_func_table[] = { {0x80100000u, 0} };
const uint32_t rt_func_count = 0;
void rt_gx_fifo_write(Ctx *c, uint64_t v, int size);

static Ctx *C; static int fails;
#define CHECK(cond, ...) do { if (!(cond)) { fails++; printf("FAIL  "); printf(__VA_ARGS__); printf("\n"); } } while (0)
void gxr_frame_sink(const uint8_t *rgba, int w, int h) { (void)rgba; (void)w; (void)h; }

static void b8(int v) { rt_gx_fifo_write(C, (uint64_t)(v & 255), 1); }
static void w32(uint32_t v) { b8((int)(v >> 24)); b8((int)(v >> 16)); b8((int)(v >> 8)); b8((int)v); }
static void f32(float f) { uint32_t u; memcpy(&u, &f, 4); w32(u); }
static void cp(int reg, uint32_t v) { b8(0x08); b8(reg); w32(v); }
static void bp(int reg, uint32_t v) { b8(0x61); w32((uint32_t)reg << 24 | (v & 0xFFFFFF)); }
static void xf(uint32_t addr, int n, const float *f) { b8(0x10); w32((uint32_t)(n - 1) << 16 | addr); for (int i = 0; i < n; i++) f32(f[i]); }
static void xfu(uint32_t addr, uint32_t v) { b8(0x10); w32(addr); w32(v); }

static void base_state(int perspective) {
    float ident[12] = { 1,0,0,0, 0,1,0,0, 0,0,1,0 };
    xf(0, 12, ident); xf(60 * 4, 12, ident);
    if (perspective) {                                                             /* x,y in view units, z negative in front of the eye; near 1, far 100 */
        float n = 1, f = 100, proj[6] = { 1.f, 0.f, 1.333f, 0.f, -n / (f - n), -f * n / (f - n) };
        xf(0x1020, 6, proj); xfu(0x1026, 0);
    } else {
        float proj[6] = { 2.f / 640, -1.f, -2.f / 480, 1.f, 0.f, -0.5f };         /* orthographic: pixel coordinates, z = -0.5 + z * 0 */
        xf(0x1020, 6, proj); xfu(0x1026, 1);
    }
    float vp[6] = { 320, -240, 16777216.f, 320 + 342, 240 + 342, 16777216.f };
    xf(0x101A, 6, vp);
    xfu(0x1009, 1); xfu(0x100E, 1); xfu(0x1010, 1);
    bp(0x40, 0); bp(0x41, 0x18); bp(0xF3, 0x3F0000);
    bp(0x20, 342 << 12 | 342); bp(0x21, (342 + 639) << 12 | (342 + 527)); bp(0x59, 171 | 171 << 10);
    cp(0x30, 60 << 6);
    for (int i = 0; i < 8; i++) bp(0xE0 + 2 * i, 0);
    static const uint32_t swp[8] = { 4, 14, 0, 12, 5, 13, 10, 14 };
    for (int i = 0; i < 8; i++) bp(0xF6 + i, swp[i]);
    bp(0x4F, 0); bp(0x50, 0); bp(0x51, 0xFFFFFF);
}
/* vertex format: position float xyz, colour0 rgba8888, tex0 float st */
static void fmt_color(void) { cp(0x50, 1 << 9 | 1 << 13); cp(0x60, 0); cp(0x70, 1 | 4 << 1 | 1 << 13 | 5 << 14); }
static void fmt_tex(void) { cp(0x50, 1 << 9); cp(0x60, 1); cp(0x70, 1 | 4 << 1 | 1 << 21 | 4 << 22); }   /* position + tex0 (float st), no colour */
static void stage_ras(void) {                                                      /* TEV: out = RASC, alpha = RASA */
    bp(0x00, 1 << 4); bp(0x28, 7 << 7); bp(0x28, 0); xfu(0x103F, 0);
    bp(0xC0, 10 | 15 << 4 | 15 << 8 | 15 << 12 | 1 << 19); bp(0xC1, 5 << 4 | 7 << 7 | 7 << 10 | 7 << 13 | 1 << 19);
}
static void tri(const float p[3][3], const uint8_t col[3][4]) {
    b8(0x90); b8(0); b8(3);
    for (int i = 0; i < 3; i++) { f32(p[i][0]); f32(p[i][1]); f32(p[i][2]); for (int k = 0; k < 4; k++) b8(col[i][k]); }
}
static void flat_tri(float x0, float y0, float x1, float y1, float x2, float y2, float z, uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    const float ox = 0.37f, oy = 0.21f;                                            /* keep edges off the exact pixel centres: the two rasterizers treat ties differently */
    float p[3][3] = { { x0 + ox, y0 + oy, z }, { x1 + ox, y1 + oy, z }, { x2 + ox, y2 + oy, z } }; uint8_t c[3][4] = { { r, g, b, a }, { r, g, b, a }, { r, g, b, a } }; tri(p, c);
}
static void quad_flat(float x0, float y0, float x1, float y1, float z, uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    b8(0x80); b8(0); b8(4);
    float q[4][2] = { { x0, y0 }, { x1, y0 }, { x1, y1 }, { x0, y1 } };
    for (int i = 0; i < 4; i++) { f32(q[i][0]); f32(q[i][1]); f32(z); b8(r); b8(g); b8(b); b8(a); }
}

typedef void (*Scene)(void);
static uint8_t efb_soft[GXR_EFB_W * GXR_EFB_H * 4], efb_gl[GXR_EFB_W * GXR_EFB_H * 4];

/* ---- scenes */
static void scene_depth(void) {                                                    /* overlapping triangles, far one drawn last: LEQUAL must hide it where it is behind */
    base_state(0); fmt_color(); stage_ras();
    bp(0x40, 1 | 3 << 1 | 1 << 4);                                                 /* z test on, LEQUAL, update */
    float proj[6] = { 2.f / 640, -1.f, -2.f / 480, 1.f, -0.5f, -0.5f }; xf(0x1020, 6, proj); xfu(0x1026, 1);   /* z_ndc = -0.5 z - 0.5: window depth = 1 + z_ndc */
    flat_tri(120, 200, 520, 200, 320, 460, 0.6f, 0, 0, 255, 255);                  /* depth 0.2 (nearest) */
    flat_tri(150, 120, 450, 120, 150, 420, 0.0f, 0, 255, 0, 255);                  /* depth 0.5 */
    flat_tri(100, 100, 400, 100, 100, 400, -0.2f, 255, 0, 0, 255);                 /* depth 0.6 (farthest, drawn last) */
    bp(0x40, 1 | 4 << 1 | 0 << 4);                                                 /* GREATER, no update: only draws where something is nearer than... the buffer value */
    flat_tri(500, 60, 620, 60, 500, 180, 0.0f, 255, 255, 0, 255);                  /* the cleared depth is 1.0: depth 0.5 is not greater -> hidden */
}
static void scene_blend(void) {
    base_state(0); fmt_color(); stage_ras();
    quad_flat(50, 50, 600, 430, 0, 40, 90, 200, 255);                              /* opaque background */
    bp(0x41, 1 | 0x18 | 4 << 8 | 5 << 5);                                          /* blend: src alpha, inv src alpha */
    quad_flat(100, 100, 300, 300, 0, 255, 200, 0, 128);
    bp(0x41, 1 | 0x18 | 1 << 8 | 1 << 5);                                          /* additive */
    quad_flat(200, 200, 400, 400, 0, 60, 30, 10, 255);
    bp(0x41, 1 | 0x18 | 1 << 11 | 1 << 8 | 1 << 5);                                /* reverse subtract: dst - src */
    quad_flat(350, 120, 550, 300, 0, 30, 30, 30, 255);
    bp(0x41, 0x18);
    bp(0xF3, (4 << 16) | 200 | (7 << 19) | (0 << 22));                              /* a > 200 AND always */
    quad_flat(60, 380, 160, 460, 0, 255, 255, 255, 100);                           /* rejected */
    quad_flat(180, 380, 280, 460, 0, 255, 255, 255, 220);                          /* drawn */
}
static void scene_cull(void) {
    base_state(0); fmt_color(); stage_ras();
    bp(0x00, 1 << 4 | 1 << 14);                                                    /* cull mode 1 */
    flat_tri(50, 50, 250, 50, 50, 250, 0, 255, 0, 0, 255);                         /* one winding */
    flat_tri(300, 50, 300, 250, 500, 50, 0, 0, 255, 0, 255);                       /* the other winding */
    bp(0x00, 1 << 4 | 2 << 14);                                                    /* cull mode 2 */
    flat_tri(50, 280, 250, 280, 50, 460, 0, 255, 0, 255, 255);
    flat_tri(300, 280, 300, 460, 500, 280, 0, 0, 255, 255, 255);
    bp(0x00, 1 << 4 | 3 << 14);                                                    /* cull all */
    flat_tri(520, 100, 620, 100, 520, 200, 0, 255, 255, 255, 255);
}
static void scene_scissor(void) {
    base_state(0); fmt_color(); stage_ras();
    quad_flat(0, 0, 640, 480, 0, 20, 20, 20, 255);
    bp(0x20, (342 + 100) << 12 | (342 + 80)); bp(0x21, (342 + 299) << 12 | (342 + 219));
    quad_flat(0, 0, 640, 480, 0, 200, 60, 60, 255);                                // clipped to the scissor rectangle 100,80 .. 299,219
    bp(0x20, 342 << 12 | 342); bp(0x21, (342 + 639) << 12 | (342 + 527));
    bp(0x4F, 255 << 8 | 10); bp(0x50, 40 << 8 | 90);                               /* clear colour: r 10, a 255, g 40, b 90 */
    bp(0x49, 400 | 300 << 10); bp(0x4A, 119 | 79 << 10); bp(0x4E, 256);
    bp(0x52, 1 << 11 | 1 << 14);                                                   /* copy to the display with clear: clears 400,300 .. 519,379 only */
    quad_flat(380, 280, 420, 320, 0, 250, 250, 0, 255);                            // drawn after the clear
}
static uint8_t *tex_mem;
static void scene_texture(void) {
    base_state(1); fmt_tex();
    /* 8x8 RGBA8 texture at 0x200000: a gradient + a bright diagonal so wrap / filtering are visible */
    tex_mem = rt_ptr(C, 0x80200000u);
    for (int by = 0; by < 2; by++) for (int bx = 0; bx < 2; bx++) {
        uint8_t *blk = tex_mem + (by * 2 + bx) * 64;
        for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) {
            int X = bx * 4 + x, Y = by * 4 + y, i = (y * 4 + x) * 2; uint8_t r = (uint8_t)(X * 36), g = (uint8_t)(Y * 36), b = X == Y ? 255 : 40, a = 255;
            blk[i] = a; blk[i + 1] = r; blk[32 + i] = g; blk[32 + i + 1] = b;
        }
    }
    bp(0x00, 1);
    bp(0x28, 0 | 0 << 3 | 1 << 6 | 7 << 7);
    bp(0xC0, 8 | 15 << 4 | 15 << 8 | 15 << 12 | 1 << 19); bp(0xC1, 4 << 4 | 7 << 7 | 7 << 10 | 7 << 13 | 1 << 19);
    xfu(0x1009, 0); xfu(0x103F, 1); xfu(0x1040, 0 | 0 << 1 | 0 << 4 | 5 << 7);
    bp(0x94, 0x200000 >> 5);
    bp(0x30, 7); bp(0x31, 7);
    for (int mode = 0; mode < 4; mode++) {
        int wrap = mode & 1 ? 1 : 2, lin = mode >> 1;                              /* repeat or mirror; nearest or bilinear */
        bp(0x88, 7 | 7 << 10 | 6 << 20); bp(0x80, wrap | wrap << 2 | lin << 4);
        float x0 = -2.2f + mode * 1.1f, y0 = mode & 1 ? 0.2f : -1.9f, sz = 1.0f;   /* receding quad: z from -3 (near edge) to -6 */
        b8(0x80); b8(0); b8(4);
        float q[4][5] = { { x0, y0, -3, 0, 0 }, { x0 + sz, y0, -4, 3, 0 }, { x0 + sz, y0 + 1.6f, -6, 3, 3 }, { x0, y0 + 1.6f, -4, 0, 3 } };
        for (int i = 0; i < 4; i++) for (int k = 0; k < 5; k++) f32(q[i][k]);
    }
}
static void scene_tev(void) {                                                       /* stage 0: C0*(1-K0rgb) + RAS*K0rgb, alpha K0a; stage 1: prev * 2 */
    base_state(0); fmt_color();
    bp(0x00, 1 << 4 | 1 << 10);                                                    /* 1 colour channel, 2 stages */
    bp(0x28, 0); xfu(0x103F, 0);                                                   /* stage 0: colour channel 0; stage 1 (high half): channel 0 too */
    bp(0xE2, 60 | 255 << 12); bp(0xE3, 90 | 30 << 12);                             /* C0 = (r 60, g 30, b 90, a 255) */
    bp(0xE0, 1 << 23 | 200 | 100 << 12); bp(0xE1, 1 << 23 | 50 | 150 << 12);       /* K0 = (r 200, g 150, b 50, a 100) */
    bp(0xF6, 4 | 12 << 4 | 28 << 9); bp(0xF7, 14);                                 /* stage 0: konst colour = K0 rgb (12), konst alpha = K0 A (28); swap table 0 = RGBA */
    bp(0xC0, 14 | 12 << 4 | 10 << 8 | 2 << 12 | 1 << 19);                          /* d = 14 (konst)... see below: a=C0 b=RASC c=KONST d=ZERO */
    bp(0xC0, 15 | 14 << 4 | 10 << 8 | 2 << 12 | 1 << 19);                          /* a = C0 (2), b = RASC (10), c = KONST (14), d = ZERO (15) */
    bp(0xC1, 7 << 4 | 6 << 7 | 7 << 10 | 7 << 13 | 1 << 19);                       /* alpha: d = ZERO + (a*(1-c) + b*c), c = KONST (6) with b = ZERO, a = ZERO -> 0 .. rewritten next */
    bp(0xC1, 7 << 4 | 6 << 7 | 5 << 10 | 7 << 13 | 1 << 19);                       /* alpha: b = RASA (5), c = KONST (6) */
    bp(0xC2, 0 | 15 << 4 | 15 << 8 | 15 << 12 | 1 << 20 | 1 << 19);                /* stage 1: d = CPREV (0), x2 */
    bp(0xC3, 0 | 7 << 7 | 7 << 10 | 7 << 13 | 1 << 20 | 1 << 19);                  /* alpha d = APREV */
    quad_flat(100, 100, 500, 400, 0, 200, 120, 60, 255);
    quad_flat(520, 100, 620, 400, 0, 20, 240, 130, 90);
}

static void run(Scene sc, const GxrBackend *be, uint8_t *out) {
    gxr_set_backend(be);
    be->clear(0, 0, GXR_EFB_W, GXR_EFB_H, 1, 1, 1, (const uint8_t[4]){ 0, 0, 0, 0 }, 0.99999994f);
    sc();
    be->read(0, 0, GXR_EFB_W, GXR_EFB_H, out);
}
static void compare(const char *name, Scene sc) {
    run(sc, &gxr_soft_backend, efb_soft); run(sc, &gxr_gles_backend, efb_gl);
    long covered = 0, bad = 0, edge = 0; int maxd = 0;
    for (size_t i = 0; i < (size_t)GXR_EFB_W * GXR_EFB_H; i++) {
        const uint8_t *a = &efb_soft[i * 4], *b = &efb_gl[i * 4]; int d = 0;
        for (int k = 0; k < 4; k++) { int dd = abs(a[k] - b[k]); if (dd > d) d = dd; }
        if (a[0] || a[1] || a[2] || a[3]) covered++;
        if (d > maxd) maxd = d;
        if (d > 3) {
            if (d > 40) edge++;
            if (bad < 3 && getenv("RT_TEST_VERBOSE")) printf("        %s px (%zu,%zu): soft %d %d %d %d, gl %d %d %d %d\n", name, i % GXR_EFB_W, i / GXR_EFB_W, a[0], a[1], a[2], a[3], b[0], b[1], b[2], b[3]);
            bad++;
        }
    }
    printf("      %-9s covered %7ld px, differing (>3) %5ld, large (>40) %4ld, max %3d\n", name, covered, bad, edge, maxd);
    /* A pixel that is on a triangle edge may fall on either side of it; everything else must agree. 0.4% of the covered area is generous for edges. */
    CHECK(covered > 1000, "%s: the software backend drew almost nothing (%ld px)", name, covered);
    CHECK(bad * 250 <= covered, "%s: %ld pixels differ by more than 3 levels (of %ld covered)", name, bad, covered);
}

int main(void) {
    C = calloc(1, sizeof *C); C->mem1 = calloc(1, 0x1800000); C->mem2 = calloc(1, 0x4000000); C->lc = calloc(1, 0x4000);
    if (!gxr_gles_start()) { printf("SKIP  GX renderer cross-check: no OpenGL ES 3 / EGL here (on a PC: Mesa + RT_GL_HEADLESS=1)\n"); return 0; }
    compare("depth", scene_depth); compare("blend", scene_blend); compare("cull", scene_cull); compare("scissor", scene_scissor);
    compare("texture", scene_texture); compare("tev", scene_tev);
    printf("%s  GX renderer: OpenGL ES backend vs software backend\n", fails ? "FAIL" : "PASS");
    return fails != 0;
}
