/* Links against all generated code: proves every symbol resolves.
 * gcc -O0 -ffp-contract=off -frounding-math -Iruntime -Igen tests/link_smoke.c gen/*.o runtime/rt.c -lm */
#include "rt.h"
#include "funcs.h"
#include <stdio.h>
#include <stdlib.h>
int main(void) {
    Ctx *c = calloc(1, sizeof *c);
    c->mem1 = calloc(1, 0x1800000); c->mem2 = calloc(1, 0x4000000);
    (void)func_80004050;   /* the DOL entry point */
    printf("table has %u functions, first=0x%08X\n", rt_func_count, rt_func_table[0].addr);
    return 0;
}
