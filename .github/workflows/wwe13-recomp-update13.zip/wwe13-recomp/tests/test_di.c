/* Tests for the virtual disc (rt_di.c) against a tiny fabricated disc folder; no game data involved.
 * usage: test_di [fst|folder]   fst: trust sys/fst.bin; folder: build the file table from the folder (the default mode of the boot harness) */
#include "rt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

const rt_func_entry rt_func_table[] = { {0x80100000u, 0} };
const uint32_t rt_func_count = 0;

int rt_di_open(const char *root, int use_fst);
void rt_di_boot(Ctx *c);
void rt_di_read(uint8_t *dst, uint64_t pos, uint32_t len);
Ctx *rt_ctx_new(void);

static int fails;
#define CHECK(cond, ...) do { if (!(cond)) { fails++; printf("FAIL  line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

static void put32(uint8_t *p, uint32_t v) { p[0] = v >> 24; p[1] = v >> 16; p[2] = v >> 8; p[3] = v; }
static void write_file(const char *dir, const char *name, const uint8_t *d, size_t n) {
    char p[512]; snprintf(p, sizeof p, "%s/%s", dir, name);
    FILE *f = fopen(p, "wb"); if (!f || fwrite(d, 1, n, f) != n) { perror(p); exit(2); } fclose(f);
}
static void fill(uint8_t *d, size_t n, uint8_t seed) { for (size_t i = 0; i < n; i++) d[i] = (uint8_t)(seed + i); }

/* Partition layout used by the test:
 *   0x0000 boot.bin (0x440)   0x0440 bi2.bin (0x2000)   0x2440 apploader (0x100)
 *   0x4000 main.dol (0x200)   0x5000 fst.bin            0x10000 a.bin (100 bytes)   0x10100 sub/b.bin (50)   0x20000 sub/gone.bin (64, not on disk) */
#define A_OFF 0x10000u
#define B_OFF 0x10100u
#define G_OFF 0x20000u

int main(int argc, char **argv) {
    int use_fst = !(argc > 1 && !strcmp(argv[1], "folder"));
    char root[] = "/tmp/rt_di_test_XXXXXX";
    if (!mkdtemp(root)) { perror("mkdtemp"); return 2; }
    char d[600]; snprintf(d, sizeof d, "%s/sys", root); mkdir(d, 0755);
    snprintf(d, sizeof d, "%s/files", root); mkdir(d, 0755);
    snprintf(d, sizeof d, "%s/files/sub", root); mkdir(d, 0755);

    uint8_t fstb[128] = {0};                                         /* root, a.bin, sub/, b.bin, gone.bin  = 5 entries */
    const char names[] = "a.bin\0sub\0b.bin\0gone.bin";
    put32(fstb + 0, 0x01000000); put32(fstb + 8, 5);
    put32(fstb + 12, 0x00000000); put32(fstb + 16, A_OFF >> 2); put32(fstb + 20, 100);
    put32(fstb + 24, 0x01000006); put32(fstb + 28, 0); put32(fstb + 32, 5);                  /* dir "sub": ends before index 5 */
    put32(fstb + 36, 0x0000000A); put32(fstb + 40, B_OFF >> 2); put32(fstb + 44, 50);
    put32(fstb + 48, 0x00000010); put32(fstb + 52, G_OFF >> 2); put32(fstb + 56, 64);
    memcpy(fstb + 60, names, sizeof names);
    size_t fst_len = 60 + sizeof names;

    uint8_t boot[0x440], bi2[0x2000], app[0x100], dol[0x200], a[100], b[50];
    memset(boot, 0, sizeof boot); memcpy(boot, "TEST01", 6); put32(boot + 0x18, 0x5D1C9EA3);
    put32(boot + 0x420, 0x4000 >> 2); put32(boot + 0x424, 0x5000 >> 2); put32(boot + 0x428, (uint32_t)fst_len >> 2);
    memset(bi2, 0xB2, sizeof bi2); memset(app, 0xA9, sizeof app); memset(dol, 0xD0, sizeof dol);
    fill(a, sizeof a, 1); fill(b, sizeof b, 100);
    snprintf(d, sizeof d, "%s/sys", root);
    write_file(d, "boot.bin", boot, sizeof boot); write_file(d, "bi2.bin", bi2, sizeof bi2);
    write_file(d, "apploader.img", app, sizeof app); write_file(d, "main.dol", dol, sizeof dol);
    write_file(d, "fst.bin", fstb, fst_len);
    snprintf(d, sizeof d, "%s/files", root); write_file(d, "a.bin", a, sizeof a);
    snprintf(d, sizeof d, "%s/files/sub", root); write_file(d, "b.bin", b, sizeof b);
    uint8_t zb[300]; fill(zb, sizeof zb, 7);                          /* a file the FST in sys/ does not know about, different size than any FST entry */
    snprintf(d, sizeof d, "%s/files", root); write_file(d, "Z.bin", zb, sizeof zb);

    CHECK(rt_di_open("/nonexistent-folder", use_fst) == -1, "a missing folder must be rejected");
    CHECK(rt_di_open(root, use_fst) == 0, "open fabricated disc");
    if (!use_fst) goto folder_mode;

    if (0) {
folder_mode:;
        /* The file table is built from the folder: look names up in the FST the game would see, then read through the disc. */
        Ctx *c = rt_ctx_new(); rt_di_boot(c);
        uint32_t fp = rt_r32(c, 0x80000038u), n = rt_r32(c, fp + 8);
        CHECK(n == 5, "root + a.bin + sub + sub/b.bin + Z.bin = 5 entries (gone.bin is not in the folder), got %u", n);
        const char *want[] = { "a.bin", "sub/b.bin", "Z.bin" };
        const uint8_t *exp[] = { a, b, zb }; const size_t explen[] = { sizeof a, sizeof b, sizeof zb };
        for (int k = 0; k < 3; k++) {
            uint32_t i = 1, end = n, found = 0; const char *p = want[k];
            while (i < end && p) {                                            /* walk like DVDConvertPathToEntrynum */
                uint32_t w = rt_r32(c, fp + 12 * i), off = rt_r32(c, fp + 12 * i + 4), len = rt_r32(c, fp + 12 * i + 8);
                char nm[64]; uint32_t o = fp + 12 * n + (w & 0xFFFFFF), q = 0; while ((nm[q] = (char)rt_r8(c, o + q))) q++;
                size_t l = strlen(nm), pl = strcspn(p, "/");
                if (l == pl && !strncmp(nm, p, l)) {
                    if (w >> 24) { p += pl + 1; end = len; i++; continue; }  /* descend */
                    uint8_t buf[400]; rt_di_read(buf, (uint64_t)off << 2, len);
                    CHECK(len == explen[k] && !memcmp(buf, exp[k], len), "%s: FST entry (len %u) and disc read agree", want[k], len);
                    found = 1; break;
                }
                i = (w >> 24) ? len : i + 1;                                 /* skip a non-matching directory's subtree */
            }
            CHECK(found, "%s found in the generated FST", want[k]);
        }
        uint32_t mx = 0; for (uint32_t i = 1; i < n; i++) { uint32_t w = rt_r32(c, fp + 12 * i); if (!(w >> 24)) { uint32_t o = rt_r32(c, fp + 12 * i + 4); CHECK(((uint64_t)o << 2) % 0x8000 == 0, "file %u 32 KiB aligned", i); mx = o > mx ? o : mx; } }
        CHECK((rt_r32(c, fp + 12 * 2) >> 24) == 1 && rt_r32(c, fp + 12 * 2 + 4) == 0 && rt_r32(c, fp + 12 * 2 + 8) == 4, "entry 2 is directory 'sub' (parent 0) ending before entry 4");
        snprintf(d, sizeof d, "rm -rf %s", root); if (system(d)) {}
        if (fails) { printf("%d check(s) failed\n", fails); return 1; }
        printf("PASS  virtual disc (file table built from the folder): FST entries agree with disc reads\n");
        return 0;
    }

    uint8_t buf[0x200];
    rt_di_read(buf, A_OFF, 100);       CHECK(!memcmp(buf, a, 100), "whole file a.bin");
    rt_di_read(buf, A_OFF + 90, 30);   CHECK(!memcmp(buf, a + 90, 10), "tail of a.bin");
    {   int z = 1; for (int i = 10; i < 30; i++) z &= buf[i] == 0; CHECK(z, "alignment gap after a.bin reads as zeros"); }
    rt_di_read(buf, A_OFF + 0xF0, 0x40);                                    /* gap, then the start of b.bin at 0x10100 */
    {   int z = 1; for (int i = 0; i < 0x10; i++) z &= buf[i] == 0; CHECK(z, "gap before b.bin is zero");
        CHECK(!memcmp(buf + 0x10, b, 0x30), "b.bin begins at partition offset 0x10100 (nested directory resolved)"); }
    rt_di_read(buf, G_OFF, 64);        { int z = 1; for (int i = 0; i < 64; i++) z &= buf[i] == 0; CHECK(z, "missing file reads as zeros"); }
    rt_di_read(buf, 0, 0x10);          CHECK(!memcmp(buf, "TEST01", 6), "boot.bin at offset 0");
    rt_di_read(buf, 0x438, 0x10);      CHECK(!memcmp(buf, boot + 0x438, 8) && buf[8] == 0xB2 && buf[15] == 0xB2, "boot.bin -> bi2.bin boundary");
    rt_di_read(buf, 0x4000, 0x10);     CHECK(buf[0] == 0xD0 && buf[15] == 0xD0, "main.dol at the offset boot.bin names");
    rt_di_read(buf, 0x5000, 12);       CHECK(!memcmp(buf, fstb, 12), "fst.bin at the offset boot.bin names");
    rt_di_read(buf, 0x7FFFFF00u, 16);  { int z = 1; for (int i = 0; i < 16; i++) z &= buf[i] == 0; CHECK(z, "unmapped area reads as zeros"); }

    /* The real path: IOS requests in guest memory, open("/dev/di") then ioctl 0x71 / 0x70. */
    Ctx *c = rt_ctx_new();
    rt_di_boot(c);
    uint32_t fst_ptr = rt_r32(c, 0x80000038u);
    CHECK(fst_ptr >= 0x81700000u && fst_ptr < 0x81800000u && !(fst_ptr & 31), "FST pointer set (0x%08X), 32-byte aligned, above the arena end (0x81700000)", fst_ptr);
    CHECK(rt_r32(c, 0x8000003Cu) >= fst_len, "FST max size covers the FST");
    CHECK(!memcmp(rt_ptr(c, fst_ptr), fstb, fst_len), "FST copied into guest memory");
    CHECK(!memcmp(rt_ptr(c, 0x80000000u), "TEST01", 6) && !memcmp(rt_ptr(c, 0x80003180u), "TEST", 4), "game ID in low memory");

    const uint32_t REQ = 0x00100000, PATH = 0x00100200, IN = 0x00100300, OUT = 0x00200000;   /* physical addresses */
    const char *dev = "/dev/di"; for (size_t i = 0; i <= strlen(dev); i++) rt_w8(c, 0x80000000u + PATH + (uint32_t)i, (uint32_t)(unsigned char)dev[i]);
    rt_w32(c, 0x80000000u + REQ + 0, 1); rt_w32(c, 0x80000000u + REQ + 0xC, PATH); rt_w32(c, 0x80000000u + REQ + 0x10, 0);
    CHECK(rt_ios_request(c, REQ) == 0, "open replies immediately");
    int32_t fd = (int32_t)rt_r32(c, 0x80000000u + REQ + 4);
    CHECK(fd > 0, "open /dev/di gives fd %d", fd);

    rt_w32(c, 0x80000000u + IN + 0, 0x71000000u); rt_w32(c, 0x80000000u + IN + 4, 100); rt_w32(c, 0x80000000u + IN + 8, A_OFF >> 2);
    rt_w32(c, 0x80000000u + REQ + 0, 6); rt_w32(c, 0x80000000u + REQ + 8, (uint32_t)fd); rt_w32(c, 0x80000000u + REQ + 0xC, 0x71);
    rt_w32(c, 0x80000000u + REQ + 0x10, IN); rt_w32(c, 0x80000000u + REQ + 0x14, 0x20);
    rt_w32(c, 0x80000000u + REQ + 0x18, OUT); rt_w32(c, 0x80000000u + REQ + 0x1C, 100);
    CHECK(rt_ios_request(c, REQ) == 0, "ioctl replies immediately");
    CHECK(rt_r32(c, 0x80000000u + REQ + 4) == 1, "DI read result is 1 (success)");
    CHECK(!memcmp(rt_ptr(c, 0x80000000u + OUT), a, 100), "DI read 0x71 delivers a.bin into guest memory");

    rt_w32(c, 0x80000000u + REQ + 0, 6); rt_w32(c, 0x80000000u + REQ + 8, (uint32_t)fd);     /* the reply overwrote cmd and fd */
    rt_w32(c, 0x80000000u + REQ + 0xC, 0x70); rt_w32(c, 0x80000000u + REQ + 0x1C, 0x20);
    memset(rt_ptr(c, 0x80000000u + OUT), 0, 0x20);
    rt_ios_request(c, REQ);
    CHECK(!memcmp(rt_ptr(c, 0x80000000u + OUT), "TEST01", 6), "DI 0x70 returns the disc ID/header");

    snprintf(d, sizeof d, "rm -rf %s", root); if (system(d)) {}
    if (fails) { printf("%d check(s) failed\n", fails); return 1; }
    printf("PASS  virtual disc: FST tree, extents, gaps, system area, missing files, IOS /dev/di read\n");
    return 0;
}
