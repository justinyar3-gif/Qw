/* Runtime tests for threads and interrupts using fake guest functions (no lifted code).
 * usage: test_threads <ping_pong|interrupt|decrementer|irq_switch> */
#include "rt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define CTX_A    0x80200000u
#define CTX_B    0x80200400u
#define CTX_IDLE 0x80200800u
#define FN_THREAD_B 0x80100020u
#define FN_EXIT     0x80100030u
#define FN_HANDLER  0x80100040u
#define FN_HANDLER_SWITCH 0x80100050u
#define FN_THREAD_B2 0x80100060u

static int logv[32], nl;
static void L(int v) { logv[nl++] = v; }
static volatile int flag;
static Ctx *C0;

static void fn_exit(Ctx *c) { L(200); c->r[3] = CTX_A; rt_os_load_context(c); L(999); }
static void thread_b(Ctx *c) {
    L(100 + (int)c->r[3]);
    c->r[3] = CTX_B; rt_os_save_context(c);
    L(101);
    c->r[3] = CTX_A; rt_os_load_context(c);          /* switch to A; returns when B is scheduled again */
    L(102);
}
static void irq_clear(Ctx *c) { rt_w32(c, 0xCD000004u, 0x36); }   /* clear Y1/Y2, keep IY1/IY2 */
static void handler(Ctx *c) {                         /* like ExternalInterruptHandler: ends with OSLoadContext(ctx) */
    L((int)c->r[3]); L(c->r[4] == CTX_IDLE);
    irq_clear(c); flag = 1;
    c->r[5] = 0xDEAD;                                  /* clobber: must be restored */
    c->r[3] = c->r[4]; rt_os_load_context(c);
}
static void handler_dec(Ctx *c) { L((int)c->r[3]); flag = 1; c->r[5] = 0xDEAD; c->r[3] = c->r[4]; rt_os_load_context(c); }
static void handler_switch(Ctx *c) {                  /* the interrupt handler decides to run thread B */
    L(10); irq_clear(c);
    c->r[3] = CTX_B; rt_os_load_context(c);           /* returns only if A is rescheduled normally */
    L(998);
}
static void thread_b2(Ctx *c) {
    L(20); flag = 1;
    c->r[3] = CTX_A; rt_os_load_context(c);           /* resume the interrupted thread */
    L(997);
}
static void fn_save(Ctx *c) { rt_os_save_context(c); }
static void fn_load(Ctx *c) { rt_os_load_context(c); }

const rt_func_entry rt_func_table[] = {
    {0x80100000u, fn_save}, {0x80100010u, fn_load}, {FN_THREAD_B, thread_b}, {FN_EXIT, fn_exit},
    {FN_HANDLER, handler}, {FN_HANDLER_SWITCH, handler_switch}, {FN_THREAD_B2, thread_b2}, {0x80100070u, handler_dec},
};
const uint32_t rt_func_count = sizeof rt_func_table / sizeof rt_func_table[0];

static void init_thread_ctx(Ctx *c, uint32_t ctx, uint32_t entry, uint32_t arg) {
    rt_w32(c, ctx + 0x198, entry); rt_w32(c, ctx + 4, 0x80300000u); rt_w32(c, ctx + 0xC, arg);
    rt_w32(c, ctx + 0x84, FN_EXIT); rt_w32(c, ctx + 0x19C, 0x8000u);
}
static void expect(const char *name, const int *want, int n) {
    int ok = nl == n;
    for (int i = 0; ok && i < n; i++) ok = logv[i] == want[i];
    printf("%s  %s", ok ? "PASS" : "FAIL", name);
    if (!ok) { printf("\n      got:"); for (int i = 0; i < nl; i++) printf(" %d", logv[i]); }
    printf("\n"); fflush(stdout); _exit(ok ? 0 : 1);
}
static void raise_ipc_interrupt(Ctx *c) {            /* PI mask, Hollywood mask, then an IOS request whose reply raises the line */
    rt_w32(c, 0xCC003004u, 0x4000); rt_w32(c, 0xCD000034u, 0x40000000u);
    rt_w32(c, 0x80000100u, 0);                        /* request: cmd 0 (unknown) is fine, we only need the reply */
    rt_w32(c, 0xCD000000u, 0x100); rt_w32(c, 0xCD000004u, 0x31);
}

int main(int argc, char **argv) {
    if (argc < 2) return 2;
    Ctx *c = calloc(1, sizeof *c); C0 = c;
    c->mem1 = calloc(1, 0x1800000); c->mem2 = calloc(1, 0x4000000);
    rt_fiber_main_init(c);
    c->r[1] = 0x80280000u;
    if (!strcmp(argv[1], "sc_aspect")) {              /* SCGetAspectRatio HLE: 16:9 by default, 4:3 on request */
        c->r[3] = 99; rt_hle_sc_get_aspect_ratio(c); int a = (int)c->r[3];
        rt_sc_widescreen = 0; c->r[3] = 99; rt_hle_sc_get_aspect_ratio(c); int b = (int)c->r[3];
        int ok = a == 1 && b == 0;
        printf("%s  SCGetAspectRatio: 16:9 by default (got %d), 4:3 when switched (got %d)\n", ok ? "PASS" : "FAIL", a, b);
        return !ok;
    }
    if (!strcmp(argv[1], "ping_pong")) {
        init_thread_ctx(c, CTX_B, FN_THREAD_B, 7);
        c->r[3] = CTX_A; rt_os_save_context(c); L(1);
        c->r[3] = CTX_B; rt_os_load_context(c);       /* B starts, saves, switches back here */
        L(2);
        c->r[3] = CTX_A; rt_os_save_context(c);
        c->r[3] = CTX_B; rt_os_load_context(c);       /* B resumes, finishes, its exit routine switches back */
        L(3);
        static const int want[] = {1, 107, 101, 2, 102, 200, 3};
        expect("threads: new thread, save/load ping-pong, exit routine", want, 7);
    }
    rt_w32(c, 0x800000D4u, CTX_IDLE); rt_w32(c, 0x80003010u, FN_HANDLER);   /* OSCurrentContext; external handler */
    rt_irq_init(c);
    if (!strcmp(argv[1], "interrupt")) {
        c->msr |= 0x8000u; c->r[5] = 0x1234;
        raise_ipc_interrupt(c);
        for (long i = 0; !flag && i < 100000000L; i++) RT_POLL(c);
        static const int want[] = {4, 1};
        printf("%s  interrupt: delivered at poll site, r5 restored, EE restored\n",
               (flag && c->r[5] == 0x1234 && (c->msr & 0x8000u)) ? "PASS" : "FAIL");
        int ok = flag && c->r[5] == 0x1234 && (c->msr & 0x8000u);
        for (int i = 0; ok && i < 2; i++) ok = logv[i] == want[i];
        if (!ok) { printf("FAIL  log mismatch / state (flag=%d r5=%X msr=%X)\n", flag, c->r[5], c->msr); return 1; }
        return 0;
    }
    if (!strcmp(argv[1], "decrementer")) {
        rt_w32(c, 0x80003020u, 0x80100070u);              /* exception 8 handler */
        c->msr |= 0x8000u; c->r[5] = 0x1234;
        rt_set_dec(c, 60750);                             /* about 1 ms */
        for (long i = 0; !flag && i < 400000000L; i++) RT_POLL(c);
        int ok = flag && c->r[5] == 0x1234 && logv[0] == 8;
        printf("%s  decrementer: fires after about 1 ms, exception 8\n", ok ? "PASS" : "FAIL");
        return !ok;
    }
    if (!strcmp(argv[1], "irq_switch")) {
        rt_w32(c, 0x800000E4u, CTX_A);                    /* OSCurrentThread = A: a thread, not idle */
        rt_w32(c, 0x800000D4u, CTX_A);                    /* its context is the current context */
        rt_w32(c, 0x80003010u, FN_HANDLER_SWITCH);
        init_thread_ctx(c, CTX_B, FN_THREAD_B2, 0);
        c->msr |= 0x8000u; c->r[5] = 0x1234;
        raise_ipc_interrupt(c);
        for (long i = 0; !flag && i < 100000000L; i++) RT_POLL(c);
        static const int want[] = {10, 20};
        int ok = flag && c->r[5] == 0x1234 && nl == 2 && logv[0] == 10 && logv[1] == 20;
        printf("%s  interrupt -> handler switches to thread B -> B resumes A at the poll site\n", ok ? "PASS" : "FAIL");
        if (!ok) { printf("      got:"); for (int i = 0; i < nl; i++) printf(" %d", logv[i]); printf("  r5=%X\n", c->r[5]); }
        (void)want; fflush(stdout); _exit(!ok);
    }
    return 2;
}
