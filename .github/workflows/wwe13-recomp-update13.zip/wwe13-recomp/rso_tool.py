#!/usr/bin/env python3
"""Read Nintendo RSO-format files (StaticModule_*.sel, *.rso) from YOUR disc dump.

  python rso_tool.py info    StaticModule_USA.sel
  python rso_tool.py symbols StaticModule_USA.sel symbols.txt [--bases 1=0x80004000,2=0x800067E0]
                             [--detect out/functions.json] [--merge out/functions.json out/functions_merged.json]

StaticModule_USA.sel describes main.dol as a module: its export table maps SDK/libc names to
(ELF section, offset). Section ids are ELF section indices; here 1 = .init (0x80004000) and
2 = .text (0x800067E0), plus two absolute symbols (_SDA_BASE_ = r13, _SDA2_BASE_ = r2).
Every export entry carries the ELF hash of its name, which is used to check the parse.

Only run this on files from a disc you own. Keep the generated symbol list out of public repos.
"""
import json, struct, sys

DEFAULT_BASES = {1: 0x80004000, 2: 0x800067E0}      # WWE '13 USA main.dol: .init and .text
SHN_ABS = 0xFFF1


def elf_hash(name):
    h = 0
    for c in name.encode("latin1"):
        h = ((h << 4) + c) & 0xFFFFFFFF
        g = h & 0xF0000000
        if g:
            h ^= g >> 24
        h &= ~g & 0xFFFFFFFF
    return h


class Rso:
    FIELDS = ("next", "prev", "num_sections", "section_info", "name_off", "name_size", "version", "bss_size")

    def __init__(self, data):
        self.b = data
        u = self.u32
        if len(data) < 0x58:
            raise ValueError("file too small for an RSO header")
        for i, f in enumerate(self.FIELDS):
            setattr(self, f, u(4 * i))
        self.prolog_sec, self.epilog_sec, self.unresolved_sec, self.bss_sec = data[0x20:0x24]
        (self.prolog, self.epilog, self.unresolved, self.int_rel, self.int_rel_size, self.ext_rel,
         self.ext_rel_size, self.exp, self.exp_size, self.exp_names, self.imp, self.imp_size,
         self.imp_names) = struct.unpack(">13I", data[0x24:0x24 + 52])
        for f in ("section_info", "name_off", "int_rel", "ext_rel", "exp", "exp_names", "imp", "imp_names"):
            if getattr(self, f) > len(data):
                raise ValueError("header field %s points outside the file; not an RSO?" % f)

    def u32(self, o):
        return struct.unpack(">I", self.b[o:o + 4])[0]

    @property
    def module_name(self):
        return self.b[self.name_off:self.name_off + self.name_size].split(b"\0")[0].decode("latin1")

    def sections(self):
        for i in range(self.num_sections):
            off, size = struct.unpack(">II", self.b[self.section_info + 8 * i:self.section_info + 8 * i + 8])
            yield i, off & ~1, size

    def exports(self):
        """(name, section, offset, hash_ok) for every export entry."""
        for i in range(self.exp_size // 16):
            no, off, sec, h = struct.unpack(">IIII", self.b[self.exp + 16 * i:self.exp + 16 * i + 16])
            s = self.exp_names + no
            name = self.b[s:self.b.index(b"\0", s)].decode("latin1")
            yield name, sec, off, elf_hash(name) == h


def resolve(sec, off, bases):
    if sec == SHN_ABS:
        return off
    return bases[sec] + off if sec in bases else None


def detect_bases(rso, functions, defaults, sections=(1, 2), min_exports=8):
    """Check each section's base against the known function starts. The default base is kept unless a
    search finds one that scores strictly higher; sections with few exports are too ambiguous to search."""
    fs = set(functions)
    found = {}
    for sec in sections:
        offs = [o for _, s, o, _ in rso.exports() if s == sec]
        if not offs:
            continue
        score = lambda base: sum(1 for o in offs if base + o in fs)
        base, hits = defaults.get(sec), 0
        if base is not None:
            hits = score(base)
        if len(offs) >= min_exports:
            best = max(range(0x7FFF0000, 0x80020000, 4), key=score)
            if base is None or score(best) > hits:
                base, hits = best, score(best)
        elif base is None:
            print("section %d: only %d exports and no default base; pass --bases" % (sec, len(offs)))
            continue
        found[sec] = base
        print("section %d: base 0x%08X, %d/%d exports are known function starts" % (sec, base, hits, len(offs)))
    return found


def parse_bases(text):
    return {int(k): int(v, 0) for k, v in (p.split("=") for p in text.split(","))}


def main(argv):
    if len(argv) < 3 or argv[1] not in ("info", "symbols"):
        print(__doc__)
        return 1
    rso = Rso(open(argv[2], "rb").read())
    opt = lambda name, n=1: argv[argv.index(name) + 1:argv.index(name) + 1 + n] if name in argv else None
    if argv[1] == "info":
        print("module: %s\nsections: %d  bss: 0x%X  version: %d" % (rso.module_name, rso.num_sections, rso.bss_size, rso.version))
        for i, off, size in rso.sections():
            if off or size:
                print("  section %2d: file offset 0x%08X size 0x%08X" % (i, off, size))
        ex = list(rso.exports())
        print("exports: %d (hash check passed for %d)" % (len(ex), sum(e[3] for e in ex)))
        print("relocations: %d internal, %d external; imports: %d" % (rso.int_rel_size // 8, rso.ext_rel_size // 8, rso.imp_size // 8))
        return 0
    if len(argv) < 4:
        print(__doc__)
        return 1
    bases = dict(DEFAULT_BASES)
    if opt("--bases"):
        bases = parse_bases(opt("--bases")[0])
    funcs = None
    if opt("--detect"):
        funcs = [int(x, 16) for x in json.load(open(opt("--detect")[0]))["functions"]]
        bases.update(detect_bases(rso, funcs, bases))
    rows, bad = [], 0
    for name, sec, off, ok in rso.exports():
        bad += not ok
        a = resolve(sec, off, bases)
        if a is None:
            print("skipping %s: no base for section %d" % (name, sec), file=sys.stderr)
            continue
        rows.append((a, name))
    rows.sort()
    with open(argv[3], "w") as f:
        for a, n in rows:
            f.write("%08X %s\n" % (a, n))
    print("wrote %d symbols to %s (%d failed the ELF-hash check)" % (len(rows), argv[3], bad))
    if opt("--merge", 2):
        src, dst = opt("--merge", 2)
        d = json.load(open(src))
        have = set(int(x, 16) for x in d["functions"])
        text_secs = [s for s in bases if s != SHN_ABS]
        new = sorted(a for a, n in rows if a not in have and a >= min(bases.values()) and a < 0x80900000
                     and any(sec in text_secs and resolve(sec, off, bases) == a for n2, sec, off, _ in rso.exports() if n2 == n))
        d["functions"] = ["0x%08X" % a for a in sorted(have | set(new))]
        d["stats"]["total"] = len(d["functions"])
        json.dump(d, open(dst, "w"), indent=1)
        print("added %d function starts (exports that nothing in the DOL calls directly) -> %s" % (len(new), dst))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
