#!/usr/bin/env python3
"""DOL toolkit for static-recompilation planning (Wii / GameCube).

Usage:
  python dol_tool.py info  main.dol
  python dol_tool.py split main.dol out/     # raw section dumps + sections.json
  python dol_tool.py scan  main.dol out/     # candidate function starts -> functions.json
  python dol_tool.py stats main.dol          # opcode histogram (what a lifter must support)

Bring your own main.dol from a disc you own. Never redistribute game files.
"""
import json
import os
import struct
import sys
from collections import Counter

OPNAMES = {
    4: "paired-single", 7: "mulli", 10: "cmpli", 11: "cmpi", 12: "addic",
    14: "addi", 15: "addis", 16: "bc", 18: "b/bl", 19: "bclr/bcctr/crops",
    20: "rlwimi", 21: "rlwinm", 23: "rlwnm", 24: "ori", 25: "oris",
    28: "andi.", 31: "integer-ext", 32: "lwz", 33: "lwzu", 34: "lbz",
    35: "lbzu", 36: "stw", 37: "stwu", 38: "stb", 39: "stbu", 40: "lhz",
    41: "lhzu", 42: "lha", 44: "sth", 45: "sthu", 46: "lmw", 47: "stmw",
    48: "lfs", 49: "lfsu", 50: "lfd", 52: "stfs", 53: "stfsu", 54: "stfd",
    56: "psq_l", 57: "psq_lu", 59: "float-single-ext", 60: "psq_st",
    61: "psq_stu", 63: "float-ext",
}


def load(path):
    d = open(path, "rb").read()
    if len(d) < 0x100:
        sys.exit("File too small to be a DOL")
    off = struct.unpack(">18I", d[0x00:0x48])
    addr = struct.unpack(">18I", d[0x48:0x90])
    size = struct.unpack(">18I", d[0x90:0xD8])
    bss_addr, bss_size, entry = struct.unpack(">3I", d[0xD8:0xE4])
    secs = []
    for i in range(18):
        if size[i] == 0:
            continue
        if off[i] + size[i] > len(d):
            sys.exit(f"Section {i} runs past end of file; not a valid DOL")
        kind = "text" if i < 7 else "data"
        name = f"text{i}" if i < 7 else f"data{i - 7}"
        secs.append(dict(name=name, kind=kind, offset=off[i],
                         addr=addr[i], size=size[i]))
    meta = dict(bss_addr=bss_addr, bss_size=bss_size, entry=entry)
    return d, secs, meta


def words(d, s):
    n = s["size"] // 4
    return struct.unpack(f">{n}I", d[s["offset"]:s["offset"] + n * 4])


def cmd_info(d, secs, meta):
    for s in secs:
        print(f"{s['name']:6} file=0x{s['offset']:07X} "
              f"addr=0x{s['addr']:08X} size=0x{s['size']:07X}")
    print(f"bss    addr=0x{meta['bss_addr']:08X} size=0x{meta['bss_size']:X}")
    print(f"entry  0x{meta['entry']:08X}")


def cmd_split(d, secs, meta, out):
    os.makedirs(out, exist_ok=True)
    for s in secs:
        with open(os.path.join(out, s["name"] + ".bin"), "wb") as f:
            f.write(d[s["offset"]:s["offset"] + s["size"]])
    with open(os.path.join(out, "sections.json"), "w") as f:
        json.dump(dict(sections=secs, **meta), f, indent=2)
    print(f"Wrote {len(secs)} sections + sections.json to {out}")


def cmd_scan(d, secs, meta, out):
    text = [s for s in secs if s["kind"] == "text"]

    def in_text(a):
        return any(s["addr"] <= a < s["addr"] + s["size"] for s in text)

    bl_targets, prologues = Counter(), set()
    for s in text:
        w = words(d, s)
        for i, x in enumerate(w):
            pc = s["addr"] + i * 4
            # bl (opcode 18, AA=0, LK=1): strong call-graph evidence
            if x >> 26 == 18 and (x & 3) == 1:
                li = x & 0x03FFFFFC
                if li & 0x02000000:
                    li -= 0x04000000
                t = (pc + li) & 0xFFFFFFFF
                if in_text(t):
                    bl_targets[t] += 1
            # Metrowerks: stwu r1,-N(r1) ; mflr r0
            if (x & 0xFFFF8000) == 0x94218000 and 0x7C0802A6 in w[i + 1:i + 4]:
                prologues.add(pc)
            # GCC-style: mflr r0 ; stw r0,4(r1)
            if x == 0x7C0802A6 and 0x90010004 in w[i + 1:i + 3]:
                prologues.add(pc)
    funcs = set(bl_targets) | prologues | {meta["entry"]}
    both = set(bl_targets) & prologues
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "functions.json"), "w") as f:
        json.dump(dict(
            functions=[f"0x{a:08X}" for a in sorted(funcs)],
            stats=dict(total=len(funcs), bl_targets=len(bl_targets),
                       prologues=len(prologues), confirmed_by_both=len(both)),
        ), f, indent=1)
    print(f"{len(funcs)} candidate functions "
          f"({len(bl_targets)} via bl, {len(prologues)} via prologue, "
          f"{len(both)} both) -> {out}/functions.json")


def cmd_stats(d, secs, meta):
    c, ps = Counter(), 0
    for s in secs:
        if s["kind"] != "text":
            continue
        for x in words(d, s):
            c[x >> 26] += 1
    total = sum(c.values())
    print(f"{total} instruction words in text sections\n")
    for op, n in c.most_common(20):
        print(f"{OPNAMES.get(op, 'op%d' % op):20} {n:8}  {100 * n / total:5.1f}%")
    ps = c[4] + c[56] + c[57] + c[60] + c[61]
    print(f"\nPaired-single related (op 4/56/57/60/61): {ps} "
          f"({100 * ps / total:.1f}%) -> lifter must support these")


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    cmd, path = sys.argv[1], sys.argv[2]
    out = sys.argv[3] if len(sys.argv) > 3 else "out"
    d, secs, meta = load(path)
    {"info": lambda: cmd_info(d, secs, meta),
     "split": lambda: cmd_split(d, secs, meta, out),
     "scan": lambda: cmd_scan(d, secs, meta, out),
     "stats": lambda: cmd_stats(d, secs, meta)}.get(cmd, lambda: sys.exit(__doc__))()


if __name__ == "__main__":
    main()
