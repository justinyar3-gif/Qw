#!/bin/bash
# Incremental, resumable compile of generated C. Only parts whose text changed are rebuilt.
# usage: scripts/build_gen.sh [gen_dir=gen] [seconds_budget=0 (unlimited)]
GEN=${1:-gen}; BUDGET=${2:-0}
R="$(cd "$(dirname "$0")/.." && pwd)/runtime"
cd "$GEN" || exit 1
start=$(date +%s); n=0
for f in part_*.c dispatch.c; do
  h=$(cat "$f" "$R/rt.h" | md5sum | cut -d' ' -f1)
  [ -f "$f.o" ] && [ "$(cat "$f.md5" 2>/dev/null)" = "$h" ] && continue
  if [ "$BUDGET" -gt 0 ] && [ $(( $(date +%s) - start )) -gt "$BUDGET" ]; then echo "PAUSED after $n (run again)"; exit 0; fi
  gcc -O0 -Wall -ffp-contract=off -frounding-math -c -I"$R" -I. "$f" -o "$f.o.tmp" \
    && mv "$f.o.tmp" "$f.o" && echo "$h" > "$f.md5" && n=$((n+1)) || { echo "FAILED $f"; exit 1; }
done
echo "ALL DONE (recompiled $n)"
