#!/bin/bash
# Links the boot harness: runtime + generated objects (+ optional game-specific C files as extra args).
# usage: scripts/link_boot.sh [gen_dir=gen] [extra.c ...]   ->   <gen_dir>/boot
GEN=${1:-gen}; shift
R="$(cd "$(dirname "$0")/.." && pwd)/runtime"
cd "$GEN" || exit 1
gcc -O1 -ffp-contract=off -frounding-math -I"$R" -I. \
  "$R"/rt.c "$R"/rt_mmio.c "$R"/rt_boot.c "$R"/rt_main.c "$R"/rt_irq.c "$R"/rt_thread.c "$R"/rt_ios.c "$R"/rt_hle.c "$R"/rt_gx.c "$R"/rt_di.c "$R"/rt_input.c "$R"/rt_gxr.c "$R"/rt_gxr_soft.c "$R"/rt_gxr_gles.c "$R"/rt_gxr_tex.c \
  "$R"/../game/*.c ./*.o "$@" \
  -o boot -rdynamic -lm -lpthread -ldl && echo "built $GEN/boot"
