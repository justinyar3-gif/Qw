# Mark candidate functions found by dol_tool.py scan.
# Run from Ghidra: Window > Script Manager > add this folder > run.
# @category WWE13Recomp
import json

f = askFile("Select functions.json", "Open")
data = json.load(open(f.getAbsolutePath()))

made = 0
for a in data["functions"]:
    addr = toAddr(int(a, 16))
    if getFunctionAt(addr) is None:
        disassemble(addr)
        if createFunction(addr, None) is not None:
            made += 1

println("Created %d functions" % made)
