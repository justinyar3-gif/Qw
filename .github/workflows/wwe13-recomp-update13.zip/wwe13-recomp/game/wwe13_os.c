/* WWE '13 (Wii) specific overrides. Addresses come from the DOL; they are not valid for other games.
 * Generated functions are weak, so these definitions replace them at link time.
 *   0x805D8DB0  OSSaveContext(context)      (identified from its disassembly: stmw r13, GQR saves, returns 0)
 *   0x805D8E30  OSLoadContext(context)      (ends with rfi to SRR0)
 * Both are implemented by the generic runtime; see runtime/rt_thread.c. */
#include "rt.h"
void func_805D8DB0(Ctx *c) { rt_os_save_context(c); }
void func_805D8E30(Ctx *c) { rt_os_load_context(c); }

/* 0x805D93A0: printf-style logger called as OSReport(fmt, ...) by the fatal-error path (OSFatal) */
void func_805D93A0(Ctx *c) { rt_hle_os_report(c); }

/* 0x8062B110: SCGetAspectRatio() (SCFindU8Item(&ar, 1); returns 1 only when the item is exactly 1). The game calls it at 0x80109104/0x80109170
 * to choose between plistwii.def (HD set: *HD.pac, game2dHD, evtgdhd) and plistwii_4x3.def (SD set). Default: 16:9, so the HD set is used;
 * `--aspect 4x3` gives the SD set. See rt_hle.c. */
void func_8062B110(Ctx *c) { rt_hle_sc_get_aspect_ratio(c); }

/* 0x80674DC0: KPADReadEx(chan, KPADStatus *buf, count, s32 *err) (r7 = 1, then falls into the body at 0x80674DD0). The game calls it from 0x806A3FF4
 * once per frame for each of the four channels. The Wii Remote is not emulated, so this is replaced by a virtual Classic Controller (rt_input.c). */
#include "rt_input.h"
void func_80674DC0(Ctx *c) { rt_hle_kpad_read_ex(c); }
