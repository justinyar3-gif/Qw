# WWE '13 (Wii) recompilation project

### WWE 2K to Wii model converter, by Jatin Talwar (Mod Place Wii)
Headline credit for the WWE 2K to Wii model converter by **Jatin Talwar (Mod Place Wii)**. The converter is a separate tool and is not
part of this repository; the runtime here does not use it.

Bring-your-own-files. Never commit or share `main.dol` or any disc assets.

## Status
| Milestone | State |
|---|---|
| M0 DOL tooling, function discovery | done |
| M1 Integer + branch lifter, runtime, tests | done |
| M2 Floating point + paired singles | done |
| M3 Jump tables, interrupts, threads, boot harness | **boots to the main menu**: boots through OS/SDK init, reads its files from an extracted disc folder (`--disc`), brings up the DSP (boot handshake) and the AX audio clock, loads the sound packs and the start-up archives, and **shows its screens** (Wii Remote safety notice, "WWE 2K26 / Don't try this at home", auto-save notice, the logo movie (garbled), the title screen and the main menu, which reacts to the scripted controller); no abort in 200 s; the 3D game scenes have not been reached; nothing is heard yet |
| M4 GX renderer, AX audio, input | input: **virtual Classic Controller done** (see "Controller input"). GX renderer: **done for what the first screens use, two backends**: a software rasterizer (reference, PNG dump) and an **OpenGL ES 3** backend; both agree on the test scenes and on real frames (see "Graphics"). **Vulkan: not implemented.** AX audio: todo |
| M5 Android packaging | **project written, never built** (`android/`): app, on-screen Classic Controller, native build, `android/build_apk.sh`. No APK exists yet; it must be built on a PC with the Android SDK and NDK (see "Android app") |

## Use
```
python dol_tool.py scan main.dol out/                       # initial function candidates
python rso_tool.py symbols StaticModule_USA.sel symbols.txt --detect out/functions.json \
       --merge out/functions.json out/functions_merged.json   # 190 SDK/libc names + 24 function starts only reachable from the HBM module
python tests/test_lifter.py                                 # 21 lift-compile-run tests (needs gcc)
tests/run_c_tests.sh                                        # 10 runtime tests: GX renderer (2: the software backend, and OpenGL ES vs software: needs Mesa/EGL, else SKIP), virtual controller, virtual disc (2), SCGetAspectRatio, threads, interrupts, decrementer
(cd android/tests && javac -d /tmp/tpl ../app/src/main/java/org/wwe13recomp/TouchPadLogic.java org/wwe13recomp/TouchPadLogicTest.java && java -cp /tmp/tpl org.wwe13recomp.TouchPadLogicTest)   # on-screen controller logic
python lifter.py coverage main.dol out/functions.json       # what is lifted / missing
python lifter.py gen main.dol out/functions.json gen/       # emit C (about 33 files, one per 256 KB of code)
scripts/build_gen.sh gen                                    # incremental compile (first full build is slow, ~4 min)
scripts/link_boot.sh gen                                    # -> gen/boot
gen/boot main.dol [timeout_s] [trace_n] [--mmio-log] [--header header.bin]   # run the lifted game's entry point
gen/boot main.dol 60 100 --disc <extracted disc folder>   # folder = sys/ + files/ as written by Dolphin's "Extract Entire Disc";
                                                          # the file table is built from the folder (add --disc-fst to trust sys/fst.bin)
gen/boot main.dol 60 100 --disc <folder> --aspect 4x3     # --aspect 16x9 is the default: the game loads its HD asset set (plistwii.def,
                                                          # *HD.pac); 4x3 makes it load the SD set (plistwii_4x3.def, *SD.pac)
gen/boot main.dol 60 100 --disc <folder> --render soft    # draw with the software rasterizer; --render gles = OpenGL ES 3 (on a PC: RT_GL_HEADLESS=1, Mesa);
                                                          # --render off (default without RT_FRAME_DUMP) = decode graphics, draw nothing
RT_FRAME_DUMP=frames RT_FRAME_EVERY=100 RT_FRAME_MAX=40 gen/boot ...   # write frames/frame_NNNNN.png (also RT_FRAME_AT=100,2400  RT_FRAME_ALL=1: the software
                                                          # backend normally draws only the frames it dumps, because it is slow)
RT_PAD_SCRIPT="PLUS:200:10,A:300:10" gen/boot ...         # scripted presses on the virtual controller (name[+name]:first_read:reads); RT_NO_PAD=1 or --no-pad = no controller
# debugging aids (environment variables):
#   RT_BREAK=805DB680     stop with call stack + recent functions when a guest function is entered
#   RT_LOG_AT=805E0300    log (non-fatal) each entry with r3/r4/lr and the OS current thread/context; a comma list (a,b,c) logs several
#                         functions in order, RT_LOG_MAX=N raises the 400-line cap, RT_LOG_PTR=4 also shows 32 bytes at r4's address
#   RT_WATCH=800000D4     report stores to that address; RT_WATCH_MASK=FFFFFFC0 widens it, RT_WATCH_RING=1 records
#                         silently (dumped by the other tools), RT_WATCH_STACK=1 adds call stacks. Alias-aware:
#                         0x8..., 0xC... and physical addresses of the same RAM match.
#   RT_CHECK_ZERO=800000D4  report the first moment that word goes from non-zero to zero
#   RT_DUMP=addr:len      hex-dump guest memory in the crash/timeout report
#   RT_SCHED_LOG=1|N      log the first 200 (or N) thread switches with OS thread states; RT_SCHED_STACK=<ctx> stack when it blocks
#   RT_BT_DEBUG=1         raw Bluetooth control-message vectors
#   RT_DSP_LOG=1          log DSP/AI accesses, the AX command lists, mails in both directions and AI DMA start/stop
#   RT_DSP_DUMP=dir       save each DSP microcode image the game uploads (stays local: it comes from your disc)
#   RT_STRICT=1           calls/jumps into code that was never lifted (e.g. the HOME-menu module) abort instead of returning 0
#   RT_DI_LOG=1           log every disc read and the first open of each file; missing files are always reported once
#   RT_ANNOTATE=1 python lifter.py gen ...   tag each C statement with its guest address (use with -g + addr2line)
```

## Numbers for your DOL
- 50,872 functions, 2,127,986 instructions. 100.0% lift; 47 left (28 `tw`, 4 `twi`,
  `dcbz_l`, and 13 data words inside code).
- 514 switch jump tables recovered (509 with a confirmed bounds check, 5 by scanning).
  408 more `bctr` sites are tail calls through pointers and 3 use unknown table bases;
  they are dispatched at runtime through the function table.
- Everything compiles warning-free (`gcc -Wall`) and links with the runtime.

## How it works
- All guest state lives in `Ctx` (GPRs, CR, LR/CTR/XER, FPRs as `ps[32][2]`, FPSCR, GQRs,
  MSR, segment regs). Cutting code into C functions anywhere is safe: fallthrough becomes
  a call, in-function branches become `goto`, out-of-function branches become tail calls.
  So extra function starts are always harmless.
- Function discovery: `bl` targets, prologues, code pointers stored in data, addresses
  built with `lis`+`addi/ori`, and code after unconditional `blr`.
- Generated functions are `weak`, so game-specific C can override any of them (HLE) at
  link time without regenerating. Every function entry feeds a trace ring (`RT_TRACE`).
- Guest memory is big-endian behind `rt_r32/rt_w32/...`; MEM1 and MEM2 are mapped and the
  hardware window (0xCC/0xCD......) goes to `rt_mmio.c`.

## Interrupts and threads (how the boot gets past the first IOS request)
- **Poll points.** Generated code polls for interrupts at every function entry and every loop
  back-edge (`RT_POLL`). Delivery mimics the exception vector: the interrupted registers are written
  into the current OSContext (pointer at 0x800000D4), the handler from the exception table
  (0x80003000 + 4 * exception) is called with r3 = exception, r4 = context, and the handler's final
  `OSLoadContext` carries a sentinel SRR0 that unwinds back to the poll site (`rt_exc_return`).
- **Sources.** PI interrupt cause/mask, the Hollywood IPC mailbox (IOS replies), VI retrace
  (display interrupt registers, written by the SDK as 16-bit halves), and the decrementer
  (60.75 MHz real-time time base). A helper thread only raises flags.
- **Threads.** Each guest thread is a host thread with its own register file (`Ctx`). Two SDK
  routines are replaced (`game/wwe13_os.c`): `OSSaveContext` at 0x805D8DB0 and `OSLoadContext`
  at 0x805D8E30, both identified from their disassembly. The SDK's own scheduler runs unmodified
  and ends with `OSLoadContext(next)`: for the running thread that is a return (the code after it
  is the epilogue, verified in the disassembly), for another thread the caller is parked and the
  target woken, for a new thread a host thread is started from its saved context.
- Tested with fake guest code (`tests/test_threads.c`): thread ping-pong, interrupt return with
  registers restored, decrementer, and an interrupt handler that switches to another thread which
  later resumes the interrupted one at its poll site.

## Boot bring-up log (what the real DOL does under this runtime)
`__start` (0x80004050) initializes the OS and then the program runs:
1. SDK banners through `OSReport` (0x805D93A0, hooked): EXI, SI, OS, SC, NAND, DVD, VI, all
   "release build: Aug 23 2010 (0x4302_145)".
2. IOS conversation (`rt_ios.c`, every request logged): /dev/stm, /dev/fs, /dev/es, /dev/di, settings
   files. Replies are zero-filled successes except: the disc drive returns 1 (success), and /dev/usb/*
   other than the Bluetooth dongle is reported absent.
3. Video setup and retrace interrupts every frame. The first draw-sync tokens are processed by the GX
   command processor (see below).
4. `main` runs on a fresh stack (0x805D8F20 helper), the game creates its own threads (a Bluetooth/pad
   thread, a render thread, a job worker) and starts its frame loop, issuing graphics commands.
5. It tries to open game files and gets `DVDOpen(): file 'plistwii_4x3.def' / 'pac/_startup.pac' was
   not found`, because the disc file table is not in memory. The game then keeps running with null
   objects, and a null object's `memset` writes zeros through the physical alias 0x000000D0/D4, which is
   the same RAM as 0x800000D4, the OS's current-context pointer. That corrupts the scheduler and the main
   thread is lost. (Found with the alias-aware write watch; the zero-write shows up as a store to physical
   0xD4 from the C-library clear routine at 0x80004714.) On a real console that store would fault, since
   address 0 is not mapped, so this is a consequence of the missing files, not a runtime bug.

**Update: disc backend (`runtime/rt_di.c`, `--disc`).** `/dev/di` reads (ioctl 0x71, offset stored >> 2) and the disc ID (0x70)
are served from an extracted disc folder, and the FST is placed in guest memory with its pointer at 0x80000038 as the apploader
would. With the files present the game opens `plistwii_4x3.def`, reads the header (14336 bytes) of every `.pac` it lists, loads
`pac/_startup.pac` in one 174080-byte read, starts two more threads and initializes AI. The FST must sit at the very top of MEM1
(0x81800000), above the arena that ends at 0x81700000: placed inside the arena the game's heaps zero it and every `DVDOpen` fails.
Then the audio interface needed a sample counter (`rt_mmio.c`): `AIInit` measures it, and with the counter stuck at 0 the main
thread spun on `0xCD006C08` (505 million reads in 45 s).
**Update: modules, DSP and audio clock.**
- The game links `HbmRso.rso` (the HOME-menu module) into its heap with its own loader and calls the module's `_prolog` (0x81598760).
  That code is not in `main.dol`, so nothing lifted can run it. `rt_call_indirect` / `rt_jump_indirect` now log such a call once and
  return 0 (only for heap addresses; `RT_STRICT=1` restores the abort). The HOME menu will not work until modules are lifted or HLE'd.
- DSP boot (`rt_mmio.c`): the SDK uploads an 8 KB microcode image (mails `0x80F3A001` ... `0x80F3D001`); the runtime answers with
  `DSP_INIT` (0xDCD10000) plus a DSP interrupt. After the boot the AX protocol is answered at mail level: `0xBABExxxx` + a command-list
  address -> the list is accepted (not executed: no mixing yet) and `DSP_YIELD` (0xDCD10002) is posted; `0xCDD10001` -> `DSP_RESUME`;
  `0xCDD10003` needs no answer. DSP -> CPU mails go through a queue, like the one-deep hardware mailbox.
- AI DMA (0xCC005030..503A): the SDK starts a 384-byte buffer (96 stereo samples) and expects AIINT (control bit 3) each time it has been
  played, 2 ms at 48 kHz. That interrupt clocks the audio engine. It is now raised from wall-clock time (timer thread wakes the guest,
  the guest decides). About 500 AX frames per second run.
- Crash/timeout reports now list the guest OS threads (state, priority, suspend/wait queue, saved PC).

**Current state: every resource lookup the game makes at start-up now succeeds, and the main thread runs its render loop.**
With the 101 character archives and 10 of the 12 `pac/menu` archives supplied:
- The `/CHAR/DAT`, `/CHAR/PRO` and `/CHAR/MOVS` lookups succeed (they failed with the character archives missing). 55 of the 101 `ch` files match
  the file table's size and 46 do not; the lookups worked regardless, so a size difference alone is not a problem.
- The `/MLYE/LGAL` lookup, which stalled the previous run in the same zero-size allocation loop (`0x806A9300` calling the allocator `0x80698C48`
  with size 0), now succeeds, as do `/MLYE/DOTI`, `/MENU/FNT2`, `/MLYE/CMSM`, `/RGRP/MAGG`, `/HLPM/HLPD`, `/SDB/0000` and `/SSLC/INFO`.
  Decoded from `RT_LOG_AT=806A8C48 RT_LOG_PTR=4`: 29 lookups, none with type 0xFFFF. The entries are in the `pac/menu` archives
  (`MLYE` = menu layout, English). The wait loop is gone.
- After the last lookup (`/HLPM/HLPD`) the main thread keeps running: in a 90 s run it issued 188 MB of GX data (20.7 million commands,
  514,589 draws, 2,058,356 vertices, 17,812 draw-sync tokens, 0 decode errors). These numbers are not frame rates: the run is not paced to real
  time, and they change from run to run (a 25 s run decodes only 1,259 draws, so the heavy drawing starts well after the first half minute).
  **Correction:** an earlier version of this paragraph said the game made no disc reads after start-up and called that "a render loop with
  nothing left to load". Logging every read (`RT_DI_LOG=1`) shows that was too strong: reads do continue late in the run, and the last ones are
  menu data (`fontSD`, `MnLaySD`, `menu.pac`, `string.pac`). So the game is still loading menu resources late in the run; whether it has reached a
  visible menu is still unknown.
- **What is not known:** which screen the game is on. There is no renderer yet (GX is decoded and counted, not drawn) and no pad input, so
  the likely explanations (legal or title screen waiting for a timer or a button) cannot be told apart from a loop that never advances.
  The next thing to build to find out is a way to see a frame: either the GX to Vulkan/GLES renderer (M4), or, cheaper, a debug dump of the
  XFB copy / the first textured draws to PNG.
- **Re-sent top-level files fixed the size mismatches.** The new `_startup.pac` (172,508 bytes) and `string.pac` (9,355,264 bytes) match the file
  table exactly; the copies sent earlier (174,080 and 9,359,360) came from a different build. So the "modded or re-packed image" guess below was
  too broad: at least those two were simply the wrong versions. `pac/gm.pac` (4,655,104, exact) is also in now, and `misc.pac` was re-sent with
  the same size but different content (the newest copy is used). With these, the same 29 lookups succeed; `/SDB/0000` (string database) is now 0x24B
  units instead of 0x260, which is the visible effect of the right `string.pac`. The render loop is unchanged
  (227 reads, 156 files touched in 90 s). Still different in size from the file table: 46 of the 101 `pac/ch` archives, four HD menu variants,
  `sound/Music.pck`, `opening.bnr`. If you can re-dump those from the same image as `_startup.pac` and `string.pac`, do; so far none has caused a failure.
- With 20 of the 42 `pac/evt` archives added (`Entrance00`-`08`, `evtdata`, `evtfont`, `evtgdhd`, `evtgdsd`, `evtmot`, `evtmov`, `evtobj`,
  `Season00`-`03`) a 90 s run gives the same result: the same 29 lookups, none failed (226 reads, 155 files
  touched, up from 207 and 136). They are opened for the index and not asked for yet.
- **Run with everything received so far** (259 files in the folder). Since the previous bullet it also has all 63 `pac/edit`, all 8
  `pac/evtdsc`, 17 more `pac/evt` (`Season04`-`06`, `Universe00`-`03`, `WSD00`-`05`, `Winning00`-`03`), `pac/bg/bg.pac` and
  `pac/yase/InGameLua.pac`; every one of these has exactly the size the file table gives. 90 s result: the same 29 lookup requests (20 distinct
  paths), none failed; GX 176 to 192 MB between runs (19 to 21 million commands, 480,000 to 520,000 draws, 0 errors); disc: 317 reads,
  9,704,384 bytes, 246 files touched. That is 90 more files than the 156 of the previous run, which is exactly the number of files added since:
  the game opens and reads every archive in its file table once at start-up, and these were only that. **The extra archives changed nothing
  visible; the game is in the same state as before.**
- **HD set is now the default.** The game chooses between the two asset lists by asking the SDK for the console's aspect ratio
  (`SCGetAspectRatio`, 0x8062B110, called at 0x80109104 and 0x80109170): 16:9 gives `plistwii.def` (the `*HD` archives), 4:3 gives
  `plistwii_4x3.def` (the `*SD` archives). The SDK reads that setting from SYSCONF on the NAND, which is not emulated and reads back as zeros,
  so the game always saw 4:3 and took the SD list. `game/wwe13_os.c` now answers that call from a runtime setting (`rt_sc_widescreen`,
  `runtime/rt_hle.c`), default 16:9; `--aspect 4x3` gives the old SD behaviour back. It switches the **whole** list, not only Load and Match
  (menuHD, MnLayHD, fontHD, LoadHD, MatchHD, CAE_HD, ScrLayHD, MnUIHD, game2dHD, evtgdhd instead of their SD counterparts); the game has no
  per-file choice. Result of a 90 s run with the folder of 264 files: the game asks for `plistwii.def` and the HD archives, and no longer opens
  `plistwii_4x3.def`, `LoadSD`, `MatchSD` or any other `*SD` archive. The same 29 lookup requests (20 distinct paths) all succeed, none failed;
  GX 195.5 MB (21.5 million commands, 533,812 draws, 0 errors); disc: 323 reads, 9,735,104 bytes, 252 files touched, none missing from the
  folder. Nothing visible differs yet, because nothing is drawn.
- `pac/menu/MatchHD.pac` has been received (37,969,920 bytes on disk against 18,538,496 in the file table: the folder wins, like for the other re-packed files).
  Still not in the folder: the 191 `movies/*.bik` videos (about 2.2 GB). Since the float fix the game runs far enough to ask for the first one, `movies/logo.bik`
  (see "Next steps"); the rest are not needed until that works.
  The game also asks for `plistwii.arc`, which is not in the file table (only the `.def` is). `LoadSD` and `MatchSD` are not needed any more
  (only `--aspect 4x3` would ask for them), and the five `pac/evt/T_*.pac` have been received. None of these has stopped the boot: a missing
  archive gives a "not found" warning and the game carries on.
- Files in the folder that this run never read: the SD archives that the HD list replaces (`CAE_SD`, `fontSD`, `menuSD`, `MnLaySD`,
  `MnUISD`, `ScrLaySD`, `pac/game2dSD.pac`, `pac/evt/evtgdsd.pac`), `plistwii_4x3.def`, `pac/plistwii.h`, `pac/plistwii_4x3.h` and
  `opening.bnr`. Four of the HD files (`LoadHD`, `MnLayHD`, `MnUIHD`, `menuHD`) differ in size from the file table.
- `RT_DI_LOG=1` prints every disc read as a byte offset. With `--disc <folder>` the offsets follow the table built from the folder (files sorted
  by name case-insensitively, depth first, each 32 KB aligned, starting at 0x1000000), so a read can be mapped back to a file.
- A failed lookup is still how the next missing archive shows up: `RT_LOG_AT=806A8A94 RT_LOG_PTR=4` prints every entry header; a header whose
  fourth word starts with `FFFF` is a failed lookup, with the path after it.

Bugs fixed on the way, each of which hid the next problem:
- **BSS clearing.** The DOL's declared BSS range overlaps a data section (the small-constants area behind
  r2). Zeroing it after copying the sections wiped initialized values, e.g. the `-1` that ends the game's
  memory-pool size list. The loader now leaves it alone (memory starts zeroed anyway).
- Missing low-memory words (0x80003110 arena end), dcbz_l and the locked cache (mapped at 0xE0000000),
  tw/twi traps (now conditional), Bluetooth HCI payload position, video display-interrupt registers that
  the SDK writes as 16-bit halves, IOS replies that must be queued one at a time.

New runtime pieces: Bluetooth controller (HCI init sequence completes: reset, buffer size, class, name,
timeouts, scan enable, inquiry finds nothing; Wii Remotes are not emulated), the GX command processor
(`rt_gx.c`: decodes the write-gather stream including vertex-format-dependent draw lengths, executes
draw-sync tokens and draw-done through the pixel-engine registers, counts draws; on the real boot it
decoded 446,917 bytes as 273,612 commands with zero errors), and an optional `--header` for the disc
header (game ID in low memory).

## Controller input (virtual Classic Controller)
The game reads its pads through the SDK's KPAD library: `KPADReadEx(chan, KPADStatus *buf, count, s32 *err)` at 0x80674DC0, called from 0x806A3FF4,
once per frame for each of the four channels (90 s run: 4,505 calls per channel). The Wii Remote itself is not emulated (no Bluetooth HID link,
and the SYSCONF paired-device list is not emulated), so `game/wwe13_os.c` replaces that one function with `rt_hle_kpad_read_ex` (`runtime/rt_input.c`):
channel 0 is a **Classic Controller** that is always connected, channels 1 to 3 report "no controller" (error -2, no samples). The state comes from
`rt_pad_set()` (the Android touch overlay calls it), from `RT_PAD_SCRIPT`, or stays "nothing pressed".
- Button bits are the SDK's `WPAD_BUTTON_CL_*` values (UP 0x0001, LEFT 0x0002, ZR 0x0004, X 0x0008, A 0x0010, Y 0x0020, B 0x0040, ZL 0x0080,
  R 0x0200, PLUS 0x0400, HOME 0x0800, MINUS 0x1000, L 0x2000, DOWN 0x4000, RIGHT 0x8000); sticks are -1..1 floats, triggers 0..1 (a pressed L or R reads as a
  fully pressed trigger).
- Written into the game's buffer per sample (0xF0 bytes): `dev_type` (+0x5C) = 2, `wpad_err` = 0, `dpd_valid_fg` = 0 (no pointer), `data_format` = 8, and
  `ex_status.cl` at +0x60: hold, trig, release, lstick, rstick, ltrigger, rtrigger. The core Wii Remote fields (hold/trig/release at +0, acceleration, pointer) stay zero.
- **Verified:** the offsets of `dev_type`, `wpad_err`, `dpd_valid_fg`, `data_format` and the 0xF0 sample size match the copy loop in the game's own
  KPADReadEx; the device numbers (2 = Classic) match the comparisons in it; the unit test checks every byte written (hold/trig/release edges, sticks,
  triggers, channels, scripts). A 90 s run with scripted presses: the game calls the function 4,505 times per channel and all 9 scripted presses
  (90 held samples) were delivered; the disc reads and error counts are the same as without them.
- **Not verified:** the field order inside `ex_status.cl`, the exact `data_format` number and the stick/trigger ranges come from my memory of the SDK headers,
  not from this game's code. **Whether the game reacts to the buttons is unknown**: nothing is drawn, so no one can see which screen it is on. If a menu does not respond on
  a device, those three assumptions are where to look first (the KPADStatus bytes can be dumped with `RT_WATCH` on the buffer address).
- Not done: a physical gamepad or keyboard (only the touch overlay exists), the Wii Remote core buttons, pointer, motion and rumble.

## Graphics (GX renderer: `rt_gxr*.c`)
**What exists.** The GX command processor (`rt_gx.c`) already decoded the game's FIFO; now `rt_gxr.c` turns it into pictures:
- Front end (`rt_gxr.c`, `rt_gxr_tex.c`): vertex fetch (direct / indexed, all component formats), position matrices, perspective and orthographic projection, texture
  coordinate generation (regular, with the dual-texture post transform), the TEV stage setup (up to 16 stages, colour/alpha combiners, swap tables, konst colours,
  4 registers), alpha test, depth test, blending, scissor, viewport, texture decoding (I4 I8 IA4 IA8 RGB565 RGB5A3 RGBA8 C4 C8 C14X2 CMPR with palettes), and EFB copies:
  to the screen (the picture) and to a texture (encoded back into guest memory, so later draws that use the copy read it as an ordinary texture).
- Backend 1, software (`rt_gxr_soft.c`): float TEV, perspective-correct, near/far clipping, top-left fill rule, PNG output without zlib. Slow (about 60x too slow for
  the game), so it draws only the frames that are dumped. It is the reference the other backend is checked against.
- Backend 2, **OpenGL ES 3** (`rt_gxr_gles.c`): the EFB is a 640x528 texture + 24-bit depth behind an FBO; one `glDrawArrays` per GX draw; the whole TEV pipeline is one
  fragment shader driven by uniforms; blend / depth / scissor / colour masks are GL state; GX clip space is mapped to GL clip space per vertex so GL does the clipping.
  It runs on a thread of its own (an EGL context belongs to one thread; the guest's threads take turns) and makes its own EGL context, so it needs no GL/EGL headers:
  everything is resolved at run time. On a PC it runs headless on Mesa (`RT_GL_HEADLESS=1`); on Android it draws into the app's `SurfaceView`
  (`Native.setSurface`), letterboxed to 16:9 or 4:3 following the console aspect setting.

**What was checked.**
- `tests/test_gxr.c`: hand-computed pixels for a Gouraud triangle, a textured quad, display copy, EFB-to-texture round trips, texture decoders.
- `tests/test_gxr_gles.c`: the same six scenes through both backends (depth test with 3 functions, three blend modes plus alpha test, face culling modes, scissor + clear
  rectangle, perspective texturing with repeat / mirror wrap and nearest / bilinear, TEV with konst colours and a register). On llvmpipe: no pixel differs by more than 1 level.
- **The real game**: with `RT_FRAME_DUMP` the first screens came out right (Wii Remote safety notice, "WWE 2K26 - Don't try this at home", the auto-save notice with the B
  button). The OpenGL ES backend produced the same frames as the software one (maximum difference 1 level; the only larger differences are the spinning save icons,
  which are at a different animation phase in two separate runs). The OpenGL ES backend ran the game at about 30 frames per second on Mesa's software GL on a 2-core
  machine, 235,000 draws in 100 s.
- **Not checked:** any real GPU (Mali / Adreno / ...), the Android window path (`eglCreateWindowSurface`, swap, surface loss), speed on a phone, anything in
  3D (no wrestler, ring or menu has been drawn yet: the game cannot get past the first movie).

**What is not implemented** (it will show as missing or wrong pictures once the game gets there): lighting (lit colour channels use the material colour; normals are
ignored), lines and points (skipped), fog, indirect texturing / bump, logic ops in the blender (drawn without blending), EFB peek / poke, z-texture, texture LOD / mipmaps
(level 0 only), anisotropy, "z before texture" subtleties, 8-bit fixed-point TEV rounding (float math is used), `GXSetDispCopyGamma`. EFB copies to textures go through guest
memory (a `glReadPixels` per copy: correct, slow on a phone). **Vulkan is not implemented.** I chose OpenGL ES 3 because it could be built, run and compared here, which a
Vulkan renderer could not; the front end is backend-independent (`GxrBackend` in `rt_gxr.h`: draw / clear / read / present), so a Vulkan backend needs only those five calls.

**Debugging aids:** `RT_GXR_TRACE=N` (+ `RT_GXR_TRACE_FROM=frame`) prints the state of N draws (stage setup, first vertices, matrices, viewport); `RT_GXR_XFTRACE=N` logs writes
to the viewport / projection registers with the guest caller; `RT_GX_FLIPCULL=1` swaps the culling sign if the 3D scenes come out inside out (the sign convention is from memory);
`RT_LOG_AT=<addr> RT_LOG_FPR=1` also prints f1..f6 when a function is entered; `RT_GL_VSYNC=0` turns off the swap interval.

**A bug the renderer found in the runtime.** The first frames were completely black because the viewport and projection the game set were 0 x 0 and NaN. Cause: the
single-precision instructions (`fadds fsubs fmuls fdivs fmadds ...`) in `rt.h` converted their *operands* to float before computing. On the real CPU they take the full
double from the register and round only the result. The compiler's int-to-float idiom is `fsubs (0x43300000_xxxxxxxx as double) - 2^52`: with operands rounded to float first
that gives 0, so **every integer-to-float conversion in the game returned 0** (screen sizes, anything animated). Fixed (`rt_add_s` etc. compute in double and round the
result; fmaf is kept when all three operands are single values, as the earlier Dolphin comparison requires) and covered by a lifter test. Generated code must be rebuilt
after this change (`scripts/build_gen.sh` does it: it notices that `rt.h` changed). Earlier "the game does X" observations in this README were made with the bug present.

## Android app (`android/`, never built)
A Gradle project (Android Gradle Plugin 8.5.2, Gradle 8.9 wrapper, compileSdk 34, minSdk 26, arm64-v8a only):
- `app/src/main/java/org/wwe13recomp/`: `MainActivity` (finds the disc folder, starts the game thread), `PadView` (draws the on-screen controller, sends
  touches), `TouchPadLogic` (layout and multi-touch logic; no Android dependencies, so it is unit-tested on a plain JVM), `Native` (JNI).
- On-screen Classic Controller: D-pad and left stick on the left, A B X Y and right stick on the right, L / ZL and R / ZR along the top, - HOME + at the bottom
  centre. Fingers can slide between buttons, several buttons and both sticks work together, the layout shrinks on 4:3 tablets.
- `app/src/main/cpp/`: `rt_android.c` (JNI: starts the game on a background thread, stderr goes to logcat tag `wwe13`) and `CMakeLists.txt` (runtime + `game/*.c` +
  the C generated from your DOL, `-O1`, hidden visibility, no `rt_main.c`).
- Runtime changes for Android: `rt_compat.h` (`backtrace()` only exists from API 33), no SIGSEGV/SIGUSR1/SIGALRM handlers on Android (ART owns the first two), the
  1 GB guest stack falls back to 512 and 256 MB if the system refuses.
- **Build it on a PC** (needs python3, JDK 17+, curl, unzip; Linux, macOS or WSL): `android/build_apk.sh /path/to/main.dol --install-sdk` downloads Google's command-line tools into `android/sdk`, installs platform 34 / build-tools / NDK 26.1 / CMake 3.22.1 there after you accept the licences, then builds. With an SDK you already have (NDK and CMake installed, `ANDROID_HOME` set): `android/build_apk.sh /path/to/main.dol`. **The download and Gradle steps were never run** (the sandbox cannot reach dl.google.com or maven.google.com), so expect to fix a first-run problem or two.
  It lifts your DOL to C, compiles about 90 MB of C for arm64 (10 to 40 minutes the first time) and writes `wwe13-debug.apk`. The APK contains code derived from your
  DOL: do not share it. Install with `adb install -r wwe13-debug.apk`.
- **No PC: build it on GitHub's servers** (`android/github-build-apk.yml`, never run). In a **private** repository of your own: create the file `.github/workflows/build-apk.yml` with that
  text, create a release with the tag `files` and attach `main.dol` and the project zip to it, then Actions -> "Build WWE13 APK" -> Run workflow. After 30 to 90 minutes the run has an artifact
  `wwe13-apk` (a zip holding `wwe13-debug.apk`). This puts your `main.dol` on GitHub (as a release file in your private repository, not in the git history); the APK and the build log contain
  code made from it, so keep the repository private. Never use a public repository for this.
- **Disc folder on the phone:** the extracted disc (folders `sys/` and `files/`, with `sys/main.dol`) in `/sdcard/WWE13/disc` (the app asks for "All files access")
  or in `Android/data/org.wwe13recomp/files/disc`. The folder needs about 2 GB without the movies (the whole disc is 4.3 GB, 2.2 GB of it videos).
- **What was checked here, and what was not.** Checked: the Java code compiles against hand-written Android stubs (so typos and signature mismatches between
  my files, not the real Android API); `TouchPadLogic` passes its JVM test on four screen sizes; `rt_android.c` passes a clang syntax check against stub headers; the
  CMake file lists the right sources (configured with the host toolchain); the runtime and 3 sampled generated files compile with clang. **Not checked:** the
  Gradle build, the NDK compile and link (no Android SDK or NDK could be downloaded in the sandbox), installing and starting the app, the JNI calls, file
  access on a real phone, speed. **What it should do when it starts:** the game boots, runs, draws on the screen through OpenGL ES (`SurfaceView` under the touch
  controls, see "Graphics"; the OpenGL ES backend itself is tested on a PC, the Android surface path is not) and takes the controller state; there is no sound (AX mixing does not
  exist yet). Until the game gets past its first movie (see "Next steps") you will see the Wii Remote safety notice, the WWE 2K26 notice and the auto-save notice, then black.

## About the disc files received so far
- `header.bin`, `region.bin`: game ID S3XE78, title "WWE '13", Wii disc magic; region 1 = USA. Used.
- `boot.bin`, `bi2.bin`, `apploader.img`: read, not needed yet.
- `fst.bin`: **valid** (the earlier "damaged name table" note was a misreading). 10140 bytes = the size boot.bin names; 473 entries,
  12 directories + root, 460 files; the directory tree walks cleanly; name offsets strictly increase; no overlapping extents; the last
  extent ends at 4,286,316,512 bytes, inside the 4,286,316,544 bytes the TMD declares (which is exactly the 2110 hash groups in
  `h3.bin`). The 30 "extra strings" are 12 zero bytes of padding before the last entries. Disc offsets are stored >> 2 and files are
  packed on 4-byte boundaries. `plistwii.def`, `plistwii_4x3.def` and `StaticModule_USA.sel` are in the root; `_startup.pac` is `pac/_startup.pac`.
- **Update:** the re-sent `_startup.pac` and `string.pac` do match this fst.bin (see "Current state"). The paragraph below describes the first set of files.
- **The extracted files you used did not all match this fst.bin:** 17 files matched their FST size exactly, but `pac/_startup.pac`
  (172508 in the FST, 174080 on disk), `pac/string.pac` (9355264 vs 9359360) and `opening.bnr` (414568 vs a 6496-byte GameCube
  `BNR1` banner) did not. Most likely the folder and fst.bin come from different images. The same holds for `sound/Music.pck` (117,043,200 bytes on disk, 109,445,568 in the FST). The `.pck` files are Audiokinetic Wwise packages (magic `AKPK`). That is why `--disc` builds the file table from
  the folder by default; extract everything from one image to be safe.
- `pac/menu/MatchHD.pac` (received, used). Its size differs from the file table's entry, like the other re-packed files above; `--disc` builds the table from the folder, so it does not matter.
- `StaticModule_USA.sel` / `HbmRso.rso`: Nintendo RSO format. The `.sel` is the export table of `main.dol` (module name
  `smackWii_Release_USA.elf`, 192 symbols, ELF hashes verified): `rso_tool.py` reads it. `HbmRso.rso` is the Home Button Menu as a
  loadable module (about 147 KB of code, 710 exports, ~6600 relocations). The lifter does not handle modules yet, so a call into it
  now logs once and returns 0 (see above); add module lifting before the HOME menu can open.

## Next steps
1. **The logo movie is garbled.** With `movies/logo.bik` present (received: 7,948,808 bytes, 640x480, 570 frames: the size the file table gives for `logo4x3.bik`, so probably that file under the
   other name; the game ran with it under both names) the game plays on to the title screen ("Forever Reloaded", press any button) and the main menu, no abort. The movie frame itself comes out as
   red strips with horizontal lines: Bink decodes into YUV planes that the game draws through the GX renderer (textures + TEV), so either the lifted Bink code or the renderer's texture / TEV handling
   is off for it. Not investigated yet; dump frames around 2800 to 3100 (`RT_FRAME_AT`) and trace the draws (`RT_GXR_TRACE`). The other 190 movies (about 2.2 GB) only when a lookup asks for them.
   (`plistwii.arc` is also probed and reported "not found"; the file table does not list it and the game carries on, so it is not needed.)
2. **Look at the 3D scenes** as soon as the game gets there: lighting, normals and lines are not implemented, the culling sign is a guess (`RT_GX_FLIPCULL`).
3. **AX mixing.** Command lists are accepted but not executed. Wwise needs the DSP's side effects (voice state and position written back
   to the parameter blocks, aux sends) and, for sound, a real mixer feeding the AI DMA buffer. Either HLE the AX ucode (the list format is
   visible with `RT_DSP_LOG=1`; the ucode itself is saved by `RT_DSP_DUMP`) or hook the `AX*` functions.
4. Make accesses to unmapped addresses (address 0 with translation on) fault the way hardware does, so a
   missing resource shows up as a clear "null pointer write" at the culprit instead of corrupting the OS.
5. A Vulkan backend (five functions, see "Graphics"), if the OpenGL ES one turns out too slow on phones.
6. Module support for `HbmRso.rso` (HOME menu), a physical gamepad / keyboard mapping, Wii Remote emulation (Bluetooth HID) if a real remote is ever wanted, further IOS devices, naming more SDK functions for HLE.

## Android notes (shell not started; found by reading the code and measuring)
- Lifted tail calls are `func_X(c); return;`, plain calls. That is why the guest runs on a 1 GB stack. Under clang use
  `__attribute__((musttail))` (all lifted functions share one signature) or a trampoline, then the stack sizes can shrink.
  `rt_call_indirect` has a different signature, so indirect tail calls need to dispatch through a function pointer.
- `execinfo.h` `backtrace()` (rt_boot.c, rt_thread.c) only exists on Android API 33+; guard it.
- Build with the NDK (CMake) at -O1/-O2, not gcc -O0. Generated C is 89 MB in 34 files (about 42 bytes per guest instruction);
  an ARM64 sample at -O1 expanded to roughly 12 instructions per guest instruction, so expect a native library around 100 MB.
  The C comes from the user's main.dol, so each user builds the APK on a PC.
- Every load/store does MMIO, range and watch checks; give it a fast path before judging speed on a phone.
- **What the APK can and cannot do today.** See "Android app" above. It can boot the game and feed it touch input; it cannot show a picture or play sound. Before an Android build is worth playing: a GX renderer (Vulkan or GLES) and AX mixing with audio output. Nothing here has been built with the NDK yet.

## Floating point choices (read before trusting results)
Checked against evidence:
- `fmadds` family uses a 32-bit `fmaf` (Dolphin issue #13865; a test reproduces the
  hardware value 0xBF55BF17 and the old 0xBF55BF18).

From memory of Dolphin's behavior, NOT yet verified against hardware or Dolphin:
- Single-precision scalar ops write ps0 and ps1; double ops write ps0 only; `lfs` fills both.
- frC is rounded to 25 bits for single and paired multiplies (`rt_force25`).
- Quantized load/store scale handling; NaN stores as 0 (a guess).
- Division by zero follows Dolphin's convention as I recall it.
- Low-memory values in `rt_init_lowmem`, the EXI/DSP/IPC/VI/PE register models, the GX command
  encodings and the Bluetooth HCI replies were written from memory and are only exercised as far as the
  boot log above (the GX parser staying in sync over 273k commands is good evidence for its encodings).

Known approximations:
- `fres/frsqrte/ps_res/ps_rsqrte` return exact values; hardware uses lookup tables.
- FPSCR tracks rounding mode and FPCC only. `mcrfs` is not lifted.
- `lwarx/stwcx.` assume no preemption between the pair.

## Legal
Only distribute the tooling. Users must supply their own disc dump.
